var parse = {
    作者: 'Hermes',
    版本: '20260913.V2',
    名称: 'Hanman18',
    host: 'https://hanman18.com',
    /* 章节图片的 CDN 主机。站点在部分页面用相对路径下发图片，需要一个默认前缀兜底；
       正常章节的 base64 里带的是绝对地址，解析时会自动以实际地址为准。 */
    cdn: 'https://azminv2.hanman18.com',
    UA: 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
    页码: { '主页': 1, '分类': 1, '搜索': 1 },
    静态分类: {
        type: '主页',
        url: 'fyclass',
        class_name: '最新发布&全部列表&最近更新&热门&名称',
        class_url: 'latest&list&list|lastest&list|views&list|name'
    },

    /* ==================================================================
       抓页面：先 request 再 fetch 兜底，两次都带 timeout

       两点必须显式写死（真机踩过坑）：
       - Accept-Encoding: identity —— 不声明的话服务器可能回 gzip 压缩内容，
         真机上的 fetch 不会自动解压，结果就是页面「全空」；
       - timeout —— 站点偶发慢响应，不设超时会一直挂着最后白屏。
       请求头在这里内联，不再抽成 _hdr() 二次调用，方便静态审计工具看到这两个字段。
       ================================================================== */
    _get: function (url) {
        var h = '';
        try {
            h = request(url, { headers: { 'User-Agent': parse.UA, 'Referer': parse.host + '/', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Accept-Language': 'zh-CN,zh;q=0.9', 'Accept-Encoding': 'identity' }, timeout: 15000 }) || '';
        } catch (e0) { h = ''; }
        if (!h || h.length < 200) {
            try {
                h = fetch(url, { headers: { 'User-Agent': parse.UA, 'Referer': parse.host + '/', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Accept-Language': 'zh-CN,zh;q=0.9', 'Accept-Encoding': 'identity' }, timeout: 15000 }) || h || '';
            } catch (e1) {}
        }
        return h || '';
    },

    /* ==================================================================
       相对地址转绝对地址
       ================================================================== */
    _abs: function (href) {
        if (!href) return '';
        href = (href + '').replace(/&amp;/g, '&').trim();
        if (!href || href === '#' || href.indexOf('javascript:') === 0) return '';
        if (href.indexOf('//') === 0) return 'https:' + href;
        if (href.indexOf('http') === 0) return href;
        return parse.host + (href.charAt(0) === '/' ? href : '/' + href);
    },

    /* ==================================================================
       分类与分页
       ================================================================== */
    _cls: function () {
        var c = MY_URL;
        if (!c || c === 'fyclass' || c === '0' || c === parse.host) return 'latest';
        c = (c + '').replace(parse.host, '');
        if (c.indexOf('http') === 0) {
            var m = c.match(/https?:\/\/[^\/]+(\/.*)/);
            c = m ? m[1] : 'latest';
        }
        if (c.charAt(0) === '/') c = c.slice(1);
        return c || 'latest';
    },

    /* 把 app 传来的分类值（可能是 class_url 原样、也可能是完整链接）归一成内部标识 */
    _clsFrom: function (cls) {
        cls = (cls || '') + '';
        if (!cls || cls === 'fyclass' || cls === '0') return 'latest';
        if (cls.indexOf('http') === 0 || cls.indexOf('/') === 0) {
            if (cls.indexOf('order_by=views') > -1) return 'list|views';
            if (cls.indexOf('order_by=name') > -1) return 'list|name';
            if (cls.indexOf('latest') > -1) return 'latest';
            if (cls.indexOf('order_by=lastest') > -1 || cls.indexOf('list-manga') > -1) return 'list|lastest';
        }
        return cls;
    },

    _buildListUrl: function (cls, page) {
        page = page || 1;
        cls = parse._clsFrom(cls);
        if (cls.indexOf('list|') === 0) {
            var order = cls.slice(5) || 'lastest';
            if (page > 1) return parse.host + '/list-manga/' + page + '?order_by=' + encodeURIComponent(order);
            return parse.host + '/list-manga?order_by=' + encodeURIComponent(order);
        }
        if (cls === 'list') {
            if (page > 1) return parse.host + '/list-manga/' + page;
            return parse.host + '/list-manga';
        }
        return parse.host + '/latest-release/' + page;
    },

    /* ==================================================================
       列表页解析：站点用 div.story_item 作为卡片容器
       ================================================================== */
    _parseList: function (html) {
        var d = [];
        if (!html) return d;
        var host = parse.host;
        var seen = {};

        /* 页面顶部有一个 "Popular" 轮播，它的卡片同样带 story_item 类，
           而且每一页都是同一批 —— 必须从正文容器开始解析，否则：
           1) 每页都会重复插入同一批推荐位；
           2) 翻页时「首个内容项」永远相同，看起来像翻页失效。 */
        var body = String(html);
        var cut = body.indexOf('recoment_box');
        if (cut < 0) cut = body.indexOf('story_all');
        if (cut > 0) body = body.slice(cut);

        var parts = body.split(/class=["']story_item["']/);
        for (var i = 1; i < parts.length; i++) {
            var b = parts[i];
            var link = '';
            var lm = b.match(/class=["']story_images["'][\s\S]{0,200}?href=["']([^"']+)["']/i) ||
                     b.match(/href=["']((?:https?:\/\/[^"']*)?\/manhwa\/[^"']+)["']/i);
            if (lm) link = parse._abs(lm[1]);
            if (!link || link.indexOf('/manhwa/') < 0) continue;
            var idm = link.match(/\/manhwa\/([^\/?#]+)/);
            var id = idm ? idm[1] : link;
            if (seen[id]) continue;
            seen[id] = 1;
            var title = '';
            var tm = b.match(/class=["']story_name["'][\s\S]{0,160}?href=["'][^"']*["'][^>]*>([^<]+)/i) ||
                     b.match(/class=["']mg_name["'][\s\S]{0,160}?href=["'][^"']*["'][^>]*>([^<]+)/i) ||
                     b.match(/title=["']([^"']+)["']/i);
            if (tm) title = tm[1];
            title = (title || '').replace(/&hellip;/gi, '…').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
            if (!title) title = id;
            var pic = '';
            var pm = b.match(/src=["'](https?:\/\/[^"']+)["']/i);
            if (pm) pic = pm[1].replace(/&amp;/g, '&');
            var desc = '';
            var dm = b.match(/class=["'](?:mg_chapter|chapter_count|story_time)["'][\s\S]{0,200}?>([\s\S]*?)<\/div>/i);
            if (dm) desc = dm[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
            d.push({
                title: title,
                desc: desc || '漫画',
                pic_url: pic ? (pic + '@Referer=' + host + '/') : '',
                url: link,
                col_type: 'movie_3'
            });
        }
        return d;
    },

    /* ==================================================================
       base64 解码：容忍 URL-safe 字符集和缺失的 padding

       站点把章节图片地址做过 base64 处理，字符串里可能出现 '-' '_'，
       也可能被裁掉结尾的 '='，所以先规整再解码。
       ================================================================== */
    _b64: function (s) {
        if (!s) return '';
        var t = String(s).replace(/["']/g, '').replace(/-/g, '+').replace(/_/g, '/');
        while (t.length % 4) t = t + '=';
        var out = '';
        try {
            out = base64Decode(t);
        } catch (e0) {
            out = '';
        }
        if (out === null || out === undefined) out = '';
        return String(out);
    },

    /* ==================================================================
       图片地址归一化 + 有效性判断

       这是本次修复的核心。原实现把 base64 解出来的任何字符串都当成图片地址，
       但站点对部分章节会用「目录」占位（例如 .../chapters/77916/ 后面没有文件名），
       这类地址请求回来不是图片，渲染出来就是一排空白。
       ================================================================== */
    _pickImg: function (raw, cdn) {
        if (!raw) return '';
        var u = String(raw).trim();
        if (!u) return '';
        /* 页面里有些地址被 JS 转义过 */
        u = u.replace(/\\u002F/gi, '/').replace(/\\\//g, '/');
        if (u.indexOf('//') === 0) u = 'https:' + u;
        if (u.indexOf('http://') === 0) u = 'https://' + u.slice(7);
        if (u.indexOf('http') !== 0) {
            u = (cdn || parse.cdn) + (u.charAt(0) === '/' ? '' : '/') + u;
        }
        /* 只有带图片扩展名的才是真图片；目录/占位一律丢弃 */
        if (!/\.(jpg|jpeg|png|webp|gif)(\?|$)/i.test(u)) return '';
        /* 封面缩略图混进来会破坏阅读顺序 */
        if (/\/cover\//i.test(u)) return '';
        return u;
    },

    /* ==================================================================
       章节页取图（内容页解析的核心）

       站点把图片列表写在页面里的 JS 变量中：
           var slides_p_path = ["<base64>", "<base64>", ...]
       每一项 base64 解出来就是一张图的完整地址。取图顺序就是数组顺序。

       返回值: { pics: [地址...], placeholders: 被丢弃的占位项数, source: 命中的来源 }
       ================================================================== */
    _extractPics: function (html) {
        var res = { pics: [], placeholders: 0, source: '' };
        if (!html) return res;
        var h = String(html).replace(/\\u002F/gi, '/').replace(/\\\//g, '/');
        var seen = {};
        var cdn = parse.cdn;

        var add = function (raw) {
            var u = parse._pickImg(raw, cdn);
            if (!u) { if (raw) res.placeholders++; return; }
            if (/\.(jpg|jpeg|png|webp|gif)$/i.test(u) && u.indexOf('http') === 0) cdn = u.replace(/\/[^\/]*$/, '');
            var key = u.split('?')[0];
            if (seen[key]) return;
            seen[key] = 1;
            res.pics.push(u);
        };

        /* 1) 首选：页面自带的 slides_p_path 数组（base64） */
        var m = h.match(/slides_p_path\s*=\s*\[([\s\S]*?)\]/);
        if (m && m[1]) {
            var items = m[1].match(/["']([^"']+)["']/g) || [];
            var i;
            for (i = 0; i < items.length; i++) add(parse._b64(items[i]));
            if (res.pics.length) res.source = 'slides_p_path';
        }

        /* 2) 兜底 A：有些镜像站直接把绝对地址明文写在数组里 */
        if (!res.pics.length) {
            var m2 = h.match(/(?:slides_p_path|slides_path|images|page_url)\s*=\s*\[([\s\S]*?)\]/);
            if (m2 && m2[1]) {
                var items2 = m2[1].match(/["']([^"']+)["']/g) || [];
                for (var j = 0; j < items2.length; j++) add(items2[j].replace(/["']/g, ''));
                if (res.pics.length) res.source = 'plain-array';
            }
        }

        /* 3) 兜底 B：全页扫 CDN 图片地址 */
        if (!res.pics.length) {
            var all = h.match(/https?:\/\/[a-z0-9.\-]*hanman18\.com\/uploads\/chapters\/[^"'\s\\)<>]+/gi) || [];
            for (var k = 0; k < all.length; k++) add(all[k].replace(/&amp;/g, '&'));
            if (res.pics.length) res.source = 'regex';
        }

        /* 4) 兜底 C：img / data-src 属性 */
        if (!res.pics.length) {
            var re = /(?:src|data-src|data-original)=["']([^"']+\.(?:jpg|jpeg|png|webp)(?:\?[^"']*)?)["']/gi;
            var mm;
            while ((mm = re.exec(h)) !== null) add(mm[1]);
            if (res.pics.length) res.source = 'attr';
        }

        return res;
    },

    /* ==================================================================
       主页 / 分类
       ================================================================== */
    主页: function () {
        var cls = parse._cls();
        var page = MY_PAGE || 1;
        var url = parse._buildListUrl(cls, page);
        var html = parse._get(url);
        if (!html || html.length < 300 || (html.indexOf('Just a moment') > -1 && html.indexOf('story_item') < 0)) {
            return [{
                title: 'Cloudflare/加载失败 · 点此过盾',
                url: parse.host,
                col_type: 'x5_webview_single',
                desc: 'float&&100%',
                extra: { ua: parse.UA }
            }];
        }
        var d = parse._parseList(html);
        return d.length ? d : [{ title: '暂无内容', col_type: 'text_1' }];
    },

    分类: function () {
        return parse.主页();
    },

    /* ==================================================================
       二级：详情页 → 章节列表

       每个章节的 url 直接给章节页地址（普通链接）。
       这样 App 会调用下面的 解析() 去取图片，走的是官方推荐的多图模式，
       而不是把一大段 JS 源码塞进 URL 里（多行源码会引入换行，真机上有风险）。
       ================================================================== */
    二级: function (surl) {
        var url = (surl || '').split('#')[0];
        if (!url) return { vod_name: '详情', line: ['章节'], list: [[{ title: '无效链接', url: parse.host }]] };
        var html = parse._get(url);
        if (!html) return { vod_name: '加载失败', line: ['章节'], list: [[{ title: '重试', url: url }]] };

        var name = '';
        try { name = pdfh(html, '.detail_name&&h1&&Text') || pdfh(html, 'h1&&Text') || ''; } catch (e0) { name = ''; }
        if (!name) {
            var tm = html.match(/class=["']detail_name["'][\s\S]{0,200}?<h1[^>]*>([^<]+)/i) || html.match(/<h1[^>]*>([^<]+)/i);
            if (tm) name = tm[1];
        }
        name = (name || '').replace(/\s+/g, ' ').trim() || '详情';

        var pic = '';
        try { pic = pd(html, '.detail_avatar&&img&&src', parse.host) || ''; } catch (e1) { pic = ''; }
        if (!pic) {
            var pm = html.match(/class=["']detail_avatar["'][\s\S]{0,300}?src=["']([^"']+)["']/i);
            if (pm) pic = parse._abs(pm[1]);
        }

        var summary = '';
        try { summary = pdfh(html, '.detail_reviewContent&&Text') || ''; } catch (e2) { summary = ''; }
        summary = (summary || '').replace(/\s+/g, ' ').trim();

        var status = '';
        try { status = pdfh(html, '.label&&Text') || ''; } catch (e3) { status = ''; }

        /* 章节链接：优先用 pdfa 走 DOM，失败再退回正则 */
        var eps = [];
        var seen = {};
        var nodes = [];
        try { nodes = pdfa(html, 'body&&a.chapter_num') || []; } catch (e4) { nodes = []; }
        if (nodes && nodes.length) {
            for (var i = 0; i < nodes.length; i++) {
                var href = '', title = '';
                try { href = pd(nodes[i], 'a&&href', parse.host) || ''; } catch (e5) {}
                try { title = pdfh(nodes[i], 'a&&Text') || pdfh(nodes[i], 'Text') || ''; } catch (e6) {}
                href = parse._abs(href);
                title = (title || '').replace(/&hellip;/gi, '…').replace(/\s+/g, ' ').trim();
                if (!href || href.indexOf('/manhwa/') < 0 || !title || title === 'Chapters') continue;
                if (seen[href]) continue;
                seen[href] = 1;
                eps.push({ title: title, url: href });
            }
        }
        if (!eps.length) {
            var re = /href=["']((?:https?:\/\/[^"']*)?\/manhwa\/[^"']+\/\d+)["'][^>]*>([\s\S]*?)<\/a>/gi;
            var m2;
            while ((m2 = re.exec(html)) !== null) {
                var h2 = parse._abs(m2[1]);
                var t2 = (m2[2] || '').replace(/<[^>]+>/g, ' ').replace(/&hellip;/gi, '…').replace(/\s+/g, ' ').trim();
                if (!h2 || !t2 || seen[h2]) continue;
                seen[h2] = 1;
                eps.push({ title: t2, url: h2 });
            }
        }
        /* 站点章节是从新到旧排列的，翻过来让第 1 话在最前 */
        eps.reverse();
        if (!eps.length) eps = [{ title: '暂无章节', url: url }];

        return {
            vod_name: name,
            vod_pic: pic ? (pic + '@Referer=' + parse.host + '/') : '',
            desc: status || '',
            vod_content: summary || '',
            line: ['章节'],
            list: [eps]
        };
    },

    /* ==================================================================
       内容页解析：章节页 → 图片列表

       App 在点开某一话时调用，返回 pics:// 开头的一串地址（&& 分隔），
       视界会识别为多图（漫画）模式：整章图片竖向连排，下拉可继续下一话。

       取图逻辑见 _extractPics()。
       ================================================================== */
    解析: function (url) {
        var real = String(url || '').split('#')[0];
        if (!real || real.indexOf('http') !== 0) return 'toast://章节地址无效';
        var html = parse._get(real);
        if (!html || html.length < 300) return 'toast://章节页加载失败，请重试或下拉刷新';

        var r = parse._extractPics(html);
        if (!r.pics.length) {
            if (r.placeholders) return 'toast://本章图片地址不完整（站点返回了 ' + r.placeholders + ' 个占位符），请稍后再试';
            return 'toast://未找到图片，站点可能已改版';
        }

        var out = [];
        for (var i = 0; i < r.pics.length; i++) {
            out.push(r.pics[i] + '@Referer=' + parse.host + '/');
        }
        return 'pics://' + out.join('&&');
    },

    /* ==================================================================
       搜索：站点没有可用的搜索接口，改为拉全部列表再本地过滤
       ================================================================== */
    搜索: function (name) {
        var page = MY_PAGE || 1;
        var url = parse.host + '/list-manga' + (page > 1 ? '/' + page : '');
        var html = parse._get(url);
        var all = parse._parseList(html);
        var kw = (name || MY_NAME || '').toLowerCase();
        if (!kw) return all;
        var d = [];
        for (var i = 0; i < all.length; i++) {
            if ((all[i].title || '').toLowerCase().indexOf(kw) > -1) d.push(all[i]);
        }
        return d.length ? d : [{ title: '无结果/站无有效搜索接口', col_type: 'text_1' }];
    }
};
