var parse = {
  作者: 'NULL',
  版本: '20260910v2',
  名称: '大图居',
  host: 'https://m.datuju.com',
  UA: 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
  页码: { 主页: 1, 搜索: 1 },
  /* 分类走聚阅原生分类切换（class_url 直接是站点路径） */
  静态分类: { type: '主页', url: 'fyclass', class_name: '美女图片&美女模特&高清壁纸', class_url: 'meinv&mote&bizhi' },
  /* 统一 GET：内联 UA/Referer/禁gzip/15s超时（真机防乱码防卡死），异常回空串 */
  _req: function(u) { try { return request(u, { headers: { 'User-Agent': this.UA, Referer: 'https://m.datuju.com/', 'Accept-Encoding': 'identity' }, timeout: 15000 }) || ''; } catch (e0) { return ''; } },
  /* 标签清理与实体还原 */
  _text: function(s) { return String(s || '').replace(/<[^>]+>/g, '').replace(/&nbsp;|&#160;/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim(); },
  /* 列表页解析：卡片 a[href$=.html] + img data-src 封面 + h3 标题，按链接去重 */
  _list: function(html) {
    var s = String(html || ''), out = [], re = /<a[^>]+href="([^"]*\/(\d+)\.html)"[^>]*>\s*<img[^>]+data-src="([^"]+)"[^>]*>\s*<h3>([\s\S]*?)<\/h3>/gi, m, seen = {};
    while ((m = re.exec(s))) {
      if (seen[m[1]]) continue;
      seen[m[1]] = 1;
      var t = this._text(m[4]);
      if (!t) continue;
      out.push({ id: m[2], href: m[1], img: m[3], title: t });
    }
    if (!out.length) {
      re = /<a[^>]+href="([^"]*\/(\d+)\.html)"[^>]*>\s*<img[^>]+data-src="([^"]+)"[^>]*alt="([^"]*)"/gi;
      while ((m = re.exec(s))) {
        if (seen[m[1]]) continue;
        seen[m[1]] = 1;
        var t2 = this._text(m[4]);
        if (!t2) continue;
        out.push({ id: m[2], href: m[1], img: m[3], title: t2 });
      }
    }
    return out;
  },
  /* 主页：MY_URL 是分类路径（meinv/mote/bizhi），数字翻页 /list_N.html；mote 首页是模特索引页（.name 卡片），解析后跳到模特作品列表 */
  主页: function() {
    var paths = ['meinv', 'mote', 'bizhi'], p = Number(MY_PAGE || 1);
    var path = String(MY_URL || '');
    if (paths.indexOf(path) < 0) path = 'meinv';
    var u = p > 1 ? this.host + '/' + path + '/list_' + p + '.html' : this.host + '/' + path + '/';
    var html = this._req(u);
    var a = this._list(html);
    if (!a.length && path === 'mote') {
      /* 模特索引页：.name 区块 a[href] + img data-src + i 名字 → 作品列表页（无翻页，翻页仍走 list_N） */
      var nr = /<a[^>]+href="([^"]*\/mote\/[a-z0-9]+\/)"[^>]*>\s*<img[^>]+data-src="([^"]+)"[^>]*>\s*<i>([\s\S]*?)<\/i>/gi, nm;
      a = [];
      while ((nm = nr.exec(html))) {
        a.push({ href: nm[1], img: nm[2], title: this._text(nm[3]) });
      }
    }
    if (a.length) {
      var d = [];
      for (var j = 0; j < a.length; j++) d.push({ title: a[j].title, img: a[j].img, col_type: 'movie_3', url: a[j].href });
      return d;
    }
    if (p > 1) return [];
    return [{ title: '‘‘’’加载失败，点我重试', desc: '网络异常或站点不可达', col_type: 'text_center_1', url: this.host + '/' + path + '/' }];
  },
  /* 搜索：POST JSON 接口（tid 0=美女 1=壁纸），tab 记忆 + 上下页按钮 */
  搜索: function(name) {
    var q = String(name || '').trim();
    if (!q) return [{ title: '‘‘’’请输入关键词', desc: '支持汉字/字母/数字', col_type: 'text_1', url: 'hiker://empty' }];
    var h = 'dtjs_', d = [], cur = getMyVar(h + 'tid', '0'), tabs = ['美女图片', '高清壁纸'];
    if (getMyVar(h + 'kw') !== q) { putMyVar(h + 'kw', q); putMyVar(h + 'page', '1'); putMyVar(h + 'tid', '0'); cur = '0'; }
    var p = Number(getMyVar(h + 'page', '1')) || 1;
    for (var i = 0; i < tabs.length; i++) {
      d.push({ title: String(i) === cur ? '❆ ' + tabs[i] + ' ❆' : tabs[i], url: $('hiker://empty#noLoading#').lazyRule(function(idx, key) { putMyVar(key + 'tid', idx + ''); putMyVar(key + 'page', '1'); refreshPage(false); return 'hiker://empty'; }, i, h), col_type: 'scroll_button' });
    }
    d.push({ col_type: 'blank_block' });
    var raw = '';
    try {
      /* 手工拼 JSON body（站点只认 application/json 原文体） */
      var payload = '{"str":"' + q.replace(/[\\"]/g, '') + '","tid":' + (Number(cur) || 0) + ',"page":' + p + '}';
      raw = request(this.host + '/library/search.php', { method: 'POST', body: payload, headers: { 'User-Agent': this.UA, Referer: 'https://m.datuju.com/search.php', 'Content-Type': 'application/json', 'Accept-Encoding': 'identity' }, timeout: 15000 }) || '';
    } catch (e0) {}
    var total = 0, arr = [];
    try { var j = JSON.parse(raw); total = Number(j.total) || 0; arr = this._list(j.content || ''); } catch (e1) {}
    for (var k = 0; k < arr.length; k++) d.push({ title: arr[k].title, img: arr[k].img, col_type: 'movie_3', url: arr[k].href });
    if (total > p * 10) d.push({ title: '‘‘’’下一页（第 ' + (p + 1) + ' 页）', url: $('hiker://empty#noLoading#').lazyRule(function(key, np) { putMyVar(key + 'page', np + ''); refreshPage(true); return 'hiker://empty'; }, h, p + 1), col_type: 'text_center_1' });
    if (p > 1) d.push({ title: '‘‘’’上一页', url: $('hiker://empty#noLoading#').lazyRule(function(key, np) { putMyVar(key + 'page', np + ''); refreshPage(true); return 'hiker://empty'; }, h, p - 1), col_type: 'text_center_1' });
    if (arr.length === 0) d.push({ title: '‘‘’’未找到「' + q + '」相关内容', desc: '换个关键词试试', col_type: 'text_center_1', url: 'hiker://empty' });
    return d;
  },
  /* 二级：详情标题/日期/专辑；图集用 bmore 接口取全量图名，选集 @lazyRule 烘焙出 pics://；壁纸单图页直接看大图 */
  二级: function(url) {
    var u = String(url || ''), html = this._req(u);
    var tm = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
    var title = tm ? this._text(tm[1]) : '详情';
    var dm = html.match(/发布时间：([\d\- :]+)/i);
    var picM = html.match(/<img[^>]+id="picBox"[^>]*>/i);
    var first = picM ? (picM[0].match(/src="([^"]+)"/) || ['', ''])[1] : '';
    var infoM = html.match(/class="cleararea"[^>]*data-info="([^"]*)"/i);
    var parts = infoM ? infoM[1].split('l') : [];
    var isGallery = parts.length >= 6;
    var total = isGallery ? (Number(parts[4]) || 0) : 1;
    var folder = isGallery ? parts[5] : '';
    var id = parts[0] || (u.match(/\/(\d+)\.html/) ? u.match(/\/(\d+)\.html/)[1] : '');
    /* 图集：请求 bmore 接口拿全量图名（一次性，最稳）；失败降级为页面首图 */
    var names = [];
    if (isGallery && id) {
      var raw = '';
      try {
        raw = request(this.host + '/library/bmore.php?id=' + id + '&uid=0', { headers: { 'User-Agent': this.UA, Referer: u, 'Accept-Encoding': 'identity' }, timeout: 15000 }) || '';
      } catch (e0) {}
      try { var j2 = JSON.parse(raw); if (j2.fid && j2.content) names = String(j2.content).split(','); } catch (e1) {}
    }
    var descArr = [], eps = [];
    if (isGallery && names.length) {
      eps.push({
        title: '『图集』共 ' + names.length + ' 张，点击翻图',
        img: first,
        col_type: 'movie_1',
        url: $('hiker://empty#noLoading#').lazyRule(function(folder, names) {
          var arr = String(names || '').split(','), pics = [];
          for (var i = 0; i < arr.length; i++) { if (arr[i]) pics.push('https://file.datuju.net/b/' + folder + arr[i] + '.jpg'); }
          if (!pics.length) return 'toast://图集获取失败，请重试';
          return 'pics://' + pics.join('&&');
        }, folder, names.join(','))
      });
      descArr.push('共 ' + names.length + ' 张');
    } else if (first) {
      eps.push({
        title: '『壁纸』点击查看大图',
        img: first,
        col_type: 'movie_1',
        url: $('hiker://empty#noLoading#').lazyRule(function(pic) { return 'pics://' + pic; }, first)
      });
      descArr.push('高清壁纸');
    } else {
      eps.push({ title: '加载失败，请重试', col_type: 'text_center_1', url: 'hiker://empty' });
      descArr.push('暂无内容');
    }
    /* 专辑标签：点击用 @rule 拉取专题列表页并 setResult 输出列表 */
    var extenditems = [];
    var tagHtml = html.match(/class="tag">([\s\S]*?)<\/div>/i);
    if (tagHtml) {
      var tr = /<a[^>]+href="([^"]+)"[^>]*>([^<]*)<\/a>/gi, tm2, ua = this.UA;
      while ((tm2 = tr.exec(tagHtml[1]))) {
        extenditems.push({
          title: '#our# ' + this._text(tm2[2]),
          col_type: 'flex_button',
          url: $('hiker://empty#noLoading#').rule(function(tu, uag) {
            var h2 = '';
            try { h2 = request(tu, { headers: { 'User-Agent': uag, Referer: 'https://m.datuju.com/', 'Accept-Encoding': 'identity' }, timeout: 15000 }) || ''; } catch (e3) {}
            var out = [], re2 = /<a[^>]+href="([^"]*\/\d+\.html)"[^>]*>\s*<img[^>]+data-src="([^"]+)"[^>]*>\s*<h3>([\s\S]*?)<\/h3>/gi, m2, seen2 = {};
            while ((m2 = re2.exec(h2))) {
              if (seen2[m2[1]]) continue;
              seen2[m2[1]] = 1;
              var t2 = m2[3].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
              if (!t2) continue;
              out.push({ title: t2, img: m2[2], col_type: 'movie_3', url: m2[1] });
            }
            if (!out.length) out.push({ title: '暂无内容', col_type: 'text_center_1', url: 'hiker://empty' });
            setResult(out);
          }, tm2[1], ua)
        });
      }
    }
    var detail1 = "'''''<font color='#b71c1c'><b>" + title + '</b></font>' + (dm ? '<font color=#999999><small>　' + dm[1].trim() + '</small></font>' : '');
    return {
      detail1: detail1,
      desc: descArr.join('，'),
      img: first,
      list: [eps],
      moreitems: [],
      extenditems: extenditems,
      line: [isGallery ? '图集' : '壁纸']
    };
  }
};
