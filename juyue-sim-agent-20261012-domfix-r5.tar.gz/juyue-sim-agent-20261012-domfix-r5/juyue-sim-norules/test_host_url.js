#!/usr/bin/env node
// 对照海阔 8.83 StringUtil.getRealUrl / CommonParser.parsePageClassUrl / UrlDetector.clearTag
const assert = require('assert');
const host = require('./lib/host_url');
const deviceSim = require('./lib/device_sim');

let pass = 0;
function eq(name, actual, expected) {
  assert.strictEqual(actual, expected, name + '\n  actual  = ' + JSON.stringify(actual) + '\n  expected= ' + JSON.stringify(expected));
  pass++;
}

eq('empty', host.getRealUrl(''), '');
eq('null', host.getRealUrl(null), null);
eq('hash-http', host.getRealUrl('hiker://empty#https://a.com/x'), 'https://a.com/x');
eq('hash-hash-http', host.getRealUrl('hiker://empty##https://a.com/x'), 'https://a.com/x');
eq('encoded-https', host.getRealUrl('hiker://empty##https%3A%2F%2Fa.com%2Fx'), 'https://a.com/x');
eq('encoded-http', host.getRealUrl('hiker://empty##http%3A%2F%2Fa.com'), 'http://a.com');
eq('webview', host.getRealUrl('webview://https://a.com/p'), 'https://a.com/p');
eq('dollar', host.getRealUrl('hiker://empty$https://a.com/q'), 'https://a.com/q');
eq('dollar2', host.getRealUrl('hiker://empty$$https://a.com/b'), 'https://a.com/b');
eq('dollar3', host.getRealUrl('hiker://empty$$$https://a.com'), 'https://a.com');
eq('query', host.getRealUrl('hiker://empty?url=https://a.com/q'), 'https://a.com/q');
eq('strip-lazy', host.getRealUrl('https://a.com/v@lazyRule=.js:1'), 'https://a.com/v');
eq('strip-rule-first', host.getRealUrl('https://a.com/v@rule=js:1@lazyRule=.js:2'), 'https://a.com/v');
eq('hash-longest', host.getRealUrl('prefix##https://short.com##https://longer.example/path'), 'https://longer.example/path');
// 已以 http 开头时，$$$ 分段命中整串，不再看 ##
eq('http-wins-before-hash', host.getRealUrl('https://a.com##https://bbb.com'), 'https://a.com##https://bbb.com');
eq('strip-then-http-keeps-hash', host.getRealUrl('hiker://empty##https://a.com##https://bbb.example/z'), 'https://a.com##https://bbb.example/z');

eq('clear-tags', host.clearTag('x5Play://https://a/v.m3u8#isVideo=true##noLoading##threads=8#'), 'https://a/v.m3u8');
eq('threads-two-digits-only', host.clearTag('https://a#threads=123#'), 'https://a#threads=123#');
eq('music-tag', host.clearTag('https://a/s.mp3#isMusic=true#'), 'https://a/s.mp3');

const tpl = 'http://a.com/fypage.html[firstPage=http://a.com/]';
eq('first-page', host.parsePageClassUrl(tpl, 1, { class_url: 'movie' }).url, 'http://a.com/');
eq('second-page', host.parsePageClassUrl(tpl, 2, { class_url: 'movie' }).url, 'http://a.com/2.html');

const fy = 'https://movie.dban.com/j/new_search_subjects?range=0,10&start=fypage@-1@*20@&tags=fyclass';
eq('fy-p1', host.parsePageClassUrl(fy, 1, { class_url: '动作' }).url, 'https://movie.dban.com/j/new_search_subjects?range=0,10&start=0&tags=动作');
eq('fy-p2', host.parsePageClassUrl(fy, 2, { class_url: '动作' }).url, 'https://movie.dban.com/j/new_search_subjects?range=0,10&start=20&tags=动作');
eq('fy-p3', host.parsePageClassUrl(fy, 3, { class_url: '动作' }).url, 'https://movie.dban.com/j/new_search_subjects?range=0,10&start=40&tags=动作');
eq('fyall-area', host.parsePageClassUrl('http://x/fyAll', 2, { class_url: 'c', area_url: 'cn', firstHeader: 'area' }).url, 'http://x/cn');
eq('semi', host.parsePageClassUrl('http://x/fypage;extra', 3, { class_url: '' }).url, 'http://x/3;extra');
const vars = host.parsePageClassUrl('http://x/fyclass', 1, { class_url: 'movie', class_name: '电影' });
eq('var-url', vars.vars.MY_CLASS_URL, 'movie');
eq('var-name', vars.vars.MY_CLASS_NAME, '电影');
eq('no-var-when-empty', Object.keys(host.parsePageClassUrl('http://x/fypage', 1, {}).vars).length, 0);

const joined = 'hiker://empty@lazyRule=.js:"toast://ok" + "@lazyRule=x".slice(0,0)';
const hy = deviceSim.hygieneCheck(joined);
assert.ok(!hy.some((x) => x.indexOf('@lazyRule=') >= 0), '多次 lazyRule 不应再是致命卫生错误: ' + hy.join(';'));
const click = deviceSim.simulateClick(joined, {}, false, 3);
assert.strictEqual(click.ok, true, '拼回后应能执行: ' + (click.issues || []).join(';'));
assert.strictEqual(click.result, 'toast://ok');
pass += 2;

console.log('通过 ' + pass + ' / 失败 0');
