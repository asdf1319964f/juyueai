/**
 * 海阔视界 — 安全图片 Base64 / 双 Base64 解密工具
 *
 * 问题根因（8.82）：
 * 1) base64Decode() 实现是 new String(Base64.decode(s))
 *    - 把二进制当 UTF-16 字符串 → 内存约 2×，且破坏图片字节
 * 2) 规则常见「双 base64」：base64Decode(base64Decode(x))
 *    - 中间结果是损坏的 String，再解码更爆内存
 * 3) convertBase64Image：整文件读入 → encodeToString → data:image;base64,...
 *    - Glide 再解一次 base64 → 峰值内存 ≈ 原图×(1 + 4/3 + 解码位图)
 * 4) fileToBytes 无大小上限，一次 new byte[file.length]
 *
 * 正确做法：全程 byte[] / InputStream，最后返回 InputStream 或 file:// 路径，
 * 禁止把图片内容放进 JS String / data URI（大图）。
 *
 * 用法 A — 图片 @js= 解密（推荐，配合 $.image / url@js=）
 * -------------------------------------------------------
 *   pic_url: $(realUrl, headers).image(() => {
 *     // input 是 Java InputStream（OkHttpStreamFetcher 注入）
 *     return safeImageDecrypt(input, { rounds: 2 }); // 双 base64
 *   })
 *
 * 用法 B — 规则里已有 base64 文本（不要用 base64Decode）
 * -------------------------------------------------------
 *   let path = b64TextToImageFile(s, { rounds: 2, mime: 'image/jpeg' });
 *   // path 形如 file:///.../cache/img_xxx.jpg ，可直接当 pic_url
 *
 * 用法 C — 替换 convertBase64Image（返回 file 路径，不是 data URI）
 * -------------------------------------------------------
 *   let path = convertBase64ImageSafe(url, headers);
 */

(function (global) {
  'use strict';

  var File = java.io.File;
  var FileInputStream = java.io.FileInputStream;
  var FileOutputStream = java.io.FileOutputStream;
  var ByteArrayInputStream = java.io.ByteArrayInputStream;
  var ByteArrayOutputStream = java.io.ByteArrayOutputStream;
  var BufferedInputStream = java.io.BufferedInputStream;

  // 默认硬顶：防止恶意/异常 payload 拖垮进程（可按机型调）
  var DEFAULT_MAX_BYTES = 12 * 1024 * 1024; // 12MB 原始/解码后字节
  var DEFAULT_MAX_B64_CHARS = 16 * 1024 * 1024; // base64 文本字符上限

  function _log(msg) {
    try { log('[safeImageB64] ' + msg); } catch (e) {}
  }

  function _md5name(s) {
    try { return md5(String(s)); } catch (e) {
      return String(java.lang.System.currentTimeMillis());
    }
  }

  function _cachePath(name) {
    // 优先 hiker 缓存目录
    var p = getPath('hiker://files/cache/' + name);
    if (p && p.indexOf('file://') === 0) p = p.substring(7);
    return p;
  }

  /** 从 InputStream 有上限地读成 byte[] */
  function readStreamLimited(is, maxBytes) {
    maxBytes = maxBytes || DEFAULT_MAX_BYTES;
    if (is == null) return null;
    var bos = new ByteArrayOutputStream(Math.min(65536, maxBytes));
    var buf = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 8192);
    var total = 0;
    var n;
    var bis = (is instanceof BufferedInputStream) ? is : new BufferedInputStream(is, 8192);
    while ((n = bis.read(buf)) > 0) {
      total += n;
      if (total > maxBytes) {
        throw new Error('image stream exceeds maxBytes=' + maxBytes);
      }
      bos.write(buf, 0, n);
    }
    return bos.toByteArray();
  }

  /**
   * 在 byte[] 上做 N 轮 base64 解码（真正的「双 base64」安全路径）
   * - 第 1 轮：payload 是 base64 文本的 UTF-8 字节
   * - 第 2 轮：上一轮输出仍是 base64 文本字节，再解成图片二进制
   */
  function decodeB64BytesRounds(bytes, rounds, maxBytes) {
    rounds = rounds == null ? 1 : rounds;
    maxBytes = maxBytes || DEFAULT_MAX_BYTES;
    if (bytes == null) return null;
    if (bytes.length > maxBytes) {
      throw new Error('payload too large: ' + bytes.length);
    }
    var cur = bytes;
    var i;
    for (i = 0; i < rounds; i++) {
      // 使用 _base64.decode(byte[], flags) — 绝不走 base64Decode(String)
      var next = _base64.decode(cur, _base64.NO_WRAP);
      if (next == null || next.length === 0) {
        // 容错：DEFAULT / URL_SAFE
        try { next = _base64.decode(cur, _base64.DEFAULT); } catch (e1) {}
        if (next == null || next.length === 0) {
          try { next = _base64.decode(cur, _base64.URL_SAFE); } catch (e2) {}
        }
      }
      if (next == null || next.length === 0) {
        throw new Error('base64 decode failed at round ' + (i + 1));
      }
      if (next.length > maxBytes) {
        throw new Error('decoded size exceeds max at round ' + (i + 1) + ': ' + next.length);
      }
      cur = next;
    }
    return cur;
  }

  /**
   * 从 base64 文本（JS String，仅 ASCII）解码 N 轮 → 图片 byte[]
   * 注意：入参是 base64 字符，不是图片二进制被错误 new String 的结果
   */
  function decodeB64TextRounds(b64Text, rounds, maxBytes) {
    if (b64Text == null) return null;
    var s = String(b64Text).replace(/\s+/g, '');
    // 去掉 data URI 前缀
    var idx = s.indexOf('base64,');
    if (idx >= 0) s = s.substring(idx + 7);
    if (s.length > (DEFAULT_MAX_B64_CHARS)) {
      throw new Error('base64 text too long: ' + s.length);
    }
    // 只把 ASCII base64 文本转 UTF-8 字节（体积≈字符数），再进入 byte 路径
    var raw = new java.lang.String(s).getBytes('UTF-8');
    return decodeB64BytesRounds(raw, rounds, maxBytes);
  }

  /** 写缓存文件，返回绝对路径（无 file:// 前缀） */
  function writeImageFile(bytes, ext) {
    ext = ext || 'jpg';
    var name = 'img_' + _md5name(String(bytes.length) + '_' + java.lang.System.nanoTime()) + '.' + ext;
    var path = _cachePath(name);
    var f = new File(path);
    var parent = f.getParentFile();
    if (parent != null && !parent.exists()) parent.mkdirs();
    var fos = new FileOutputStream(f);
    try {
      fos.write(bytes);
      fos.flush();
    } finally {
      try { fos.close(); } catch (e) {}
    }
    return path;
  }

  /**
   * 图片 @js= 解密主入口
   * @param input  Java InputStream（Glide OkHttpStreamFetcher 注入）或 byte[]/base64 文本
   * @param opt.rounds  base64 轮数，双 base64 传 2
   * @param opt.maxBytes  上限
   * @param opt.asFile    true 则写文件并返回 FileInputStream（大图更稳）
   * @param opt.ext       文件后缀
   * @returns InputStream  给 OkHttpStreamFetcher / Glide
   */
  function safeImageDecrypt(input, opt) {
    opt = opt || {};
    var rounds = opt.rounds != null ? opt.rounds : 1;
    var maxBytes = opt.maxBytes || DEFAULT_MAX_BYTES;
    var asFile = opt.asFile !== false; // 默认写文件，避免巨型 ByteArray 常驻
    var ext = opt.ext || 'jpg';

    var bytes;
    if (input == null) {
      throw new Error('input is null');
    }

    // InputStream
    if (typeof input.read === 'function' || (input.getClass && String(input.getClass().getName()).indexOf('InputStream') >= 0)) {
      bytes = readStreamLimited(input, maxBytes);
      // 常见：响应体本身就是 base64 文本（单/双）
      // 若看起来像 base64 文本（高比例 ASCII），按文本轮解；否则当已是图片二进制
      if (opt.forceB64 || _looksLikeBase64(bytes)) {
        bytes = decodeB64BytesRounds(bytes, rounds, maxBytes);
      } else if (rounds > 1) {
        // 调用方明确要多轮，即使不像也解
        bytes = decodeB64BytesRounds(bytes, rounds, maxBytes);
      }
    } else if (typeof input === 'string' || (input.getClass && String(input.getClass().getName()) === 'java.lang.String')) {
      bytes = decodeB64TextRounds(String(input), rounds, maxBytes);
    } else {
      // 假定已是 byte[]
      bytes = input;
      if (opt.forceB64 || rounds > 0) {
        bytes = decodeB64BytesRounds(bytes, rounds, maxBytes);
      }
    }

    if (asFile) {
      var path = writeImageFile(bytes, ext);
      return new FileInputStream(path);
    }
    return new ByteArrayInputStream(bytes);
  }

  function _looksLikeBase64(bytes) {
    if (bytes == null || bytes.length < 16) return false;
    // 采样前 64 字节
    var n = Math.min(64, bytes.length);
    var ok = 0;
    var i;
    for (i = 0; i < n; i++) {
      var c = bytes[i] & 0xff;
      if ((c >= 0x41 && c <= 0x5a) || (c >= 0x61 && c <= 0x7a) ||
          (c >= 0x30 && c <= 0x39) || c === 0x2b || c === 0x2f || c === 0x3d ||
          c === 0x0a || c === 0x0d || c === 0x20) ok++;
    }
    return (ok / n) > 0.9;
  }

  /** base64 文本 → 本地图片路径（file://...），适合当 pic_url */
  function b64TextToImageFile(b64Text, opt) {
    opt = opt || {};
    var bytes = decodeB64TextRounds(b64Text, opt.rounds != null ? opt.rounds : 1, opt.maxBytes);
    var path = writeImageFile(bytes, opt.ext || 'jpg');
    return 'file://' + path;
  }

  /**
   * 替代官方 convertBase64Image
   * 原实现：download → fileToBytes 全量 → base64 字符串 → data:image;base64（OOM 重灾区）
   * 新实现：download 到唯一缓存文件 → 直接返回 file:// 路径（Glide 原生读文件，不再二次 base64）
   */
  function convertBase64ImageSafe(url, headers, opt) {
    opt = opt || {};
    var ext = opt.ext || 'jpg';
    var name = 'cbi_' + _md5name(String(url)) + '.' + ext;
    var path = _cachePath(name);
    var f = new File(path);
    if (!f.exists() || f.length() === 0) {
      downloadFile(url, 'hiker://files/cache/' + name, headers || {});
    }
    // 可选：若下载的其实是 base64 文本文件，再解 N 轮写回
    if (opt.rounds && opt.rounds > 0) {
      var raw = readStreamLimited(new FileInputStream(path), opt.maxBytes || DEFAULT_MAX_BYTES);
      if (_looksLikeBase64(raw) || opt.forceB64) {
        var img = decodeB64BytesRounds(raw, opt.rounds, opt.maxBytes || DEFAULT_MAX_BYTES);
        writeImageFileTo(path, img);
      }
    }
    return 'file://' + path;
  }

  function writeImageFileTo(path, bytes) {
    var fos = new FileOutputStream(path);
    try { fos.write(bytes); fos.flush(); }
    finally { try { fos.close(); } catch (e) {} }
  }

  // 导出
  global.safeImageDecrypt = safeImageDecrypt;
  global.b64TextToImageFile = b64TextToImageFile;
  global.convertBase64ImageSafe = convertBase64ImageSafe;
  global.decodeB64TextRounds = decodeB64TextRounds;
  global.decodeB64BytesRounds = decodeB64BytesRounds;

  // 兼容：若存在 convertBase64Image，可选择覆盖
  // global.convertBase64Image = convertBase64ImageSafe;

})(this);
