#!/usr/bin/env node
/**
 * JuYue generic rule sandbox CLI
 *
 * Usage:
 *   node run.js <rule.js> --all-cats
 *   node run.js <rule.js> --cat hjll --page 1
 *   node run.js <rule.js> --detail https://...
 *   node run.js <rule.js> --ui --assert
 *   node run.js <rule.js> --cf
 *   node run.js --cf-url https://example.com
 */
const fs = require('fs');
const path = require('path');
const {
  createSandbox,
  loadRule,
  summarize,
  getClassPairs,
  runHome,
  runDetailFromListItem,
  assertBasic,
  writeUiReport
} = require('./lib/engine');
const deviceSim = require('./lib/device_sim');
const hostUrl = require('./lib/host_url');
const appConsume = require('./lib/app_consume');
const riskAudit = require('./lib/risk_audit');
const tdaStd = require('./lib/true_device_audit');
const { execPicUrl } = require('./lib/real_sim');

function parseArgs(argv) {
  const args = {
    rule: null,
    allCats: false,
    cat: null,
    page: 1,
    detail: null,
    ui: false,
    assert: false,
    verbose: false,
    out: null,
    limit: 5,
    cf: false,
    cfUrl: null,
    device: false,
    resolveImages: false
  };
  const a = argv.slice(2);
  if (!a.length) return args;
  // allow: node run.js --cf-url URL  (no rule)
  if (a[0] === '--cf-url' || a[0] === '--help' || a[0] === '-h') {
    // fallthrough without rule
  } else if (!a[0].startsWith('--')) {
    args.rule = a[0];
  }
  for (let i = args.rule ? 1 : 0; i < a.length; i++) {
    const k = a[i];
    if (k === '--all-cats') args.allCats = true;
    else if (k === '--cat') args.cat = a[++i];
    else if (k === '--page') args.page = parseInt(a[++i], 10) || 1;
    else if (k === '--detail') args.detail = a[++i];
    else if (k === '--ui') args.ui = true;
    else if (k === '--assert') args.assert = true;
    else if (k === '--verbose') args.verbose = true;
    else if (k === '--out') args.out = a[++i];
    else if (k === '--limit') args.limit = parseInt(a[++i], 10) || 5;
    else if (k === '--device') args.device = true;
    else if (k === '--resolve-images') args.resolveImages = true;
    else if (k === '--cf') args.cf = true;
    else if (k === '--cf-url') {
      args.cf = true;
      args.cfUrl = a[++i];
    } else if (k === '-h' || k === '--help') {
      args.help = true;
    } else if (!args.rule && !k.startsWith('--')) {
      args.rule = k;
    }
  }
  return args;
}

function printHelp() {
  console.log(`JuYue Sandbox

Usage:
  node run.js <rule.js> --all-cats --ui --assert --detail auto
  node run.js <rule.js> --cat <MY_URL> [--page N]
  node run.js <rule.js> --cf
  node run.js --cf-url https://example.com

Options:
  --all-cats     Test every static category
  --cat X        Test one category MY_URL value
  --page N       Page number (default 1)
  --detail URL   Execute detail rule for URL (or first list item / auto)
  --ui           Write HTML UI simulation reports
  --assert       Fail on empty list / obvious issues
  --device       Device-accurate click simulation (lazyRule/rule URL pipeline)
  --cf           CF diagnose host (request vs WebView)
  --cf-url URL   CF diagnose arbitrary URL (rule optional)
  --resolve-images Resolve @js/@image encrypted covers to data: URLs in UI reports
  --out DIR      Report directory
  --verbose      Print rule logs
`);
}

function stripPicUrl(pic) {
  const s = String(pic || '');
  const marks = ['@headers=', '@image=js:', '@js=', '[image]'];
  let min = -1;
  for (const mk of marks) {
    const i = s.indexOf(mk);
    if (i >= 0 && (min < 0 || i < min)) min = i;
  }
  return min >= 0 ? s.substring(0, min) : s;
}

async function resolvePreviewPic(sandbox, picUrl, issues, tag) {
  if (!picUrl) return picUrl || '';
  const s = String(picUrl);
  const hasTransform = s.indexOf('@js=') >= 0 || s.indexOf('@image=js:') >= 0;
  const isHttp = /^https?:/i.test(s);
  if (!hasTransform && s.indexOf('@headers=') < 0 && !isHttp) return s;
  try {
    const r = await execPicUrl(sandbox, s);
    if (r.ok && r.bytes && r.bytes.length && ['JPEG', 'PNG', 'WEBP', 'GIF'].includes(r.format)) {
      const mime = r.format === 'JPEG' ? 'image/jpeg' : r.format === 'PNG' ? 'image/png' : r.format === 'GIF' ? 'image/gif' : 'image/webp';
      return 'data:' + mime + ';base64,' + r.bytes.toString('base64');
    }
    if ((hasTransform || isHttp) && Array.isArray(issues)) {
      issues.push((tag || 'image') + ': 图片不可解码，输出=' + String((r && (r.format || r.error)) || 'empty') + (hasTransform ? '' : '（可能是加密图片但缺少 image 回调）'));
    }
  } catch (e) {
    if ((hasTransform || isHttp) && Array.isArray(issues)) issues.push((tag || 'image') + ': 图片处理异常: ' + e.message);
  }
  return stripPicUrl(s) || s;
}

async function buildPreview(list, sandbox, resolve, issues, tag) {
  const arr = Array.isArray(list) ? list : [];
  const out = [];
  for (let idx = 0; idx < arr.length; idx++) {
    const it = arr[idx];
    const o = Object.assign({}, it);
    for (const field of ['pic_url', 'img']) {
      if (!o[field]) continue;
      const origPic = String(o[field]);
      o[field] = resolve ? await resolvePreviewPic(sandbox, origPic, issues, (tag || 'image') + '[' + idx + '].' + field) : stripPicUrl(origPic);
    }
    if (o.url && o.url.toString) o.url = o.url.toString();
    out.push(o);
  }
  return out;
}

function printCf(report) {
  if (!report) {
    console.log('[CF] no report');
    return;
  }
  console.log('\n[CF DIAGNOSE]');
  console.log('  url       ', report.url);
  console.log('  final     ', report.finalUrl || '');
  console.log('  title     ', report.title || '');
  console.log('  request   ', report.request && report.request.summary);
  console.log('  webview   ', report.webview && report.webview.summary);
  console.log('  improved  ', !!report.improved);
  console.log('  blocked   ', !!report.stillBlocked);
  console.log('  cookies   ', report.cookies && report.cookies.names && report.cookies.names.join(','));
  console.log('  clearance ', report.cookies && report.cookies.has_cf_clearance);
  console.log('  advice    ', (report.webview && report.webview.advice) || []);
  console.log('  recommend ', report.recommendation);
}

async function main() {
  const args = parseArgs(process.argv);
  if (args.help || ((!args.rule && !args.cfUrl) && !args.cf)) {
    printHelp();
    process.exit(args.help ? 0 : 1);
  }

  // standalone CF URL mode
  if (args.cf && args.cfUrl && !args.rule) {
    const outDir = path.resolve(args.out || path.join(__dirname, 'reports', 'cf_' + Date.now()));
    fs.mkdirSync(outDir, { recursive: true });
    const { sandbox } = createSandbox({
      workdir: path.join(outDir, 'runtime'),
      verbose: args.verbose
    });
    console.log('CF_URL', args.cfUrl);
    const rep = sandbox.diagnoseCf(args.cfUrl, { timeout: 30000, ua: 'x5' });
    printCf(rep);
    const f = path.join(outDir, 'cf_report.json');
    fs.writeFileSync(f, JSON.stringify(rep, null, 2));
    console.log('REPORT', f);
    process.exit(rep.stillBlocked ? 3 : 0);
  }

  const rulePath = path.resolve(args.rule);
  if (!fs.existsSync(rulePath)) {
    console.error('rule not found:', rulePath);
    process.exit(2);
  }

  const outDir = path.resolve(
    args.out || path.join(__dirname, 'reports', path.basename(rulePath, '.js') + '_' + Date.now())
  );
  fs.mkdirSync(outDir, { recursive: true });

  const { sandbox, workdir, logs } = createSandbox({
    workdir: path.join(outDir, 'runtime'),
    verbose: args.verbose
  });
  const parse = loadRule(rulePath, sandbox);
  const report = {
    rule: rulePath,
    host: parse.host || '',
    static: parse.静态分类 || null,
    workdir,
    results: [],
    issues: [],
    logs,
    cf: null
  };

  console.log('RULE', rulePath);
  console.log('HOST', parse.host || '');
  console.log('STATIC', parse.静态分类 || {});

  // 真机风险审计（作用域泄漏/gzip/超时/回调API/头尾巴）
  const riskIssues = riskAudit.auditRule(rulePath);
  const riskFatal = (riskIssues || []).filter((x) => x.kind === 'callback_api' || x.kind === 'slow_html' || x.kind === 'scope_leak' || x.kind === 'syntax');
  const riskAdvice = (riskIssues || []).filter((x) => x.kind !== 'callback_api' && x.kind !== 'slow_html' && x.kind !== 'scope_leak' && x.kind !== 'syntax');
  if (riskIssues.length) {
    report.riskIssues = riskIssues;
    console.log('  [RISK] ' + riskIssues.length + ' 项真机风险提示（' + riskFatal.length + ' 致命/' + riskAdvice.length + ' 建议）:');
    for (const ri of riskIssues) {
      console.log('    - [' + ri.kind + '] ' + ri.msg);
    }
  } else {
    console.log('  [RISK] 真机风险审计 0 问题');
  }

  if (typeof parse._getHost === 'function') {
    try {
      report.resolvedHost = parse._getHost();
      console.log('RESOLVED_HOST', report.resolvedHost);
    } catch (e) {
      report.issues.push(' _getHost failed: ' + e.message);
    }
  }

  // CF diagnose
  if (args.cf || args.cfUrl) {
    const target =
      args.cfUrl ||
      report.resolvedHost ||
      parse.host ||
      '';
    if (target) {
      try {
        const cfRep = sandbox.diagnoseCf(target, { timeout: 30000, ua: 'x5' });
        report.cf = cfRep;
        printCf(cfRep);
        fs.writeFileSync(path.join(outDir, 'cf_report.json'), JSON.stringify(cfRep, null, 2));
      } catch (e) {
        console.log('[CF] ERR', e.message);
        report.issues.push('cf: ' + e.message);
      }
    } else {
      console.log('[CF] no host/url to probe');
    }
  }

  // If only CF was requested with rule, still allow continuing list tests when other flags set
  const doLists = args.allCats || args.cat != null || (!args.cf && !args.cfUrl) || args.detail || args.ui || args.assert;
  const doDevice = args.device || args.allCats;
  if (!doLists && (args.cf || args.cfUrl)) {
    const reportFile = path.join(outDir, 'report.json');
    fs.writeFileSync(reportFile, JSON.stringify(report, null, 2));
    if (report.deviceIssues && report.deviceIssues.length) {
    const fatalDevs = report.deviceIssues.filter(x => !x.includes('[warn]'));
    report.issues.push(...fatalDevs);
  }
  console.log('\nREPORT', reportFile);
    console.log(report.cf && report.cf.stillBlocked ? 'ISSUES 1 (cf blocked)' : 'ISSUES 0');
    process.exit(report.cf && report.cf.stillBlocked && args.assert ? 1 : 0);
  }

  const deviceBase = {
    fetch: (u, o) => { try { return sandbox.fetch(u, o); } catch (e) { return ''; } },
    request: (u, o) => { try { return sandbox.request(u, o); } catch (e) { return ''; } },
    post: (u, o) => { try { return sandbox.post(u, o); } catch (e) { return ''; } },
    md5: require('crypto').createHash.bind(null, 'md5'),
    base64Encode: (x) => Buffer.from(String(x), 'utf8').toString('base64'),
    base64Decode: (x) => Buffer.from(String(x), 'base64').toString('utf8'),
    // 原生 dex/so：回调独立上下文也要有（真机同理）
    loadJavaClass: (...a) => sandbox.loadJavaClass.apply(null, a),
    findJavaClass: (...a) => sandbox.findJavaClass.apply(null, a),
    getCpuAbi: () => sandbox.getCpuAbi(),
    requireDownload: (...a) => sandbox.requireDownload.apply(null, a),
    downloadFile: (...a) => sandbox.downloadFile.apply(null, a),
    org: (sandbox.org || {}),
  };
  // lazyRule/rule 链接仿真（独立上下文）
  function deviceAudit(list, tag, budget) {
    if (!doDevice) return;
    const issues = [];
    const b = { used: 0, max: budget || 6 };
    deviceSim.auditItems(list, deviceBase, 2, issues, b);
    if (issues.length) {
      report.deviceIssues = report.deviceIssues || [];
      for (const i of issues) report.deviceIssues.push(tag + ': ' + i);
      console.log('  [DEVICE] ' + issues.length + ' 个问题:');
      for (const i of issues) console.log('    -', i);
    } else {
      console.log('  [DEVICE] 点击仿真 ' + b.used + ' 次，0 问题');
    }
  }
  // 标准规则仿真：纯 URL 列表项 → 二级(url)（规则上下文）→ 校验结构 → list 项 → 解析(url)
  function deviceAuditStandard(list, tag, budget) {
    if (!doDevice) return;
    if (typeof parse['二级'] !== 'function') return;
    const issues = [];
    let used = 0;
    const max = budget || 6;
    let chapUsed = 0;
    const chapMax = 8;      // 每个二级页最多抽查这么多章去跑 解析()，防止超长章节目录拖死整个门禁
    let chapCapped = false;
    function walk(items, depth) {
      if (depth <= 0 || !Array.isArray(items)) return;
      for (const it of items) {
        if (used >= max) return;
        if (!it || !it.url || typeof it.url !== 'string') continue;
        const u = it.url;
        if (!/^https?:\/\//.test(u)) continue;
        if (u.indexOf('@lazyRule=') > -1 || u.indexOf('@rule=') > -1) continue;
        used++;
        const d = parse['二级'].call(parse, u);
        if (!d || typeof d !== 'object' || Array.isArray(d)) { issues.push('[' + String(it.title || '?').slice(0, 24) + '] 标准二级必须返回对象，实际=' + (Array.isArray(d) ? '数组' : typeof d)); continue; }
        const structural = [];
        if (!deviceSim.validateDetailObject(d, structural)) structural.push('不是 detail1/line/list 标准二级对象');
        for (const si of structural) issues.push('[' + String(it.title || '?').slice(0, 24) + '] ' + si);
        if (d.detail1 == null && (!d.list || !d.list.length) && (!d.extenditems || !d.extenditems.length)) {
          issues.push('[' + String(it.title || '?').slice(0, 24) + '] 二级结构异常(无 detail1/list/extenditems)');
        }
        // list 选集 → 解析(url)
        const lists = Array.isArray(d.list) && d.list.length && Array.isArray(d.list[0]) ? d.list : [d.list];
        const hasParser = typeof parse['解析'] === 'function';
        for (const l of lists) {
          if (!Array.isArray(l)) continue;
          for (const ep of l) {
            /* 章节目录可能极长（rouman v2 实测有 320 章的书），而每个选集都会真的
               发一次 解析(url) 网络请求。原来的循环没有上限，一本 320 章的书就要跑
               320 次同步 curl（约 10 分钟），加上 --all-cats × 多本书会失控到几十分钟，
               表现为「框架卡死」。这里给样本量封顶：只抽查前 chapMax 章。 */
            if (chapUsed >= chapMax) { chapCapped = true; break; }
            if (!ep || !ep.url) { issues.push('[' + String(it.title || '?').slice(0, 24) + '] 选集缺 url'); continue; }
            chapUsed++;
            if (!hasParser) {
              const su = typeof ep.url === 'string' ? ep.url : String(ep.url);
              if (!/^(video|toast|hiker):\/\//.test(su) && su.indexOf('@lazyRule=') === -1) {
                issues.push('[' + String(it.title || '?').slice(0, 24) + '] 无解析函数且选集非直链: ' + su.slice(0, 50));
              }
              continue;
            }
            const pv = parse['解析'].call(parse, ep.url);
            const pvIssues = [];
            if (typeof pv !== 'string' || !tdaStd.acceptedScheme(pv)) {
              issues.push('[' + String(it.title || '?').slice(0, 24) + '] 解析返回异常: ' + String(pv).slice(0, 60));
            } else if (!deviceSim.validateRoutedUrl(pv, pvIssues)) {
              for (const pi of pvIssues) issues.push('[' + String(it.title || '?').slice(0, 24) + '] ' + pi);
            }
          }
        }
        // extenditems 纯 URL → 递归二级（深度1）
        if (Array.isArray(d.extenditems)) walk(d.extenditems, depth - 1);
      }
    }
    walk(list, 2);
    if (issues.length) {
      report.deviceIssues = report.deviceIssues || [];
      for (const i of issues) report.deviceIssues.push(tag + ': ' + i);
      console.log('  [DEVICE-标准二级] ' + issues.length + ' 个问题:');
      for (const i of issues) console.log('    -', i);
    } else if (used > 0) {
      console.log('  [DEVICE-标准二级] 二级/解析仿真 ' + used + ' 次，0 问题' +
        (chapCapped ? '（选集只抽查前 ' + chapMax + ' 章，已截断）' : ''));
    }
  }

  const pairs = getClassPairs(parse);
  const runList = [];
  if (args.allCats) runList.push(...pairs);
  else if (args.cat != null) runList.push({ name: args.cat || 'custom', cls: args.cat });
  else runList.push(pairs[0] || { name: 'home', cls: '' });

  for (const p of runList) {
    const name = p.name;
    const cls = p.cls;
    process.stdout.write(`\n[CAT] ${name} | MY_URL=${JSON.stringify(cls)} ... `);
    let list;
    try {
      list = await runHome(parse, sandbox, cls, args.page);
    } catch (e) {
      console.log('ERR', e.message);
      report.results.push({ name, cls, error: String(e.stack || e) });
      report.issues.push(`${name}: ${e.message}`);
      continue;
    }
    const sum = summarize(list);
    console.log(`n=${sum.n}`);
    if (sum.sample[0]) {
      const rawUrl = String(sum.sample[0].url || '');
      const expandedUrl = String(hostUrl.getRealUrl(rawUrl) || '');
      console.log('  first:', sum.sample[0].title, '|', rawUrl);
      if (expandedUrl && expandedUrl !== rawUrl) console.log('  expanded:', expandedUrl);
    }
    const issues = args.assert ? assertBasic(list, name) : [];
    try {
      const tda = require('./lib/true_device_audit');
      const extra = tda.auditListItems(list, name);
      for (const it of extra) {
        if (it.kind === 'url_scheme') issues.push(it.msg);
        else {
          report.deviceWarns = report.deviceWarns || [];
          report.deviceWarns.push(it.msg);
        }
      }
    } catch (eT) {}
    if (issues.length) {
      report.issues.push(...issues);
      console.log('  ASSERT', issues.join('; '));
    }
    let uiFile = null;
    if (args.resolveImages && !args.ui) {
      await buildPreview(list, sandbox, true, report.issues, name);
    }
    if (args.ui) {
      uiFile = path.join(outDir, `ui_${String(name).replace(/[^\w\u4e00-\u9fa5.-]+/g, '_') || 'home'}.html`);
      const preview = await buildPreview(list, sandbox, args.resolveImages, report.issues, name);
      writeUiReport(uiFile, `${name}`, preview, { url: cls });
      console.log('  UI', uiFile);
    }
    deviceAudit(list, name, 6);
    deviceAuditStandard(list, name, 6);
    // 原生 dex/so 调用汇总（形状桥：只证明调用链通，返回值可信度另说）
    if (sandbox.__nativeBridge && sandbox.__nativeBridge.calls.length) {
      const nb = sandbox.__nativeBridge;
      const stubs = nb.calls.filter((c) => c.stub);
      const uniqCls = [];
      for (const l of nb.loaded) if (uniqCls.indexOf(l.cls) < 0) uniqCls.push(l.cls);
      console.log('  [NATIVE] ' + nb.calls.length + ' 次原生调用 / ' + uniqCls.length + ' 个类（' + stubs.length + ' 次返回占位串，' +
        (nb.calls.length - stubs.length) + ' 次命中 fixture）mode=' + nb.mode + ' abi=' + nb.abi);
      for (const l of nb.loaded) {
        const flags = [];
        if (l.dex) flags.push(l.dexExists ? (l.dexMagic ? 'dex✓' : 'dex✗(不是dex文件)') : 'dex✗(未下载)');
        if (l.so) {
          if (l.soKind === 'dir') flags.push('so目录(' + (l.soFiles || 0) + ' 个 .so)');
          else if (!l.soExists) flags.push('so✗(不存在)');
          else flags.push(l.soMagic ? 'so✓' : 'so✗(不是ELF)');
        }
        const bad = flags.filter((f) => f.indexOf('✗') > -1);
        console.log('    · ' + l.cls + '  [' + flags.join(' ') + ']' + (bad.length ? '  ← 真机会加载失败' : ''));
      }
      if (stubs.length) {
        report.nativeStubs = report.nativeStubs || [];
        for (const c of stubs.slice(0, 5)) report.nativeStubs.push(c.cls + '#' + c.method);
        console.log('    - 占位调用: ' + stubs.slice(0, 5).map((c) => c.cls + '#' + c.method).join(', '));
        console.log('    - 补真值: 在 ' + nb.fixtureDir + ' 下新建 <全限定类名>.json，内容 {"方法名":"真机返回值"}');
        console.log('      （查找顺序: JUYUE_NATIVE_FIXTURES → cwd/native → <out>/runtime/native）');
      }
    }
    // App 消费模型审计：id 列表项 → 二级消费（线路提取/可点性/回调执行）+ 翻页
    if (doDevice && typeof parse['二级'] === 'function') {
      const issues2 = [];
      const b2 = { used: 0, max: 6 };
      const realItems = (Array.isArray(list) ? list : []).filter(
        (it) => it && it.url && typeof it.url === 'string' && !/^https?:\/\//.test(it.url) && !/@lazyRule=|@rule=/.test(it.url)
      );
      for (const it of realItems.slice(0, 3)) {
        appConsume.auditDetailConsume(parse, it.url, deviceBase, '[' + String(it.title || '?').slice(0, 12) + ']', issues2, b2);
      }
      if (issues2.length) {
        report.deviceIssues = report.deviceIssues || [];
        for (const i of issues2) report.deviceIssues.push(name + ': ' + i);
        const core = issues2.filter((x) => x.indexOf('[海阔核心]') >= 0);
        const tmpl = issues2.filter((x) => x.indexOf('[聚阅模板]') >= 0);
        const other = issues2.filter((x) => x.indexOf('[海阔核心]') < 0 && x.indexOf('[聚阅模板]') < 0);
        console.log('  [APP消费] ' + issues2.length + ' 个问题（海阔核心 ' + core.length + ' / 聚阅模板 ' + tmpl.length + '）:');
        for (const i of core.concat(tmpl, other)) console.log('    -', i);
      } else {
        console.log('  [APP消费] 二级消费仿真 ' + b2.used + ' 次，0 问题');
      }
      // 翻页审计
      const issues3 = [];
      appConsume.auditPaging(parse, sandbox, cls, name, issues3, 2);
      if (issues3.length) {
        report.deviceIssues = report.deviceIssues || [];
        for (const i of issues3) report.deviceIssues.push(name + ': ' + i);
        console.log('  [翻页] ' + issues3.length + ' 个问题:');
        for (const i of issues3) console.log('    -', i);
      } else {
        console.log('  [翻页] 宿主翻页展开 2 页，0 问题 | ' + cls + ' → ' + appConsume.realMyUrl(cls, 2, 0, parse));
      }
    }
    report.results.push({ name, cls, page: args.page, summary: sum, ui: uiFile });
  }

  if (args.detail || args.allCats) {
    console.log('\n[DETAIL]');
    let detailUrl = args.detail && args.detail !== 'auto' ? args.detail : null;
    let item = null;
    for (let i = report.results.length - 1; i >= 0; i--) {
      const r = report.results[i];
      if (r && r.summary && r.summary.sample && r.summary.sample.length) {
        const list = await runHome(parse, sandbox, r.cls, 1);
        // prefer real content: movie_/pic_/rule/lazy with http — skip matrix buttons
        item =
          (list || []).find(
            (x) =>
              x &&
              x.url &&
              typeof x.url._ruleFn === 'function' &&
              String(x.col_type || '').indexOf('scroll') < 0
          ) ||
          (list || []).find(
            (x) =>
              x &&
              x.url &&
              typeof x.url._lazyFn === 'function' &&
              /movie|pic|video/i.test(String(x.col_type || '')) &&
              String(x.url).indexOf('#noLoading#') < 0
          ) ||
          (list || []).find(
            (x) => x && x.url && (typeof x.url._ruleFn === 'function' || typeof x.url._lazyFn === 'function')
          ) ||
          (list || []).find((x) => x && x.url && (x.url.execRule || x.url.execLazy)) ||
          (list || [])[0];
        if (!detailUrl && item && item.url && item.url.url) detailUrl = item.url.url;
        break;
      }
    }
    if (detailUrl && parse._detailRule) {
      try {
        const chain = parse._detailRule(detailUrl);
        item = { title: detailUrl, url: chain };
      } catch (e) {
        report.issues.push('detail create failed: ' + e.message);
      }
    }
    // diyichigua style: raw archives url + 二级
    if (item && item.url && !item.url.execRule && !item.url.execLazy && typeof parse.二级 === 'function') {
      try {
        const rawUrl = typeof item.url === 'string' ? item.url : item.url.toString();
        if (/archives|http/i.test(rawUrl)) {
          const d2 = parse.二级(rawUrl);
          // normalize extenditems as list-like
          const arr = [];
          if (d2 && d2.vod_name) arr.push({ title: '『' + d2.vod_name + '』', col_type: 'rich_text' });
          if (d2 && Array.isArray(d2.list)) {
            d2.list.forEach((line) => {
              (line || []).forEach((ep) => arr.push(ep));
            });
          }
          if (d2 && Array.isArray(d2.extenditems)) arr.push(...d2.extenditems);
          try {
            const tda = require('./lib/true_device_audit');
            const ds = tda.auditDetailShape(d2, 'DETAIL');
            if (ds.length) {
              report.deviceWarns = report.deviceWarns || [];
              for (const w of ds) report.deviceWarns.push(w.msg);
            }
          } catch (eDs) {}
          console.log('  type 二级');
          const sum = summarize(arr);
          console.log('  n', sum.n, 'cols', sum.cols);
          (sum.sample || []).slice(0, 8).forEach((s, idx) => {
            console.log(`   ${idx}. [${s.col}] ${String(s.title || '').slice(0, 60)}`);
          });
          // play first lazy
          const play = arr.find((x) => x && x.url && x.url.execLazy);
          if (play) {
            try {
              const out = await play.url.execLazy();
              console.log('  PLAY', String(out).slice(0, 180));
              report.play = String(out).slice(0, 500);
            } catch (e) {
              console.log('  PLAY ERR', e.message);
            }
          }
          report.detail = sum;
          if (args.ui) {
            const uiFile = path.join(outDir, 'ui_detail.html');
            const preview2 = await buildPreview(arr, sandbox, args.resolveImages, report.issues, 'DETAIL');
            writeUiReport(
              uiFile,
              'DETAIL',
              preview2,
              { url: rawUrl }
            );
            console.log('  UI', uiFile);
          }
          item = null; // done
        }
      } catch (e) {
        console.log('  二级 ERR', e.message);
      }
    }
    if (item) {
      try {
        const dres = await runDetailFromListItem(item);
        console.log('  type', dres.type);
        if (dres.summary) {
          console.log('  n', dres.summary.n, 'cols', dres.summary.cols);
          (dres.summary.sample || []).slice(0, 12).forEach((s, idx) => {
            console.log(`   ${idx}. [${s.col}] ${String(s.title || '').slice(0, 60)}`);
          });
        } else {
          console.log('  data', String(dres.data).slice(0, 200));
        }
        if (args.ui && dres.data && Array.isArray(dres.data)) {
          const uiFile = path.join(outDir, 'ui_detail.html');
          const preview = await buildPreview(dres.data, sandbox, args.resolveImages, report.issues, 'DETAIL');
          writeUiReport(uiFile, 'DETAIL', preview, { url: detailUrl || '' });
          console.log('  UI', uiFile);
          report.detailUi = uiFile;
        }
        if (Array.isArray(dres.data)) {
          const play = dres.data.find((x) => x && x.url && x.url.execLazy);
          if (play) {
            try {
              const out = await play.url.execLazy();
              console.log('  PLAY', String(out).slice(0, 180));
              report.play = String(out).slice(0, 500);
            } catch (e) {
              console.log('  PLAY ERR', e.message);
              report.issues.push('play: ' + e.message);
            }
          }
        } else if (dres.type === 'lazy') {
          console.log('  PLAY', String(dres.data).slice(0, 180));
          report.play = String(dres.data).slice(0, 500);
        }
        report.detail = dres.summary || { data: String(dres.data).slice(0, 300) };
      } catch (e) {
        console.log('  DETAIL ERR', e.stack || e);
        report.issues.push('detail: ' + e.message);
      }
    } else if (!report.detail) {
      console.log('  no detail item');
    }
  }

  const reportFile = path.join(outDir, 'report.json');
  fs.writeFileSync(reportFile, JSON.stringify(report, null, 2));
  if (report.deviceIssues && report.deviceIssues.length) {
    const fatalDevs = report.deviceIssues.filter(x => !x.includes('[warn]'));
    const warnDevs = report.deviceIssues.filter(x => x.includes('[warn]'));
    report.issues.push(...fatalDevs);
    if (warnDevs.length) { report.deviceWarns = warnDevs; console.log('\n[DEVICE-WARN] ' + warnDevs.length + ' 条警告（不计入 ISSUES）:'); warnDevs.forEach((w) => console.log(' -', w)); }
  }
  if (report.riskIssues && report.riskIssues.length) {
    for (const ri of report.riskIssues) {
      if (ri.kind === 'callback_api' || ri.kind === 'slow_html' || ri.kind === 'scope_leak' || ri.kind === 'syntax' || ri.kind === 'url_scheme' || ri.kind === 'this_bind') report.issues.push('[RISK:' + ri.kind + '] ' + ri.msg);
      else if (ri.kind === 'detail_video_only' || ri.kind === 'ad_overcut' || ri.kind === 'missing_field' || ri.kind === 'native_unverified' || ri.kind === 'native_abi') {
        report.deviceWarns = report.deviceWarns || [];
        report.deviceWarns.push('[RISK:' + ri.kind + '] ' + ri.msg);
      }
    }
  }
  console.log('\nREPORT', reportFile);
  if (report.deviceWarns && report.deviceWarns.length) {
    console.log('\n[DEVICE-WARN] ' + report.deviceWarns.length + ' 条警告（不计入 ISSUES）:');
    report.deviceWarns.forEach((w) => console.log(' -', w));
  }
  if (report.issues.length) {
    console.log('ISSUES', report.issues.length);
    report.issues.forEach((x) => console.log(' -', x));
    if (args.assert) process.exit(1);
  } else {
    console.log('ISSUES 0');
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
