var parse = {
  作者: 'Minis',
  版本: '20260912v3',
  名称: 'CF/X5 测试台',
  host: 'https://gimyai.tw',
  UA: 'Mozilla/5.0 (Linux; Android 16; PKR110 Build/AP3A.240617.008; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/151.0.7922.47 Mobile Safari/537.36',
  页码: { 主页: 1, 搜索: 1 },
  静态分类: { type: '主页', url: 'fyclass', class_name: 'CF测试', class_url: 'cf' },

  /* checkJs：fcbw 的「抓取条件」脚本。返回 null = 还没过挑战，每 250ms 重试；
     返回非 null = 抓 DOM。注意：会被 App 拼进 eval('...')，所以内部【禁止单引号】。 */
  _ck: function() {
    return '(function(){' +
      'var t=document.title||"";' +
      'if(/稍候|安全验证|Just a moment|Verifying|正在等待/i.test(t)){' +
      'try{if(!window.__cft){window.__cft=1;' +
      'var n=parseInt(sessionStorage.getItem("__cfr")||"0");' +
      'if(n<2){sessionStorage.setItem("__cfr",String(n+1));' +
      'setTimeout(function(){location.reload();},12000);}}}catch(e){}' +
      'return null;}' +
      'return true;' +
      '})()';
  },

  /* 网页侧注入（x5_webview_single 的 extra.js）：直接传给 webView.evaluateJavascript，
     所以必须是可立即执行的语句。这里用字面量字符串，避免闭包序列化问题。
     网页里只能用 fy_bridge_app / fba（App 注入），写进 putVar 后规则侧 getVar 能读到。 */
  _webjs: function() {
    return '(function(){' +
      'function put(k,v){try{fy_bridge_app.putVar(k,v);}catch(e){}}' +
      'function tick(){' +
      'var t="";try{t=document.title||"";}catch(e){}' +
      'if(!t){setTimeout(tick,2000);return;}' +
      'if(!/稍候|安全验证|Just a moment|Verifying|正在等待/i.test(t)){' +
      'put("cf_state","成功："+t);' +
      'try{put("cf_len",String((document.documentElement.outerHTML||"").length));}catch(e){}' +
      'return;}' +
      'put("cf_state","挑战中："+t);' +
      'try{if(!window.__cft){window.__cft=1;' +
      'var n=parseInt(sessionStorage.getItem("__cfr")||"0");' +
      'if(n<3){sessionStorage.setItem("__cfr",String(n+1));' +
      'setTimeout(function(){location.reload();},10000);}}}catch(e){}' +
      'setTimeout(tick,2000);}' +
      'tick();' +
      '})()';
  },

  主页: function() {
    var d = [];
    var host = this.host, ua = this.UA, ck = this._ck(), wjs = this._webjs();

    d.push({ title: 'CF / X5 测试台', col_type: 'text_center_1', url: 'hiker://empty' });
    d.push({ title: '目标 ' + host, col_type: 'text_center_1', url: 'hiker://empty' });

    /* 上次结果回显（网页侧与 fcbw 都写到这里） */
    var st = '', ln = '', tl = '', er = '';
    try { st = getVar('cf_state', '') || ''; } catch (e0) {}
    try { ln = getVar('cf_len', '') || ''; } catch (e1) {}
    try { tl = getVar('cf_title', '') || ''; } catch (e2) {}
    try { er = getVar('cf_err', '') || ''; } catch (e3) {}
    if (st || tl || er) {
      d.push({ title: '──── 上次结果 ────', col_type: 'text_center_1', url: 'hiker://empty' });
      if (st) d.push({ title: 'X5：' + st, url: 'hiker://empty', col_type: 'text_center_1' });
      if (ln) d.push({ title: 'X5 页面长度：' + ln, url: 'hiker://empty', col_type: 'text_center_1' });
      if (tl) d.push({ title: 'fcbw title：' + tl, url: 'hiker://empty', col_type: 'text_center_1' });
      if (er) d.push({ title: 'fcbw 异常：' + er, url: 'hiker://empty', col_type: 'text_center_1' });
    } else {
      d.push({ title: '（还没跑过）', col_type: 'text_center_1', url: 'hiker://empty' });
    }

    d.push({ title: '──── 测试 ① 可见 X5 ────', col_type: 'text_center_1', url: 'hiker://empty' });

    /* ① 用可见 X5 组件加载目标站，能手动点验证框；注入 JS 自动等 + reload */
    d.push({
      title: '▶ 打开 X5 加载 gimyai（等挑战跑完）',
      col_type: 'text_center_1',
      url: $('#noLoading#').rule(function(u, uag, webjs) {
        setResult([{
          title: 'gimyai.tw',
          url: u,
          col_type: 'x5_webview_single',
          desc: 'float&&100%',
          extra: { ua: uag, js: webjs }
        }]);
      }, host, ua, wjs)
    });

    d.push({ title: '──── 测试 ② fcbw 无头抓取 ────', col_type: 'text_center_1', url: 'hiker://empty' });

    /* ② fcbw + checkJs：不 ok 就 250ms 重试（已把窗口从 30s 改到 120s） */
    d.push({
      title: '▶ fcbw + checkJs 自动过挑战',
      col_type: 'text_center_1',
      url: $('#noLoading#').lazyRule(function(u, cks) {
        var s = '';
        try { s = String(fcbw(u, { timeout: 30000, checkJs: cks }) || ''); } catch (e) {}
        try {
          var t = (s.match(/<title[^>]*>([^<]*)</) || [])[1] || '(无标题)';
          putVar('cf_title', t + '  [' + s.length + 'B]');
          putVar('cf_err', '');
        } catch (e2) {}
        refreshPage(false);
        return 'hiker://empty';
      }, host, ck)
    });

    d.push({ title: '──── 测试 ③ 清 cookie ────', col_type: 'text_center_1', url: 'hiker://empty' });

    d.push({
      title: '▶ 清 gimyai cookie（重测前用）',
      col_type: 'text_center_1',
      url: $('#noLoading#').lazyRule(function() {
        try {
          putVar('cf_state', '');
          putVar('cf_len', '');
          putVar('cf_title', '');
          putVar('cf_err', '');
          toast('已清测试记录（cookie 请在 App 设置里清）');
        } catch (e) {}
        refreshPage(false);
        return 'hiker://empty';
      })
    });

    return d;
  }
};
