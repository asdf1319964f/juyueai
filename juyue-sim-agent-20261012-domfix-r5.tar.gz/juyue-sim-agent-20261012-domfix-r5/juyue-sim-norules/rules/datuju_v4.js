var parse = {
  作者: 'NULL',
  版本: '20260910v4',
  名称: '大图居',
  host: 'https://m.datuju.com',
  UA: 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
  页码: { 主页: 1, 搜索: 1 },
  /* 分类走聚阅原生 tab，url 带 fypage 供宿主替换 */
  静态分类: { type: '主页', url: 'fyclass/fypage', class_name: '美女图片&美女模特&高清壁纸', class_url: 'meinv&mote&bizhi' },
  /* 统一 GET */
  _req: function(u) {
    var url = u == null ? '' : String(u);
    try {
      return request(url, { headers: { 'User-Agent': parse.UA, Referer: 'https://m.datuju.com/', 'Accept-Encoding': 'identity' }, timeout: 15000 }) || '';
    } catch (e0) {
      return '';
    }
  },
  /* 去标签与实体 */
  _text: function(s) {
    var t = s == null ? '' : String(s);
    t = t.replace(/<[^>]+>/g, '');
    t = t.replace(/&nbsp;|&#160;/g, ' ');
    t = t.replace(/&amp;/g, '&');
    t = t.replace(/&quot;/g, '"');
    t = t.replace(/&#39;/g, "'");
    t = t.replace(/&lt;/g, '<');
    t = t.replace(/&gt;/g, '>');
    t = t.replace(/[ \t\r\n]+/g, ' ');
    t = t.replace(/^ +| +$/g, '');
    return t;
  },
  /* 站点只接受汉字字母数字 */
  _kw: function(s) {
    var t = s == null ? '' : String(s);
    return t.replace(/[^a-zA-Z0-9\u4e00-\u9fa5]+/g, '');
  },
  /* 任意值转字符串，供链式 toString */
  _str: function(x) {
    if (x == null) return '';
    try {
      if (typeof x === 'string') return x;
      if (x.toString) return String(x.toString());
    } catch (e0) {}
    return String(x);
  },
  /* 列表卡片 */
  _list: function(html) {
    var s = html == null ? '' : String(html), out = [], seen = {}, re = /<a[^>]+href="([^"]*\/(\d+)\.html)"[^>]*>([\d\D]*?)<\/a>/gi, m;
    while ((m = re.exec(s))) {
      if (seen[m[1]]) continue;
      var block = m[3] || '';
      var im = block.match(/data-src="([^"]+)"/i) || block.match(/src="(https?:\/\/file\.datuju\.net\/[^"]+)"/i);
      if (!im) continue;
      var tm = block.match(/<h3>([\d\D]*?)<\/h3>/i);
      var title = tm ? parse._text(tm[1]) : '';
      if (!title) {
        var am = block.match(/alt="([^"]*)"/i);
        title = am ? parse._text(am[1]) : '';
      }
      if (!title) continue;
      seen[m[1]] = 1;
      out.push({ id: m[2], href: m[1], img: im[1], title: title });
    }
    return out;
  },
  /* 把详情页打成 pics:// 文本（回调内零闭包，参数全烘焙） */
  _picsJs: function() {
    return function(u, ua, host) {
      u = u ? String(u) : '';
      ua = ua ? String(ua) : '';
      host = host ? String(host) : 'https://m.datuju.com';
      var html = '';
      try { html = request(u, { headers: { 'User-Agent': ua, Referer: host + '/', 'Accept-Encoding': 'identity' }, timeout: 15000 }) || ''; } catch (e0) {}
      if (!html) return 'toast://页面加载失败，请重试';
      var infoM = html.match(/data-info="([^"]*)"/i);
      var parts = infoM ? String(infoM[1]).split('l') : [];
      var picM = html.match(/<img[^>]+id="picBox"[^>]*>/i);
      var first = '';
      if (picM) {
        var sm = picM[0].match(/src="([^"]+)"/i);
        first = sm ? sm[1] : '';
      }
      var idm = u.match(/\/(\d+)\.html/i);
      var id = parts[0] || (idm ? idm[1] : '');
      if (parts.length >= 6 && id) {
        var folder = parts[5] || '', raw = '';
        try { raw = request(host + '/library/bmore.php?id=' + id + '&uid=0', { headers: { 'User-Agent': ua, Referer: u, 'Accept-Encoding': 'identity' }, timeout: 15000 }) || ''; } catch (e1) {}
        var names = [];
        try {
          var j2 = JSON.parse(raw || '{}');
          if (j2 && j2.content) names = String(j2.content).split(',');
        } catch (e2) {}
        var pics = [];
        for (var i = 0; i < names.length; i++) {
          if (names[i]) pics.push('https://file.datuju.net/b/' + folder + names[i] + '.jpg');
        }
        if (pics.length) return 'pics://' + pics.join('&&');
      }
      var dl = html.match(/href="(https:\/\/file\.datuju\.net\/w\/[^"]+)"/i);
      if (dl) return 'pics://' + dl[1];
      if (first) return 'pics://' + first;
      return 'toast://暂无图片';
    };
  },
  /* 列表直达图集 */
  _openPics: function(href) {
    var chain = $('#noLoading#').lazyRule(parse._picsJs(), parse._str(href), parse.UA, parse.host);
    return parse._str(chain);
  },
  /* 模特作品列表（.rule + setResult），作品仍直出 pics */
  _openModel: function(href) {
    var chain = $('#noLoading#').rule(function(mu, ua, host) {
      mu = mu ? String(mu) : '';
      ua = ua ? String(ua) : '';
      host = host ? String(host) : 'https://m.datuju.com';
      var html = '';
      try { html = request(mu, { headers: { 'User-Agent': ua, Referer: host + '/', 'Accept-Encoding': 'identity' }, timeout: 15000 }) || ''; } catch (e0) {}
      var out = [], seen = {}, re = /<a[^>]+href="([^"]*\/(\d+)\.html)"[^>]*>([\d\D]*?)<\/a>/gi, m;
      while ((m = re.exec(html || ''))) {
        if (seen[m[1]]) continue;
        var block = m[3] || '';
        var im = block.match(/data-src="([^"]+)"/i);
        if (!im) continue;
        var tm = block.match(/<h3>([\d\D]*?)<\/h3>/i);
        var title = '';
        if (tm && tm[1]) {
          title = String(tm[1]);
          title = title.replace(/<[^>]+>/g, '');
          title = title.replace(/[ \t\r\n]+/g, ' ');
          title = title.replace(/^ +| +$/g, '');
        }
        if (!title) continue;
        seen[m[1]] = 1;
        var picUrl = $('#noLoading#').lazyRule(function(u, uag, hs) {
          u = u ? String(u) : '';
          uag = uag ? String(uag) : '';
          hs = hs ? String(hs) : 'https://m.datuju.com';
          var h2 = '';
          try { h2 = request(u, { headers: { 'User-Agent': uag, Referer: hs + '/', 'Accept-Encoding': 'identity' }, timeout: 15000 }) || ''; } catch (e1) {}
          if (!h2) return 'toast://页面加载失败，请重试';
          var infoM = h2.match(/data-info="([^"]*)"/i);
          var parts = infoM ? String(infoM[1]).split('l') : [];
          var picM = h2.match(/<img[^>]+id="picBox"[^>]*>/i);
          var first = '';
          if (picM) {
            var sm = picM[0].match(/src="([^"]+)"/i);
            first = sm ? sm[1] : '';
          }
          var idm = u.match(/\/(\d+)\.html/i);
          var id = parts[0] || (idm ? idm[1] : '');
          if (parts.length >= 6 && id) {
            var folder = parts[5] || '', raw = '';
            try { raw = request(hs + '/library/bmore.php?id=' + id + '&uid=0', { headers: { 'User-Agent': uag, Referer: u, 'Accept-Encoding': 'identity' }, timeout: 15000 }) || ''; } catch (e2) {}
            var names = [];
            try {
              var j2 = JSON.parse(raw || '{}');
              if (j2 && j2.content) names = String(j2.content).split(',');
            } catch (e3) {}
            var pics = [];
            for (var i = 0; i < names.length; i++) {
              if (names[i]) pics.push('https://file.datuju.net/b/' + folder + names[i] + '.jpg');
            }
            if (pics.length) return 'pics://' + pics.join('&&');
          }
          if (first) return 'pics://' + first;
          return 'toast://暂无图片';
        }, m[1], ua, host);
        out.push({ title: title, desc: '图集', img: im[1], pic_url: im[1], col_type: 'movie_3', url: picUrl && picUrl.toString ? picUrl.toString() : String(picUrl || 'hiker://empty') });
      }
      if (!out.length) out.push({ title: '暂无作品', desc: '', img: '', pic_url: '', col_type: 'text_center_1', url: 'hiker://empty' });
      setResult(out);
    }, parse._str(href), parse.UA, parse.host);
    return parse._str(chain);
  },
  /* 统一卡片，避免宿主对空字段 .replace */
  _item: function(title, img, url, desc, col) {
    return {
      title: title == null ? '' : String(title),
      desc: desc == null ? '' : String(desc),
      img: img == null ? '' : String(img),
      pic_url: img == null ? '' : String(img),
      col_type: col || 'movie_3',
      url: url == null || url === '' ? 'hiker://empty' : parse._str(url)
    };
  },
  _cards: function(a, asModel) {
    var d = [], j, it, link;
    for (j = 0; j < a.length; j++) {
      it = a[j];
      link = asModel ? parse._openModel(it.href) : parse._openPics(it.href);
      d.push(parse._item(it.title, it.img, link, asModel ? '模特' : '图集', 'movie_3'));
    }
    return d;
  },
  /* 从 MY_URL 取出分类路径 */
  _path: function() {
    var raw = '';
    try { raw = String(MY_URL == null ? '' : MY_URL); } catch (e0) { raw = ''; }
    var mm = raw.match(/(meinv|mote|bizhi)/);
    return mm ? mm[1] : 'meinv';
  },
  /* 主页 */
  主页: function() {
    var p = Number(MY_PAGE || 1) || 1;
    var path = parse._path();
    var u = p > 1 ? parse.host + '/' + path + '/list_' + p + '.html' : parse.host + '/' + path + '/';
    var html = parse._req(u);
    var a = parse._list(html);
    var asModel = false;
    if (!a.length && path === 'mote') {
      asModel = true;
      var nr = /<a[^>]+href="([^"]*\/mote\/[a-z0-9]+\/)"[^>]*>[ \t\r\n]*<img[^>]+data-src="([^"]+)"[^>]*>[ \t\r\n]*<i>([\d\D]*?)<\/i>/gi, nm;
      a = [];
      while ((nm = nr.exec(html || ''))) {
        a.push({ href: nm[1], img: nm[2], title: parse._text(nm[3]) });
      }
    }
    if (a.length) return parse._cards(a, asModel);
    if (p > 1) return [];
    return [parse._item('加载失败，点我重试', '', parse.host + '/' + path + '/', '网络异常或站点不可达', 'text_center_1')];
  },
  /* 搜索：POST JSON，翻页走 MY_PAGE */
  搜索: function(name) {
    var q = parse._kw(name || MY_URL || '');
    if (!q) return [parse._item('请输入关键词', '', 'hiker://empty', '只支持汉字、字母、数字', 'text_1')];
    var key = 'dtjs_', d = [], cur = String(getMyVar(key + 'tid', '0') || '0'), tabs = ['美女图片', '高清壁纸'];
    if (String(getMyVar(key + 'kw', '') || '') !== q) putMyVar(key + 'kw', q);
    var p = Number(MY_PAGE || 1) || 1;
    var i;
    for (i = 0; i < tabs.length; i++) {
      d.push(parse._item(String(i) === cur ? '❆ ' + tabs[i] + ' ❆' : tabs[i], '', $('#noLoading#').lazyRule(function(idx, k) {
        putMyVar(k + 'tid', idx + '');
        refreshPage(false);
        return 'hiker://empty';
      }, i, key), '', 'scroll_button'));
    }
    d.push(parse._item('', '', 'hiker://empty', '', 'blank_block'));
    var raw = '', payload = '{"str":"' + q + '","tid":' + (Number(cur) || 0) + ',"page":' + p + '}';
    try {
      raw = request(parse.host + '/library/search.php', {
        method: 'POST',
        body: payload,
        headers: {
          'User-Agent': parse.UA,
          Referer: 'https://m.datuju.com/search.php',
          'Content-Type': 'application/json',
          'Accept-Encoding': 'identity'
        },
        timeout: 15000
      }) || '';
    } catch (e0) {}
    if (!raw) {
      try {
        raw = post(parse.host + '/library/search.php', {
          body: payload,
          headers: {
            'User-Agent': parse.UA,
            Referer: 'https://m.datuju.com/search.php',
            'Content-Type': 'application/json',
            'Accept-Encoding': 'identity'
          },
          timeout: 15000
        }) || '';
      } catch (e1) {}
    }
    raw = raw == null ? '' : String(raw);
    if (raw.charAt(0) === '\ufeff') raw = raw.substring(1);
    var arr = [];
    try {
      var j = JSON.parse(raw);
      arr = parse._list(j && j.content ? j.content : '');
    } catch (e2) {}
    if (arr.length) {
      for (i = 0; i < arr.length; i++) d.push(parse._item(arr[i].title, arr[i].img, parse._openPics(arr[i].href), '搜索', 'movie_3'));
    } else if (p === 1) {
      d.push(parse._item('未找到「' + q + '」', '', 'hiker://empty', '换个关键词或切到另一个分类', 'text_center_1'));
    }
    return d;
  },
  /* 宿主若仍走二级：同步产出 pics，避免 MY_URL.replace 空指针 */
  二级: function(url) {
    var u = parse._str(url || MY_URL || input || '');
    if (!u || u.indexOf('hiker://') === 0) {
      return { detail1: '大图居', desc: '', img: '', list: [[{ title: '暂无内容', url: 'hiker://empty', desc: '', img: '' }]], line: ['图片'] };
    }
    if (u.indexOf('pics://') === 0) {
      return { detail1: '大图居', desc: '', img: '', list: [[{ title: '查看图片', url: u, desc: '', img: '' }]], line: ['图片'] };
    }
    return {
      detail1: '大图居',
      desc: '点击查看',
      img: '',
      line: ['图片'],
      list: [[{ title: '查看图片', url: parse._openPics(u), desc: '', img: '' }]]
    };
  },
  /* 宿主默认解析会 MY_URL.replace，必须自备 */
  解析: function(url) {
    var u = parse._str(url || MY_URL || input || '');
    if (!u) return 'toast://空地址';
    if (u.indexOf('pics://') === 0 || u.indexOf('toast://') === 0 || u.indexOf('hiker://') === 0) return u;
    return parse._openPics(u);
  }
};
