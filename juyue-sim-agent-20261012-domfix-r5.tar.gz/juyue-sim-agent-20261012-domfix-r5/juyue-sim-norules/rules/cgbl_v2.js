var parse = {
  作者: 'hermes',
  版本: '20260910v7',
  名称: '吃瓜爆料',
  host: 'https://d9altmxkp5q0i.cloudfront.net',
  UA: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
  页码: { 主页: 1, 分类: 1, 搜索: 1 },
  静态分类: {
    type: '主页',
    url: 'fyclass/fypage',
    class_name: '首页&今日大瓜&热点吃瓜&独家爆料&AI短剧&每日大赛&海角社区&校园吃瓜&反差爆料&网红黑料&明星吃瓜&猎奇吃瓜&福利视频&探花经典',
    class_url: 'home&jrgb&ssdbl&rmgb&aidj&mrds&hjsq&xyss&bgzq&whbl&mxhl&blqw&fljq&thjx'
  },
  _str: function(x) {
    if (x == null) return '';
    try { return typeof x === 'string' ? x : String(x.toString ? x.toString() : x); } catch (e0) { return String(x); }
  },
  _host: function() {
    var h = '';
    try { h = String(getItem('cg_cgbl_host', '') || ''); } catch (e0) { h = ''; }
    if (h.indexOf('http') === 0) return h.replace(/\/+$/, '');
    return parse.host;
  },
  _hdr: function(ref) {
    return {
      'User-Agent': parse.UA,
      Referer: (ref || parse._host()) + '/',
      Accept: 'text/html,application/xhtml+xml',
      'Accept-Encoding': 'identity'
    };
  },
  _html: function(url) {
    url = String(url || '');
    if (url.indexOf('http') !== 0) return '';
    var html = '';
    try { html = request(url, { headers: parse._hdr(), timeout: 20000 }) || ''; } catch (e0) {}
    return html == null ? '' : String(html);
  },
  预处理1: function() {
    var cur = '';
    try { cur = String(getItem('cg_cgbl_host', '') || ''); } catch (e0) { cur = ''; }
    var cands = [cur, parse.host, 'https://d9altmxkp5q0i.cloudfront.net', 'https://blw66.com', 'https://www.blw66.com'];
    var i, u, html;
    for (i = 0; i < cands.length; i++) {
      u = String(cands[i] || '').replace(/\/+$/, '');
      if (u.indexOf('http') !== 0) continue;
      html = parse._html(u + '/');
      if (html.indexOf('/archives/') >= 0 && html.length > 1000) {
        try { setItem('cg_cgbl_host', u); } catch (e1) {}
        parse.host = u;
        return;
      }
    }
  },
  _cate: function() {
    var c = '';
    try {
      if (typeof MY_CLS !== 'undefined' && MY_CLS && MY_CLS !== 'fyclass') c = String(MY_CLS);
      if (!c && typeof MY_URL !== 'undefined') {
        var raw = String(MY_URL || '');
        var ps = raw.split('##');
        if (ps.length >= 2 && ps[1] && ps[1] !== 'fyclass' && ps[1] !== 'fypage') c = ps[1];
        if (!c) {
          var pm = raw.match(/category\/([^/]+)/);
          if (pm) c = pm[1];
          else if (/^home\b/.test(raw) || raw === 'home/1' || raw.indexOf('home/') === 0) c = '';
          else {
            var first = raw.split('/')[0];
            if (first && first !== 'fyclass' && first !== 'fypage' && first !== 'home' && first.indexOf('http') !== 0) c = first;
          }
        }
      }
    } catch (e0) {}
    if (c === 'home') c = '';
    return c;
  },
  _page: function() {
    var page = 1;
    try { if (typeof MY_PAGE !== 'undefined' && MY_PAGE) page = parseInt(MY_PAGE, 10) || 1; } catch (e0) {}
    if (!page || page < 1) {
      try {
        var ps = String(MY_URL || '').split('##');
        if (ps.length >= 3) page = parseInt(ps[2], 10) || 1;
      } catch (e1) {}
    }
    return page < 1 ? 1 : page;
  },
  _listUrl: function(cate, page) {
    var ho = parse._host();
    cate = String(cate || '').replace(/^\//, '');
    page = page || 1;
    if (!cate) return page > 1 ? ho + '/page/' + page + '/' : ho + '/';
    var u = ho + '/category/' + encodeURIComponent(cate) + '/';
    if (page > 1) u += page + '/';
    return u;
  },
  _imgDec: function() {
    return $('').image(function() {
      try {
        var CryptoUtil = $.require('hiker://assets/crypto-java.js');
        var key = CryptoUtil.Data.parseUTF8('f5d965df75336270');
        var iv = CryptoUtil.Data.parseUTF8('97b60394abc2fbe1');
        var textData = CryptoUtil.Data.parseInputStream(input);
        var decrypted = CryptoUtil.AES.decrypt(textData, key, { mode: 'AES/CBC/NoPadding', iv: iv });
        return decrypted.toInputStream();
      } catch (e) { return input; }
    });
  },
  _img: function(url) {
    var u = String(url || '').replace(/\\\//g, '/');
    if (!u) return '';
    if (u.indexOf('//') === 0) u = 'https:' + u;
    if (u.indexOf('http') !== 0) return '';
    return u + parse._imgDec();
  },
  _play: function(m3u8, pageUrl) {
    var u = String(m3u8 || '').replace(/\\\//g, '/').replace(/\\u0026/g, '&').replace(/&amp;/g, '&');
    if (!u) return 'toast://无播放地址';
    if (u.indexOf('//') === 0) u = 'https:' + u;
    var ref = String(pageUrl || parse._host() + '/');
    return 'video://' + u + ';{Referer@' + ref + '&&User-Agent@' + parse.UA + '}';
  },
  _parseM3u8: function(html) {
    var out = [], htmls = String(html || ''), i, raw, j, u;
    var cfgs = htmls.match(/data-config\s*=\s*'([^']+)'/g) || [];
    var cfgs2 = htmls.match(/data-config\s*=\s*"([^"]+)"/g) || [];
    for (i = 0; i < cfgs2.length; i++) cfgs.push(cfgs2[i]);
    for (i = 0; i < cfgs.length; i++) {
      raw = String(cfgs[i]).replace(/^data-config\s*=\s*['"]/, '').replace(/['"]$/, '');
      raw = raw.replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/\\\//g, '/').replace(/\\u0026/g, '&');
      u = '';
      try {
        j = JSON.parse(raw);
        if (j && j.video) u = j.video.url || j.video.url2 || '';
      } catch (e0) {}
      if (!u) {
        var mm = raw.match(/https?:[^"'\\ ]+\.m3u8[^"'\\ ]*/);
        if (mm) u = mm[0];
      }
      u = String(u || '').replace(/\\u0026/g, '&');
      if (u && out.indexOf(u) < 0) out.push(u);
    }
    return out;
  },
  _cards: function(html) {
    var d = [], seen = {}, re = /<article([\s\S]*?)<\/article>/g, m, block, id, title, pic, mm;
    html = String(html || '');
    while ((m = re.exec(html)) !== null) {
      block = m[1] || '';
      if (/itemtype="[^"]*Advertisement/i.test(block)) continue;
      mm = block.match(/\/archives\/(\d+)\//);
      if (!mm) continue;
      id = mm[1];
      if (!id || seen[id]) continue;
      mm = block.match(/<h2[^>]*>([\s\S]*?)<\/h2>/) || block.match(/itemprop="url mainEntityOfPage" content="[^"]*"[^>]*>/);
      title = '';
      var tm = block.match(/<h2[^>]*>([\s\S]*?)<\/h2>/);
      if (tm) title = tm[1];
      if (!title) {
        tm = block.match(/alt="([^"]+)"/);
        if (tm) title = tm[1];
      }
      title = String(title || '').replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').replace(/^ +| +$/g, '');
      if (!title || /更新通知|^高端约炮$/.test(title)) continue;
      pic = '';
      tm = block.match(/loadBannerDirect\(\s*['"]([^'"]+)['"]/);
      if (tm) pic = tm[1];
      if (!pic) {
        tm = block.match(/data-banner="([^"]+)"/) || block.match(/data-src="([^"]+)"/);
        if (tm) pic = tm[1];
      }
      pic = String(pic || '').replace(/\\\//g, '/');
      if (pic.indexOf('//') === 0) pic = 'https:' + pic;
      if (pic && /placeholder|logo|search_btn/i.test(pic)) pic = '';
      seen[id] = 1;
      d.push({
        title: title,
        desc: '',
        img: pic ? parse._img(pic) : '',
        pic_url: pic ? parse._img(pic) : '',
        url: parse._openDetail(id, title),
        extra: { title: title, img: pic ? parse._img(pic) : '', url: '/archives/' + id + '/' },
        col_type: 'pic_1_card'
      });
    }
    return d;
  },
  主页: function() {
    var html = parse._html(parse._listUrl(parse._cate(), parse._page()));
    var d = parse._cards(html);
    if (d.length) return d;
    return [{ title: '加载失败或分类不存在', desc: parse._listUrl(parse._cate(), parse._page()), img: '', pic_url: '', url: 'hiker://empty', col_type: 'text_center_1' }];
  },
  分类: function() { return parse.主页(); },
  搜索: function(name) {
    var q = String(name || '').replace(/[\\"\r\n]+/g, '').replace(/^ +| +$/g, '');
    if (!q) return [{ title: '输入关键词搜索', desc: '', img: '', pic_url: '', url: 'hiker://empty', col_type: 'text_center_1' }];
    var p = parse._page();
    var url = parse._host() + '/search/' + encodeURIComponent(q) + '/';
    if (p > 1) url += p + '/';
    var d = parse._cards(parse._html(url));
    return d.length ? d : [{ title: '未找到「' + q + '」', desc: '', img: '', pic_url: '', url: 'hiker://empty', col_type: 'text_center_1' }];
  },
  /* 点进详情用 rule 整页渲染，避免视频源只显示选集、正文被丢掉 */
  _openDetail: function(id, title) {
    var page0 = parse._host() + '/archives/' + id + '/';
    return parse._str($(page0).rule(function(id2, host, ua) {
      function dec() {
        return $('').image(function() {
          try {
            var CryptoUtil = $.require('hiker://assets/crypto-java.js');
            var key = CryptoUtil.Data.parseUTF8('f5d965df75336270');
            var iv = CryptoUtil.Data.parseUTF8('97b60394abc2fbe1');
            var textData = CryptoUtil.Data.parseInputStream(input);
            return CryptoUtil.AES.decrypt(textData, key, { mode: 'AES/CBC/NoPadding', iv: iv }).toInputStream();
          } catch (e) { return input; }
        });
      }
      function abs(u) {
        u = String(u || '').replace(/\\\//g, '/');
        if (u.indexOf('//') === 0) u = 'https:' + u;
        return u;
      }
      var pageUrl = host + '/archives/' + id2 + '/';
      var html = '';
      try {
        html = request(pageUrl, {
          headers: { 'User-Agent': ua, Referer: host + '/', Accept: 'text/html', 'Accept-Encoding': 'identity' },
          timeout: 20000
        }) || '';
      } catch (e0) {}
      html = String(html || '');
      var d = [], i, title = '', tm;
      tm = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/);
      if (tm) title = String(tm[1]).replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').replace(/^ +| +$/g, '');
      d.push({ title: title || ('图文 ' + id2), col_type: 'text_center_1', url: pageUrl, desc: '', img: '' });
      var cfgs = html.match(/data-config\s*=\s*'([^']+)'/g) || [];
      var plays = [], raw, j, u;
      for (i = 0; i < cfgs.length; i++) {
        raw = String(cfgs[i]).replace(/^data-config\s*=\s*'/, '').replace(/'$/, '');
        raw = raw.replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/\\\//g, '/').replace(/\\u0026/g, '&');
        u = '';
        try { j = JSON.parse(raw); if (j && j.video) u = j.video.url || ''; } catch (e1) {}
        if (!u) {
          var mm = raw.match(/https?:[^"'\\ ]+\.m3u8[^"'\\ ]*/);
          if (mm) u = mm[0];
        }
        u = String(u || '').replace(/\\u0026/g, '&');
        if (u && plays.indexOf(u) < 0) plays.push(u);
      }
      for (i = 0; i < plays.length; i++) {
        d.push({
          title: plays.length > 1 ? '▶ 视频' + (i + 1) : '▶ 播放',
          col_type: plays.length > 1 ? 'text_3' : 'text_1',
          url: 'video://' + plays[i] + ';{Referer@' + pageUrl + '&&User-Agent@' + ua + '}',
          desc: '',
          img: ''
        });
      }
      var body = html;
      var bm = html.match(/<div class="post-content"[\s\S]*$/);
      if (bm) body = bm[0];
      body = body.replace(/<div class="txt-apps"[\s\S]*?<\/div>/g, '');
      var marks = ['关键词：', '关键词:', '版权声明', '本文《', '下载官方APP', '不可错过的那些大瓜', '热点大瓜目录'];
      var cutAt = -1, pi, pv;
      for (pi = 0; pi < marks.length; pi++) {
        pv = body.indexOf(marks[pi]);
        if (pv >= 0 && (cutAt < 0 || pv < cutAt)) cutAt = pv;
      }
      if (cutAt > 400) body = body.substring(0, cutAt);
      var seen = {}, src;
      var imgs = body.match(/data-xkrkllgl="([^"]+)"/g) || [];
      if (!imgs.length) imgs = body.match(/data-src="(https?:[^"]+\.(?:jpeg|jpg|png|webp)[^"]*)"/g) || [];
      for (i = 0; i < imgs.length; i++) {
        src = (imgs[i].match(/https?:[^"]+/) || imgs[i].match(/"([^"]+)"/) || [])[0] || '';
        src = abs(String(src).replace(/^"/, '').replace(/"$/, ''));
        if (!src || seen[src]) continue;
        if (/logo|placeholder|hc237\/|default\/other|\.gif/i.test(src)) continue;
        seen[src] = 1;
        d.push({ title: '', desc: '', img: src + dec(), pic_url: src + dec(), url: src + dec(), col_type: 'pic_1_full' });
      }
      var texts = body.match(/<(?:p|h2|h3)[^>]*>([\s\S]*?)<\/(?:p|h2|h3)>/g) || [];
      for (i = 0; i < texts.length; i++) {
        var t = String(texts[i]).replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ').replace(/^ +| +$/g, '');
        if (!t || t.length < 8) continue;
        if (/^(关键词|版权声明|本文《|QQ群|下载官方|热点大瓜|不可错过|点击进入|点击下载|点击加入|发送任意|老司机|支持我们|官方公告)/.test(t)) continue;
        if (t.length < 30 && /gmail\.com|最新入口|最新地址|回家的路|高端约炮|春药|官方APP/.test(t)) continue;
        d.push({ title: t, col_type: 'rich_text', url: 'hiker://empty', desc: '', img: '' });
      }
      if (d.length < 2) d.push({ title: '正文为空，打开原页', url: pageUrl, col_type: 'text_center_1', desc: '', img: '' });
      setResult(d);
    }, String(id), parse._host(), parse.UA));
  },
  _detailItems: function(html, pageUrl) {
    var d = [], title = '', i, src, texts, imgs, plays, host;
    html = String(html || '');
    host = parse._host();
    var tm = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/);
    if (tm) title = String(tm[1]).replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').replace(/^ +| +$/g, '');
    d.push({ title: title || '详情', desc: '', img: '', pic_url: '', url: pageUrl, col_type: 'text_center_1' });
    plays = parse._parseM3u8(html);
    for (i = 0; i < plays.length; i++) {
      d.push({
        title: plays.length > 1 ? '▶ 视频' + (i + 1) : '▶ 播放',
        desc: '',
        img: '',
        pic_url: '',
        col_type: plays.length > 1 ? 'text_3' : 'text_1',
        url: parse._play(plays[i], pageUrl)
      });
    }
    var body = '';
    tm = html.match(/<div class="post-content"[\s\S]*$/);
    if (tm) body = tm[0];
    else body = html;
    body = body.replace(/<div class="txt-apps"[\s\S]*?<\/div>/g, '');
    var marks = ['关键词：', '关键词:', '版权声明', '本文《', '下载官方APP', '不可错过的那些大瓜', '热点大瓜目录'];
    var cutAt = -1, pi, pv;
    for (pi = 0; pi < marks.length; pi++) {
      pv = body.indexOf(marks[pi]);
      if (pv >= 0 && (cutAt < 0 || pv < cutAt)) cutAt = pv;
    }
    if (cutAt > 400) body = body.substring(0, cutAt);
    imgs = body.match(/data-xkrkllgl="([^"]+)"/g) || [];
    var seen = {};
    for (i = 0; i < imgs.length; i++) {
      src = (imgs[i].match(/"([^"]+)"/) || [])[1] || '';
      src = String(src).replace(/\\\//g, '/');
      if (!src || seen[src]) continue;
      if (/logo|placeholder|hc237\/|default\/other|\.gif/i.test(src)) continue;
      seen[src] = 1;
      if (src.indexOf('//') === 0) src = 'https:' + src;
      d.push({ title: '', desc: '', img: parse._img(src), pic_url: parse._img(src), url: parse._img(src), col_type: 'pic_1_full' });
    }
    texts = body.match(/<(?:p|h2|h3)[^>]*>([\s\S]*?)<\/(?:p|h2|h3)>/g) || [];
    for (i = 0; i < texts.length; i++) {
      var t = String(texts[i]).replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ').replace(/^ +| +$/g, '');
      if (!t || t.length < 8) continue;
      if (/^(关键词|版权声明|本文《|QQ群|下载官方|热点大瓜|不可错过|点击进入|点击下载|点击加入|发送任意|老司机|支持我们|官方公告)/.test(t)) continue;
      if (t.length < 30 && /gmail\.com|最新入口|最新地址|回家的路|高端约炮|春药|官方APP/.test(t)) continue;
      d.push({ title: t, desc: '', img: '', pic_url: '', url: 'hiker://empty', col_type: 'rich_text' });
    }
    if (d.length === 1 && !plays.length) d.push({ title: '正文为空', desc: '', img: '', pic_url: '', url: pageUrl, col_type: 'text_center_1' });
    return d;
  },
  二级: function(surl) {
    var src = parse._str(surl || MY_URL || '');
    var id = '';
    var mm = src.match(/archives\/(\d+)/);
    if (mm) id = mm[1];
    try { if (!id && MY_PARAMS && MY_PARAMS.url) { mm = String(MY_PARAMS.url).match(/archives\/(\d+)/); if (mm) id = mm[1]; } } catch (e0) {}
    var pageUrl = id ? parse._host() + '/archives/' + id + '/' : (src.indexOf('http') === 0 ? src : parse._host() + src);
    var html = parse._html(pageUrl);
    var items = parse._detailItems(html, pageUrl);
    var cover = '';
    try { cover = String(MY_PARAMS && MY_PARAMS.img || ''); } catch (e1) { cover = ''; }
    var plays = [];
    var i;
    for (i = 0; i < items.length; i++) {
      if (String(items[i].url || '').indexOf('video://') === 0) plays.push({ title: items[i].title, url: items[i].url, desc: '', img: '' });
    }
    return {
      detail1: items[0] ? items[0].title : '详情',
      detail2: '',
      desc: items[0] ? items[0].title : '',
      img: cover,
      line: ['正文'],
      list: [items],
      extenditems: items
    };
  },
  解析: function(url) {
    var u = parse._str(url || MY_URL || input || '');
    return u || 'toast://空地址';
  }
};
