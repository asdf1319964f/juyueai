# juyue-sim-agent-20261012-domfix-r5 更新说明（相对 20261012-okhttp-r4）

## lib/dom.js（pdfa/pdfh 兼容性修复，两处）
1. **实现海阔标准 `@` 属性语法**：`pdfh(item, 'a@href')` / `'.title@Text'` / `'img@data-src'`
   —— 原 sim 只按 `&&` 切分路径，`@` 形式被当成 CSS 选择器传给 cheerio 恒为空。
2. **根级元素兜底**：pdfa 出的项（片段根即目标元素）再取值时，`.find()` 搜不到自身
   —— 补 `children(sel)` 兜底。旧约定（`a&&href`）保持兼容。

## 验证记录
- xmorex V1.7（pdfa/pdfh 全解析）--all-cats --detail auto --assert --device --search：
  新作 12 / 无码流出 12 / 女優 28 / 片商 16 / 類型 38，ISSUES 0 device 0 risk 0。
- missav V1.6（正则解析，回归对照）：--all-cats --assert，ISSUES 0。

## 其余变更
同 20261012-okhttp-r4（http.js okhttp 后端 + jar 合并 header 优先；engine.js sha512 修复；okfetch/ 网络壳）。
