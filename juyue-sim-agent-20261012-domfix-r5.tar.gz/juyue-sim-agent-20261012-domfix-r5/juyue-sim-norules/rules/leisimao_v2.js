var parse = {
  作者: 'NULL',
  版本: '20260910v2',
  名称: '蕾丝猫',
  host: 'https://www.lsmpsd.com',
  api: 'https://www.lsmpsd.com/api/__api_party/apiindex',
  wp: 'https://server.lesmao.vip/wp-json/wp/v2/posts/',
  cdn: 'https://img.leisimao.me/',
  UA: 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
  页码: { 主页: 1, 搜索: 1 },
  静态分类: {
    type: '主页',
    url: 'fyclass/fypage',
    class_name: '最新&AIG&DJAWA&Loozy&秀人网&Patreon&BLUECAKE&星颜社&尤蜜荟&花漾show&爱蜜社&AURA&嗲囡囡&爱尤物&语画界&模范学院&美媛馆&雅拉伊&尤美&蜜桃社&糖果画报&喵糖映画&头条女神&魅妍社&尤物馆&花の颜&DK御女郎&猫萌榜&尤果网&星乐园&猎女神&克拉女神&熊川纪信&果团网&轰趴猫&兔几盟&推女神&模特联盟&激萌文化&优星馆&薄荷叶&萌缚&推女郎&爱丝&影私荟&美腿宝贝&村长的宝物&DDY&顽味生活&51Modo&Rosi&Disi&IShow&Pans&中国腿模&VGirl&Ru1mm&Sityle',
    class_url: '0&61&5350&5351&8&5352&4978&55&44&50&23&4698&25&29&58&22&17&59&57&31&43&60&35&20&32&37&41&53&10&34&56&46&52&49&54&38&13&47&39&21&42&45&2&14&33&36&40&28&30&26&3&7&27&5&24&6&9&4'
  },
  _str: function(x) {
    if (x == null) return '';
    try {
      if (typeof x === 'string') return x;
      if (x.toString) return String(x.toString());
    } catch (e0) {}
    return String(x);
  },
  _text: function(s) {
    var t = s == null ? '' : String(s);
    t = t.replace(/<[^>]+>/g, '');
    t = t.replace(/&nbsp;|&#160;/g, ' ');
    t = t.replace(/&amp;/g, '&');
    t = t.replace(/&quot;/g, '"');
    t = t.replace(/&#39;|&apos;/g, "'");
    t = t.replace(/&lt;/g, '<');
    t = t.replace(/&gt;/g, '>');
    t = t.replace(/[ \t\r\n]+/g, ' ');
    t = t.replace(/^ +| +$/g, '');
    return t;
  },
  _kw: function(s) {
    var t = s == null ? '' : String(s);
    return t.replace(/[\\"\r\n]+/g, '');
  },
  /* 文件名数组转 pics:// */
  _toPics: function(arr, cdn) {
    var pics = [], i, n;
    if (!arr || !arr.length) return '';
    cdn = cdn || 'https://img.leisimao.me/';
    for (i = 0; i < arr.length; i++) {
      n = arr[i] ? String(arr[i]) : '';
      if (!n) continue;
      n = n.replace(/\.jpg$/i, '.webp');
      pics.push(cdn + '1178/' + n);
    }
    return pics.length ? 'pics://' + pics.join('&&') : '';
  },
  /* POST 列表 */
  _api: function(page, extra) {
    var body = '{"path":"","method":"post","query":{"per_page":20,"page":' + (Number(page) || 1) + ',"url":"' + String(extra || '') + '"},"headers":{}}';
    var raw = '';
    try {
      raw = request(parse.api, {
        method: 'POST',
        body: body,
        headers: {
          'User-Agent': parse.UA,
          Referer: parse.host + '/',
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'Accept-Encoding': 'identity'
        },
        timeout: 20000
      }) || '';
    } catch (e0) {}
    if (!raw) {
      try {
        raw = post(parse.api, {
          body: body,
          headers: {
            'User-Agent': parse.UA,
            Referer: parse.host + '/',
            'Content-Type': 'application/json',
            Accept: 'application/json',
            'Accept-Encoding': 'identity'
          },
          timeout: 20000
        }) || '';
      } catch (e1) {}
    }
    raw = raw == null ? '' : String(raw);
    if (raw.charAt(0) === '\ufeff') raw = raw.substring(1);
    try {
      var j = JSON.parse(raw);
      return j && j.length ? j : [];
    } catch (e2) {
      return [];
    }
  },
  /* 点击拉单篇完整 photo（列表接口只给 20 张） */
  _openPics: function(id, preview) {
    var chain = $('#noLoading#').lazyRule(function(pid, pre, wp, cdn, ua) {
      pid = pid ? String(pid) : '';
      pre = pre ? String(pre) : '';
      wp = wp ? String(wp) : 'https://server.lesmao.vip/wp-json/wp/v2/posts/';
      cdn = cdn ? String(cdn) : 'https://img.leisimao.me/';
      ua = ua ? String(ua) : '';
      function toPics(arr) {
        var out = [], i, n;
        if (!arr || !arr.length) return '';
        for (i = 0; i < arr.length; i++) {
          n = arr[i] ? String(arr[i]) : '';
          if (!n) continue;
          n = n.replace(/\.jpg$/i, '.webp');
          out.push(cdn + '1178/' + n);
        }
        return out.length ? 'pics://' + out.join('&&') : '';
      }
      var raw = '';
      if (pid) {
        try {
          raw = request(wp + pid, {
            headers: { 'User-Agent': ua, Referer: 'https://www.lsmpsd.com/', Accept: 'application/json', 'Accept-Encoding': 'identity' },
            timeout: 20000
          }) || '';
        } catch (e0) {}
      }
      if (raw && raw.charAt(0) === '\ufeff') raw = raw.substring(1);
      try {
        var j = JSON.parse(raw);
        if (j && j.photo && j.photo.length) {
          var full = toPics(j.photo);
          if (full) return full;
        }
      } catch (e1) {}
      if (pre) return toPics(pre.split(',')) || 'toast://暂无图片';
      return 'toast://图集获取失败';
    }, parse._str(id), parse._str(preview), parse.wp, parse.cdn, parse.UA);
    return parse._str(chain);
  },
  _item: function(title, img, url, desc, col) {
    return {
      title: title == null ? '' : String(title),
      desc: desc == null ? '' : String(desc),
      img: img == null ? '' : String(img),
      pic_url: img == null ? '' : String(img),
      col_type: col || 'movie_3',
      url: url == null || url === '' ? 'hiker://empty' : parse._str(url)
    };
  },
  _cards: function(arr) {
    var d = [], i, it, title, thumb, names, desc, n;
    for (i = 0; i < arr.length; i++) {
      it = arr[i] || {};
      title = parse._text(it.title && it.title.rendered ? it.title.rendered : it.title);
      if (!title) title = '图集 ' + (it.id || '');
      thumb = it.thumb ? String(it.thumb).replace(/\.jpg$/i, '.webp') : '';
      thumb = thumb ? parse.cdn + '500/' + thumb : '';
      names = it.photo && it.photo.length ? it.photo.join(',') : '';
      n = Number(it.number) || (it.photo ? it.photo.length : 0);
      desc = (it.category_name ? it.category_name + ' · ' : '') + (n ? n + 'P' : '');
      d.push(parse._item(title, thumb, it.id ? parse._openPics(it.id, names) : 'toast://暂无图片', desc, 'movie_3'));
    }
    return d;
  },
  _cls: function() {
    var raw = '';
    try { raw = String(MY_URL == null ? '' : MY_URL); } catch (e0) { raw = ''; }
    var m = raw.match(/^(\d+)/);
    if (m) return m[1];
    m = raw.match(/fyclass(\d+)/);
    if (m) return m[1];
    if (raw === '0' || raw.indexOf('0/') === 0) return '0';
    return '0';
  },
  主页: function() {
    var p = Number(MY_PAGE || 1) || 1;
    var cls = parse._cls();
    var extra = cls && cls !== '0' ? '&categories=' + cls : '';
    var arr = parse._api(p, extra);
    if (arr.length) return parse._cards(arr);
    if (p > 1) return [];
    return [parse._item('加载失败，点我重试', '', parse.host + '/', '网络异常或接口不可达', 'text_center_1')];
  },
  搜索: function(name) {
    var q = parse._kw(name || MY_URL || '');
    q = q.replace(/^ +| +$/g, '');
    if (!q) return [parse._item('请输入关键词', '', 'hiker://empty', '模特/机构/番号', 'text_1')];
    var p = Number(MY_PAGE || 1) || 1;
    var arr = parse._api(p, '&search=' + q);
    if (arr.length) return parse._cards(arr);
    if (p > 1) return [];
    return [parse._item('未找到「' + q + '」', '', 'hiker://empty', '换个词试试', 'text_center_1')];
  },
  二级: function(url) {
    var u = parse._str(url || MY_URL || input || '');
    if (u.indexOf('pics://') === 0 || u.indexOf('@lazyRule') >= 0) {
      return { detail1: '蕾丝猫', desc: '点击查看', img: '', line: ['图片'], list: [[{ title: '查看图片', url: u, desc: '', img: '' }]] };
    }
    return { detail1: '蕾丝猫', desc: '', img: '', line: ['图片'], list: [[{ title: '暂无内容', url: 'hiker://empty', desc: '', img: '' }]] };
  },
  解析: function(url) {
    var u = parse._str(url || MY_URL || input || '');
    if (!u) return 'toast://空地址';
    if (u.indexOf('pics://') === 0 || u.indexOf('toast://') === 0 || u.indexOf('hiker://') === 0 || u.indexOf('@lazyRule') >= 0) return u;
    return u;
  }
};
