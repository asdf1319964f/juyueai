var parse = {
  作者: 'NULL',
  版本: '20260910v3',
  名称: '大图居',
  host: 'https://m.datuju.com',
  UA: 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
  页码: { 主页: 1, 搜索: 1 },
  /* 分类走聚阅原生 tab，class_url 即站点路径 meinv/mote/bizhi */
  静态分类: { type: '主页', url: 'fyclass', class_name: '美女图片&美女模特&高清壁纸', class_url: 'meinv&mote&bizhi' },
  /* 统一 GET：固定 UA/Referer/禁 gzip/超时，失败回空串 */
  _req: function(u) {
    try {
      return request(u, { headers: { 'User-Agent': this.UA, Referer: 'https://m.datuju.com/', 'Accept-Encoding': 'identity' }, timeout: 15000 }) || '';
    } catch (e0) {
      return '';
    }
  },
  /* 去标签与实体，得到纯文本标题 */
  _text: function(s) {
    return String(s || '').replace(/<[^>]+>/g, '').replace(/&nbsp;|&#160;/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/[ \t\r\n]+/g, ' ').replace(/^\s+|\s+$/g, '');
  },
  /* 清洗搜索词：站点只接受汉字/字母/数字 */
  _kw: function(s) {
    return String(s || '').replace(/[^a-zA-Z0-9\u4e00-\u9fa5]+/g, '');
  },
  /* 列表卡片：a[href$=.html] 内取 data-src 封面与 h3/alt 标题 */
  _list: function(html) {
    var s = String(html || ''), out = [], seen = {}, re = /<a[^>]+href="([^"]*\/(\d+)\.html)"[^>]*>([\d\D]*?)<\/a>/gi, m;
    while ((m = re.exec(s))) {
      if (seen[m[1]]) continue;
      var block = m[3] || '';
      var im = block.match(/data-src="([^"]+)"/i) || block.match(/src="(https?:\/\/file\.datuju\.net\/[^"]+)"/i);
      if (!im) continue;
      var tm = block.match(/<h3>([\d\D]*?)<\/h3>/i);
      var title = tm ? this._text(tm[1]) : '';
      if (!title) {
        var am = block.match(/alt="([^"]*)"/i);
        title = am ? this._text(am[1]) : '';
      }
      if (!title) continue;
      seen[m[1]] = 1;
      out.push({ id: m[2], href: m[1], img: im[1], title: title });
    }
    return out;
  },
  /* 详情页直出 pics://：图集走 bmore 全量文件名，壁纸走下载链/picBox */
  _openPics: function(href) {
    return $('#noLoading#').lazyRule(function(u, ua, host) {
      var html = '';
      try { html = request(u, { headers: { 'User-Agent': ua, Referer: host + '/', 'Accept-Encoding': 'identity' }, timeout: 15000 }) || ''; } catch (e0) {}
      if (!html) return 'toast://页面加载失败，请重试';
      var infoM = html.match(/data-info="([^"]*)"/i);
      var parts = infoM ? String(infoM[1]).split('l') : [];
      var picM = html.match(/<img[^>]+id="picBox"[^>]*>/i);
      var first = '';
      if (picM) { var sm = picM[0].match(/src="([^"]+)"/i); first = sm ? sm[1] : ''; }
      var idm = u.match(/\/(\d+)\.html/i);
      var id = parts[0] || (idm ? idm[1] : '');
      if (parts.length >= 6 && id) {
        var folder = parts[5] || '', raw = '';
        try { raw = request(host + '/library/bmore.php?id=' + id + '&uid=0', { headers: { 'User-Agent': ua, Referer: u, 'Accept-Encoding': 'identity' }, timeout: 15000 }) || ''; } catch (e1) {}
        var names = [];
        try { var j2 = JSON.parse(raw); if (j2 && j2.content) names = String(j2.content).split(','); } catch (e2) {}
        var pics = [];
        for (var i = 0; i < names.length; i++) { if (names[i]) pics.push('https://file.datuju.net/b/' + folder + names[i] + '.jpg'); }
        if (pics.length) return 'pics://' + pics.join('&&');
      }
      var dl = html.match(/href="(https:\/\/file\.datuju\.net\/w\/[^"]+)"/i);
      if (dl) return 'pics://' + dl[1];
      if (first) return 'pics://' + first;
      return 'toast://暂无图片';
    }, href, this.UA, this.host);
  },
  /* 模特主页：.rule 拉作品列表，每条再直出 pics */
  _openModel: function(href) {
    return $('#noLoading#').rule(function(mu, ua, host) {
      var html = '';
      try { html = request(mu, { headers: { 'User-Agent': ua, Referer: host + '/', 'Accept-Encoding': 'identity' }, timeout: 15000 }) || ''; } catch (e0) {}
      var out = [], seen = {}, re = /<a[^>]+href="([^"]*\/(\d+)\.html)"[^>]*>([\d\D]*?)<\/a>/gi, m;
      while ((m = re.exec(html))) {
        if (seen[m[1]]) continue;
        var block = m[3] || '';
        var im = block.match(/data-src="([^"]+)"/i);
        if (!im) continue;
        var tm = block.match(/<h3>([\d\D]*?)<\/h3>/i);
        var title = tm ? String(tm[1]).replace(/<[^>]+>/g, '').replace(/[ \t\r\n]+/g, ' ').replace(/^ +| +$/g, '') : '';
        if (!title) continue;
        seen[m[1]] = 1;
        out.push({
          title: title,
          img: im[1],
          col_type: 'movie_3',
          url: $('#noLoading#').lazyRule(function(u, uag, hs) {
            var h2 = '';
            try { h2 = request(u, { headers: { 'User-Agent': uag, Referer: hs + '/', 'Accept-Encoding': 'identity' }, timeout: 15000 }) || ''; } catch (e1) {}
            if (!h2) return 'toast://页面加载失败，请重试';
            var infoM = h2.match(/data-info="([^"]*)"/i);
            var parts = infoM ? String(infoM[1]).split('l') : [];
            var picM = h2.match(/<img[^>]+id="picBox"[^>]*>/i);
            var first = '';
            if (picM) { var sm = picM[0].match(/src="([^"]+)"/i); first = sm ? sm[1] : ''; }
            var idm = u.match(/\/(\d+)\.html/i);
            var id = parts[0] || (idm ? idm[1] : '');
            if (parts.length >= 6 && id) {
              var folder = parts[5] || '', raw = '';
              try { raw = request(hs + '/library/bmore.php?id=' + id + '&uid=0', { headers: { 'User-Agent': uag, Referer: u, 'Accept-Encoding': 'identity' }, timeout: 15000 }) || ''; } catch (e2) {}
              var names = [];
              try { var j2 = JSON.parse(raw); if (j2 && j2.content) names = String(j2.content).split(','); } catch (e3) {}
              var pics = [];
              for (var i = 0; i < names.length; i++) { if (names[i]) pics.push('https://file.datuju.net/b/' + folder + names[i] + '.jpg'); }
              if (pics.length) return 'pics://' + pics.join('&&');
            }
            if (first) return 'pics://' + first;
            return 'toast://暂无图片';
          }, m[1], ua, host)
        });
      }
      if (!out.length) out.push({ title: '暂无作品', col_type: 'text_center_1', url: 'hiker://empty' });
      setResult(out);
    }, href, this.UA, this.host);
  },
  /* 列表项转卡片：模特索引走 rule 列表，图集/壁纸直出 pics */
  _cards: function(a, asModel) {
    var d = [];
    for (var j = 0; j < a.length; j++) {
      d.push({
        title: a[j].title,
        img: a[j].img,
        col_type: 'movie_3',
        url: asModel ? this._openModel(a[j].href) : this._openPics(a[j].href)
      });
    }
    return d;
  },
  /* 主页：MY_URL=分类路径，翻页 /list_N.html；mote 首页是模特索引 */
  主页: function() {
    var paths = ['meinv', 'mote', 'bizhi'];
    var p = Number(MY_PAGE || 1);
    var path = String(MY_URL || '');
    if (paths.indexOf(path) < 0) {
      var mm = path.match(/(meinv|mote|bizhi)/);
      path = mm ? mm[1] : 'meinv';
    }
    var u = p > 1 ? this.host + '/' + path + '/list_' + p + '.html' : this.host + '/' + path + '/';
    var html = this._req(u);
    var a = this._list(html);
    var asModel = false;
    if (!a.length && path === 'mote') {
      asModel = true;
      var nr = /<a[^>]+href="([^"]*\/mote\/[a-z0-9]+\/)"[^>]*>[ \t\r\n]*<img[^>]+data-src="([^"]+)"[^>]*>[ \t\r\n]*<i>([\d\D]*?)<\/i>/gi, nm;
      a = [];
      while ((nm = nr.exec(html))) {
        a.push({ href: nm[1], img: nm[2], title: this._text(nm[3]) });
      }
    }
    if (a.length) return this._cards(a, asModel);
    if (p > 1) return [];
    return [{ title: '‘‘’’加载失败，点我重试', desc: '网络异常或站点不可达', col_type: 'text_center_1', url: this.host + '/' + path + '/' }];
  },
  /* 搜索：POST /library/search.php，tid 0=美女 1=壁纸；翻页走 MY_PAGE */
  搜索: function(name) {
    var q = this._kw(name || MY_URL || '');
    if (!q) return [{ title: '‘‘’’请输入关键词', desc: '只支持汉字、字母、数字', col_type: 'text_1', url: 'hiker://empty' }];
    var h = 'dtjs_', d = [], cur = getMyVar(h + 'tid', '0'), tabs = ['美女图片', '高清壁纸'];
    if (getMyVar(h + 'kw') !== q) putMyVar(h + 'kw', q);
    var p = Number(MY_PAGE || 1) || 1;
    for (var i = 0; i < tabs.length; i++) {
      d.push({
        title: String(i) === cur ? '❆ ' + tabs[i] + ' ❆' : tabs[i],
        url: $('#noLoading#').lazyRule(function(idx, key) {
          putMyVar(key + 'tid', idx + '');
          refreshPage(false);
          return 'hiker://empty';
        }, i, h),
        col_type: 'scroll_button'
      });
    }
    d.push({ col_type: 'blank_block' });
    var raw = '';
    try {
      var payload = '{"str":"' + q + '","tid":' + (Number(cur) || 0) + ',"page":' + p + '}';
      raw = post(this.host + '/library/search.php', {
        body: payload,
        headers: {
          'User-Agent': this.UA,
          Referer: 'https://m.datuju.com/search.php',
          'Content-Type': 'application/json',
          'Accept-Encoding': 'identity'
        },
        timeout: 15000
      }) || '';
    } catch (e0) {}
    raw = String(raw || '').replace(/^\uFEFF/, '');
    var arr = [];
    try {
      var j = JSON.parse(raw);
      arr = this._list(j.content || '');
    } catch (e1) {}
    if (arr.length) {
      for (var k = 0; k < arr.length; k++) {
        d.push({ title: arr[k].title, img: arr[k].img, col_type: 'movie_3', url: this._openPics(arr[k].href) });
      }
    } else if (p === 1) {
      d.push({ title: '‘‘’’未找到「' + q + '」', desc: '换个关键词或切到另一个分类', col_type: 'text_center_1', url: 'hiker://empty' });
    }
    return d;
  }
};
