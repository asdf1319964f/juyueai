# 聚阅/海阔仿真测试框架（无规则版）

在 PC 上模拟聚阅/海阔视界 App 的规则运行环境，验证规则函数（主页/分类/搜索/二级/解析）输出、lazyRule/rule 回调序列化、App 消费行为。**开发站点规则的必备门禁**。

## 快速开始

```bash
# 自检（确认环境可用）
node test_demo_norule.js

# 跑一个规则的全部静态分类 + 详情 + 断言 + 真机级点击仿真
node run.js /path/to/rule.js --all-cats --detail auto --assert --device

# 只跑单个分类
node run.js /path/to/rule.js --cat app_home_tj --device --assert

# 生成 HTML UI 模拟报告（看列表/封面渲染效果）
node run.js /path/to/rule.js --cat fyclass --ui --resolve-images
```

退出码：`0` = 无问题，`1` = 有问题（--assert 时）。

## 仿真能力全景

| 能力 | 说明 |
|---|---|
| 主页/分类/搜索/二级/解析执行 | 调规则函数，检查返回数组结构（n/首条/col_type 分布） |
| `pdfa/pdfh/pd` DOM 解析 | cheerio 实现 |
| `fetch/request/post` 网络 | curl 直连 |
| `juItem/putMyVar/getMyVar` 存储 | 内存模拟 |
| `$().lazyRule/rule/image/input` | 链式回调 |
| **回调序列化（--device）** | Hikerurl toStringFun → 独立上下文执行，抓闭包引用/parse 未定义/反斜杠/换行/@lazyRule 双标记 |
| **App 消费模型（--device）** | 模拟聚阅 App 怎么消费数组：详情模式只认 `""视频""`/`""音频""` 线路标记、col_type 点击性（text_4 不可点）、MY_URL 数字格式翻页审计 |
| CryptoJS/AES/Base64/图片 @js= | assets/aes.js + crypto-java.js 模拟 |
| gzip 自动解压 | 内置 |

## 新增：App 消费模型（lib/app_consume.js）

**为什么需要**：规则函数返回数组 ≠ 真机页面。聚阅 App 会按自己的逻辑消费数组，仿真必须复刻：

- **详情模式**：数组含 movie_1/pic_1 等详情卡 → App 进入详情页，只把带 `""视频""`/`""音频""` 前缀 title 的项当线路，其余忽略 → 无标记则「线路列表为空」（真实案例：糖心 v9/v10）
- **列表模式**：无详情卡 → 所有 `{title,url}` 可点击
- **col_type 点击性**：text_4/text_2/line 等展示样式不触发 url；无 col_type 的 `{title,url}` 默认可点击
- **MY_URL 翻页格式**：聚阅把 fyclass/fypage 替换成数字（`0/1`、`1/2`），规则若只认 `fyclass(\d+)` 会解析失败（真实案例：糖心 v12）

`--device` 模式下自动跑：id 列表项 → 二级 → 线路提取 → 线路项序列化点击 → 播放项可点性 + 翻页 2 页首条对比。

## 仿真测不出的边界（务必真机验证）

1. **Java 运行时**：沙箱 Node 没有 javax./java.io./hiker://assets/crypto-java.js 真实现（有模拟，但方法名/行为可能与真机 Rhino 不同——如 CryptoUtil.AES.encrypt 方法名、大文件字符串中转损坏）
2. **性能**：Node JIT vs 聚阅 Rhino 解释执行——纯 JS AES 解大图在真机慢 50-100 倍，会发热/卡 UI（真实案例：糖心 v5）
3. **网络风控**：沙箱 IP 可能被站点限流/CAPTCHA，真机 IP 正常；服务端静默拒绝（status:n 空）仿真可能误报
4. **引擎细节**：详情模式的精确触发条件、@lazyRule= 超长 URL 的硬上限（序列化后体积参考 <5KB）

## 规则开发规范（硬性交付要求）

1. **禁注释、禁 `log()`** —— 成品规则不能有调试代码
2. **必须先过沙箱门禁再交付**：`node run.js rule.js --all-cats --detail auto --assert --device` 必须 ISSUES 0
3. **最小改动**：只改必要的，其余不动
4. **静态大分类 + 子筛选矩阵**：大分类走 App tab（MY_URL token 路由），页面内只放子筛选矩阵，tag 不进 class_url
5. **解析点必有降级链**：错误返回 `toast://` 或占位节点，不能白屏
6. **音频一律 `video://` + `#isVideo=true#`**，禁 `isMusic`

## 常见坑清单（血泪教训）

| 坑 | 现象 | 规避 |
|---|---|---|
| lazyRule/image 回调引用闭包变量（self.xxx） | 真机 ReferenceError/空白（回调延迟求值，闭包丢失） | 回调内只用 App 全局（getMyVar/input）+ 硬编码字面量 + 显式烘焙参数 |
| 回调序列化体积过大 | 真机回调不执行 | 大数组（SBOX 等）base64 压缩 + 函数单行化，序列化后 <5KB（dasai 3KB 参考） |
| 二级播放项用 text_4/text_2 col_type | 点击不触发解析 | 播放项 = `{title, url}` 不带 col_type，title 带 `""视频""` 前缀（线路标记） |
| 二级有 movie_1 详情卡但播放项无线路标记 | 「线路列表为空」 | 详情模式只认 `""视频""` 标记项 |
| 顶层函数 this. 引用 | this 绑定不可靠 | 统一 `parse.xxx` 显式引用 |
| 主页写死 page=1 | 不能翻页 | 解析 MY_URL + MY_PAGE |
| MY_URL 只认 fyclass(\d+) | 聚阅替换成数字后解析失败 | `/^(\d+)/` 优先 + fyclass 兜底 |
| 纯 JS AES 解大图 | 发热/卡 UI | 用 Java Cipher/CryptoUtil（毫秒级） |
| 字符串拼代码时 \s 坍缩 | 正则失效 | 用 .trim() 归零反斜杠 |
| 图片/文件大小时 Java 字符串中转损坏 | 大文件解密失败 | 字节级处理（ByteArrayInputStream 等） |
| 封面明文 PNG/Base64 WebP 双态 | 解码失败 | 魔数判断 + 双态兼容 |
| **gzip 乱码全空**（幻宇 v2） | 真机列表空但沙箱正常 | 所有 fetch 加 `Accept-Encoding: identity`；服务器对 gzip 请求可能返回压缩响应 |
| **慢接口超时**（幻宇 v2） | 二级空白，日志无 len 输出 | fetch 必带 timeout；能点播就别依赖慢速二级 |
| **JSoup 嵌套只出 1 条**（幻宇 v2） | 列表只解析 1 条 | `html.split('</article>')` 字符串切割 + 逐段正则 |
| **回调内无 pdfa/pd**（幻宇 v2） | lazyRule 点击返回 undefined | 回调内用全局 API + 内联正则，禁止 pdfa/pd |
| **WordPress 封面 data-bg**（幻宇 v2） | 封面空白 | `data-bg` → `background url()` → img 三级提取 |
| **烘焙实参作用域泄漏**（sjs host / maomi self） | 真机 `ReferenceError: host/self 未定义，行数N` | `$.toString(fn, arg)`/`.rule(fn, arg)` 的 arg 必须在当前书写位置作用域可见；嵌套回调只见自身参数+烘焙字面量+平台全局。→ v4 起门禁 scope_leak 致命拦截 |
| **Discuz 登录特征 cookie 想当然**（sjs） | X5 轮询永不命中，登录后无反应 | 先 curl 实勘 Set-Cookie；Discuz 是 `{随机前缀}_{版本}_auth`，无 discuz_uid；正则匹配任意前缀 + 手动兜底按钮必配 |
| **m3u8 带 ;{Header} 触发 clearM3u8 代理**（hxq_v1） | CDN 无防盗链却播放失败 | 无防盗链站点用纯 video:// 直链，不加 Header 尾巴（v4 门禁 header_tail 提示） |
| **多行 .rule() 链源码**（sjs 实测） | 真机可正常打开（非致命） | 可用但建议单行化；v4 门禁降为 warn 不计入 ISSUES |

## 规则开发范式（架构模板）

```js
var parse = {
  作者: 'NULL',            // 别改成自己的名，防白嫖
  版本: 'YYYYMMDDv1',
  名称: '站点名',
  页码: { 主页: 1, 分类: 1, 搜索: 1 },
  静态分类: {
    type: '主页',
    url: 'fyclass/fypage',
    class_name: '分类1&分类2',
    class_url: 'path1&path2'
  },
  _ensureAuth: function () { /* 鉴权/换 token，缓存 getMyVar/putMyVar */ },
  _api: function (path, data, token, did) { /* 统一请求封装，含加密/签名 */ },
  _imgLazy: function () { /* 封面解密 lazy（回调内零闭包引用） */ },
  _oneItem: function (it, lazy) { /* 列表项统一构造 */ },
  主页: function () { /* 解析 MY_URL 拿分类 + MY_PAGE 翻页 */ },
  分类: function () { /* 同上，可复用 _items */ },
  搜索: function (name) { /* 搜索 + 翻页 */ },
  二级: function (id) { /* 详情：标题 + 播放项 {title: '""视频""xx', url: lazyRule链} */ },
  解析: function (url) { /* 漫画/图集：返回 pics:// 或 video:// */ }
};
```

**要点**：
- 列表项 url 用 `parse._xxxLazy(id, token)` lazyRule 链 → 点击直接播放（跳过二级，聚阅最稳）
- 回调内联所需算法（AES 等），零外部引用
- 失败分支返回 `toast://` 合理提示
- 交付前删 log/注释

## 模块地图

```
run.js                 CLI 入口（--all-cats/--cat/--detail/--ui/--assert/--device/--cf）
lib/engine.js          规则沙箱核心：Chain 链对象、$().lazyRule/rule/image、runHome/runDetail
lib/device_sim.js      真机级序列化：toStringFun、hygieneCheck、simulateClick（独立上下文执行）
lib/app_consume.js     App 消费模型：extractLines/clickable/auditDetailConsume/auditPaging
lib/crypto_java.js     CryptoUtil 模拟（crypto-java.js 的 Node 版）
lib/real_sim.js        图片 @js= 解密执行
lib/http.js            网络（curl）
lib/dom.js             pdfa/pdfh DOM 解析
lib/hiker_url.js       Hikerurl 序列化
lib/juyue_hiker.js     聚阅宿主 API 注入
lib/juyue_host.js      站点/CF 诊断
lib/webview*.js        WebView 渲染模拟
lib/ui_sim.js          UI 报告
lib/storage.js         juItem/getMyVar 存储
lib/cf_detect.js       Cloudflare 诊断
assets/                海阔内置 JS：Hikerurl.js/aes.js/crypto-java.js/help_*.json/plugin.js
test_rules/            测试规则（fake_v9 复刻坑、fake_ok 正确范式）
```

## 自带测试规则

```bash
# fake_v9：复刻「详情模式无线路标记 → 线路列表为空」+ 翻页失效
node run.js test_rules/fake_v9.js --cat a --device --assert   # 期望 ISSUES 3（两条线路空 + 翻页）

# fake_ok：正确范式（""视频"" 标记 + lazyRule 链 + 翻页变化）
node run.js test_rules/fake_ok.js --cat a --device --assert    # 期望 ISSUES 0
```

## 交付物格式

- 规则文件：`/var/minis/mounts/juyue/rules/<站点>_v<N>.js`（直达用户 /sdcard/Download/juyue/rules/）
- 交付前：`node --check` 语法 + `node run.js ... --device --assert` 门禁 + 禁 log/注释扫描
- 历史版本保留可回滚，新版本新文件名

## v5 新增目录（2026-08-27 全量备份）

- `skills/spa-api-probe/SKILL.md` — SPA 站 API 实锤技能（firecrawl_agent 流程 + 已踩坑）
- `rules_backup/` — 今日交付规则备份：javhd_v9.js（JAVHD 最终版）/ katovideo_v3.js（加藤）/ 91sp_v3.js
- `notes/2026-08-27_工作总结.md` — 全天总结
- `projects/javhd/` — JAVHD 破解工作目录（chunk JS/模块/脚本）
- `projects/katovideo/` — 加藤破解工作目录（协议脚本/解密工具）
