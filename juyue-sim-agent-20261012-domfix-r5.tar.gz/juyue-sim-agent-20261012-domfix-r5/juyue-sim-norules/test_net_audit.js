// test_net_audit.js — 网络风险审计（gzip / timeout）回归测试
//
//   node test_net_audit.js          用包内 demo-rules/netrisk_fixture.js
//   node test_net_audit.js <规则.js> 只打印该规则的风险条目
//
// 期望表与 fixture 里的 [Cn] 注释一一对应。失败时退出码 1。
const fs = require('fs');
const path = require('path');
const risk = require('./lib/risk_audit');

const FIXTURE = path.join(__dirname, '..', 'demo-rules', 'netrisk_fixture.js');

// 用例 → [gzip, timeout, net_unverified, slow_html]
const EXPECT = {
  c1:  [1, 1, 0, 0],   // 裸网络请求
  c2:  [0, 0, 0, 0],   // 内联完整 opts
  c3:  [0, 0, 0, 0],   // 本地文件字面量
  c4:  [0, 0, 0, 0],   // 变量指向本地文件
  c5:  [0, 0, 0, 0],   // 先声明后赋值 + 拼接的本地路径
  c6:  [0, 0, 0, 0],   // parse 属性指向本地文件
  c7:  [0, 0, 1, 0],   // opts 来自函数调用
  c8:  [1, 1, 0, 0],   // 拼接的网络地址，无 opts
  c9:  [0, 0, 0, 0],   // 拼接的本地路径
  c10: [0, 0, 0, 0],   // 多行 opts
  c11: [0, 0, 0, 0],   // 经封装方法调用
  c12: [1, 1, 0, 1],   // 详情页 html 无 opts
  c13: [1, 0, 0, 0],   // 详情页 html 只带 timeout
  c14: [0, 0, 0, 0],   // parse 上的对象字面量 opts
  c15: [0, 0, 1, 0],   // 通用包装函数
  c16: [0, 0, 1, 0]    // headers 由函数生成
};

if (process.argv[2]) {
  const f = process.argv[2];
  const all = risk.auditNetworkRisk(f).concat(risk.auditSlowAnnotate(f));
  console.log(f + ' → ' + all.length + ' 条');
  all.forEach((it) => console.log('  L' + (it.line || '?') + ' [' + it.kind + '] ' + it.snippet));
  process.exit(0);
}

const lines = fs.readFileSync(FIXTURE, 'utf8').split('\n');

function caseOf(issue) {
  for (let i = (issue.line || 1) - 1; i >= 0; i--) {
    const m = lines[i].match(/\[C(\d+)\]/i) || lines[i].match(/^\s*c(\d+)\s*:/);
    if (m) return 'c' + m[1];
  }
  return '?' + issue.line;
}

const got = {};
Object.keys(EXPECT).forEach((k) => { got[k] = [0, 0, 0, 0]; });
const IDX = { gzip: 0, timeout: 1, net_unverified: 2, slow_html: 3 };
const unknown = [];

function tally(list) {
  list.forEach((it) => {
    const k = caseOf(it);
    if (!got[k]) got[k] = [0, 0, 0, 0];
    if (IDX[it.kind] == null) { unknown.push(it.kind + ' @' + k); return; }
    got[k][IDX[it.kind]]++;
  });
}
tally(risk.auditNetworkRisk(FIXTURE));
tally(risk.auditSlowAnnotate(FIXTURE));

let pass = 0, fail = 0;
console.log('用例   期望[gzip,timeout,unverified,slow]      实际');
Object.keys(EXPECT).forEach((k) => {
  const e = EXPECT[k], g = got[k] || [0, 0, 0, 0];
  const ok = e.join() === g.join();
  if (ok) pass++; else fail++;
  console.log((ok ? '  ✓ ' : '  ✗ ') + k.padEnd(6) + '[' + e.join(',') + ']'.padEnd(10) +
    '  [' + g.join(',') + ']');
});
unknown.forEach((u) => { console.log('  ⚠ 未知 kind: ' + u); fail++; });

console.log('\n通过 ' + pass + ' / 失败 ' + fail);
process.exit(fail ? 1 : 0);
