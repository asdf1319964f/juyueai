var parse = {
  作者: 'NULL',
  版本: '20260910v2',
  名称: '新91大赛',
  host: 'https://d1vdowt4mkcgyq.cloudfront.net',
  UA: 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
  页码: { 主页: 1, 分类: 0, 排行: 0, 更新: 1, 搜索: 1 },
  频道: { 页面标识: '#immersiveTheme#' },
  静态分类: {
    type: '主页',
    url: 'hiker://empty##/fyclassfypage',
    class_name: '首页&往期&标签&今日大赛&热搜大赛&学院大赛&女神大赛&网红大赛&明星大赛&奇闻大赛&乱伦大赛&撸友大赛&女同大赛&污漫大赛',
    class_url: 'page/&archives/&tags/&category/jrds/&category/rsds/&category/xyds/&category/nsds/&category/whds/&category/mxds/&category/qwds/&category/llds/&category/lyds/&category/ntds/&category/wmds/'
  },
  _str: function(x) {
    if (x == null) return '';
    try {
      if (typeof x === 'string') return x;
      if (x.toString) return String(x.toString());
    } catch (e0) {}
    return String(x);
  },
  _host: function() {
    var h = '';
    try { h = String(juItem.get('吃瓜link') || ''); } catch (e0) { h = ''; }
    if (!h) h = parse.host;
    return h.replace(/\/+$/, '');
  },
  _hdr: function() {
    return {
      'User-Agent': parse.UA,
      Referer: parse._host() + '/',
      Accept: 'text/html,application/xhtml+xml',
      'Accept-Encoding': 'identity'
    };
  },
  _html: function(url) {
    var html = '';
    try { html = request(url, { headers: parse._hdr(), timeout: 20000 }) || ''; } catch (e0) {}
    if (!html) {
      try { html = fetch(url, { headers: parse._hdr(), timeout: 20000 }) || ''; } catch (e1) {}
    }
    return html == null ? '' : String(html);
  },
  _alive: function(url) {
    var html = parse._html(url);
    return html.indexOf('Xc_home_article') >= 0 || html.indexOf('CDN_XHOST') >= 0 || html.indexOf('吃瓜') >= 0;
  },
  预处理1: function() {
    var cur = '';
    try { cur = String(juItem.get('吃瓜link') || ''); } catch (e0) { cur = ''; }
    if (cur && parse._alive(cur + '/')) return;
    var cands = [
      'https://d1vdowt4mkcgyq.cloudfront.net',
      'https://www.dycg66.com',
      'https://dycg66.com',
      'https://xwtnzybd.cc'
    ];
    var i;
    for (i = 0; i < cands.length; i++) {
      if (parse._alive(cands[i] + '/')) {
        try { juItem.set('吃瓜link', cands[i]); } catch (e1) {}
        parse.host = cands[i];
        return;
      }
    }
  },
  _cdn: function(html) {
    var cached = '';
    try { cached = String(juItem.get('吃瓜图片头') || ''); } catch (e0) { cached = ''; }
    var m = String(html || '').match(/CDN_XHOST\s*:\s*["']([^"']+)["']/);
    var cdn = m ? String(m[1]).replace(/\\\//g, '/') : cached;
    if (!cdn) cdn = 'https://pic.ndhixj.cn';
    cdn = cdn.replace(/\\/g, '').replace(/\/+$/, '');
    try { juItem.set('吃瓜图片头', cdn); } catch (e1) {}
    return cdn;
  },
  _imgDec: function() {
    return $('').image(function() {
      try {
        var CryptoUtil = $.require('hiker://assets/crypto-java.js');
        var key = CryptoUtil.Data.parseUTF8('f5d965df75336270');
        var iv = CryptoUtil.Data.parseUTF8('97b60394abc2fbe1');
        var textData = CryptoUtil.Data.parseInputStream(input);
        var decrypted = CryptoUtil.AES.decrypt(textData, key, { mode: 'AES/CBC/NoPadding', iv: iv });
        return decrypted.toInputStream();
      } catch (e) { return input; }
    });
  },
  _pic: function(raw, cdn) {
    var pic = String(raw || '').replace(/\\\//g, '/');
    if (!pic) return '';
    if (pic.indexOf('http') === 0) {
      pic = pic.replace(/https?:\/\/(www\.)?dycg66\.com/i, cdn);
      pic = pic.replace(/https?:\/\/pic\.(jjlxoi|sbhioa|ndhixj)\.cn/i, cdn);
      return pic;
    }
    if (pic.charAt(0) !== '/') pic = '/' + pic;
    return cdn + pic;
  },
  _attr: function(html, key) {
    var s = String(html || ''), m;
    m = s.match(new RegExp(key + '\\s*=\\s*"([^"]+)"', 'i'));
    if (m) return m[1];
    m = s.match(new RegExp(key + "\\s*=\\s*'([^']+)'", 'i'));
    return m ? m[1] : '';
  },
  _cards: function(html) {
    var d = [], items = [], i, title, pic, href, desc, cdn, img;
    cdn = parse._cdn(html);
    try { items = pdfa(html, '.Xc_home_article-list&&li') || []; } catch (e0) { items = []; }
    if (!items.length) {
      var parts = String(html).split(/class="[^"]*Xc_home_article-si/);
      for (i = 1; i < parts.length; i++) items.push(parts[i]);
    }
    for (i = 0; i < items.length; i++) {
      try { title = pdfh(items[i], '.title&&Text') || pdfh(items[i], 'a&&title') || ''; } catch (e1) { title = ''; }
      if (!title) title = parse._attr(items[i], 'title') || parse._attr(items[i], 'alt');
      title = String(title).replace(/^ +| +$/g, '');
      if (!title || title === '热搜 HOT') continue;
      try { href = pdfh(items[i], 'a&&href'); } catch (e2) { href = ''; }
      if (!href) href = parse._attr(items[i], 'href');
      if (!href || href.indexOf('/archives/') < 0) continue;
      try { pic = pdfh(items[i], 'img&&data-src'); } catch (e3) { pic = ''; }
      if (!pic) {
        try { pic = pdfh(items[i], 'script&&Html'); } catch (e4) { pic = ''; }
        if (pic) {
          var mm = String(pic).match(/https?:[^"'\\ ]+/);
          pic = mm ? mm[0].replace(/\\/g, '') : '';
        }
      }
      if (!pic) pic = parse._attr(items[i], 'data-src');
      img = parse._pic(pic, cdn);
      try { desc = pdfh(items[i], '.last&&Text') || ''; } catch (e5) { desc = ''; }
      d.push({
        title: title,
        desc: desc,
        img: img ? img + parse._imgDec() : '',
        pic_url: img ? img + parse._imgDec() : '',
        url: href,
        extra: { title: title, desc: desc, img: img ? img + parse._imgDec() : '', url: href },
        col_type: 'pic_1_card'
      });
    }
    return d;
  },
  _m3u8: function(html) {
    var out = [], i, cfg, raw, j, u, items = [];
    try { items = pdfa(html, 'body&&.dplayer') || []; } catch (e0) { items = []; }
    if (!items.length) {
      var parts = String(html).split(/class="dplayer"/);
      for (i = 1; i < parts.length; i++) items.push(parts[i]);
    }
    for (i = 0; i < items.length; i++) {
      try { cfg = pdfh(items[i], '.dplayer&&data-config') || parse._attr(items[i], 'data-config'); } catch (e1) { cfg = parse._attr(items[i], 'data-config'); }
      cfg = String(cfg || '');
      cfg = cfg.replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/\\u0026/g, '&').replace(/\\\//g, '/');
      u = '';
      try {
        j = JSON.parse(cfg);
        if (j && j.video && j.video.url) u = String(j.video.url);
      } catch (e2) {}
      if (!u) {
        raw = cfg.match(/https?:[^"']+\.m3u8[^"']*/);
        if (raw) u = raw[0];
      }
      u = String(u || '').replace(/\\u0026/g, '&').replace(/&amp;/g, '&');
      if (!u) continue;
      out.push(u);
    }
    return out;
  },
  主页: function() {
    var raw = '';
    try { raw = String(MY_URL || ''); } catch (e0) { raw = ''; }
    var path = raw.indexOf('##') >= 0 ? raw.split('##')[1] : raw;
    if (!path) path = '/page/';
    if (path.charAt(0) !== '/') path = '/' + path;
    var p = Number(MY_PAGE || 1) || 1;
    if (/\/page\/$/.test(path) && p > 1) path = '/page/' + p + '/';
    if (/\/page\/$/.test(path) && p === 1) path = '/';
    var host = parse._host();
    var url = host + path;
    if (/archives/.test(path) && p === 1) url = host + '/archives.html';
    var html = parse._html(url);
    if (!html) return [{ title: '加载失败', desc: url, img: '', pic_url: '', url: 'hiker://empty', col_type: 'text_center_1' }];
    parse._cdn(html);
    if (/\/archives/.test(path)) {
      var list = [], i, item;
      try { list = pdfa(html, '#archives-content&&li') || []; } catch (e1) { list = []; }
      var d = [];
      for (i = 0; i < list.length; i++) {
        try { item = { title: pdfh(list[i], 'Text'), url: pdfh(list[i], 'a&&href') }; } catch (e2) { continue; }
        d.push({ title: item.title, desc: '', img: '', pic_url: '', url: item.url, extra: { title: item.title, desc: '', url: item.url }, col_type: 'text_1' });
      }
      return d;
    }
    if (/\/tags/.test(path) && path.replace(/\/+$/, '') === '/tags') {
      var tags = [], t;
      try { tags = pdfa(html, '.tags-list&&a') || []; } catch (e3) { tags = []; }
      var out = [];
      for (i = 0; i < tags.length; i++) {
        try { t = { title: pdfh(tags[i], 'Text'), url: pdfh(tags[i], 'a&&href') }; } catch (e4) { continue; }
        if (!t.url) continue;
        out.push({ title: t.title, desc: '', img: '', pic_url: '', url: t.url, col_type: 'text_4' });
      }
      return out.length ? out : parse._cards(html);
    }
    return parse._cards(html);
  },
  搜索: function(name) {
    var q = String(name || MY_URL || '').replace(/[\\"\r\n]+/g, '');
    q = q.replace(/^ +| +$/g, '');
    if (!q) return [{ title: '请输入关键词', desc: '', img: '', pic_url: '', url: 'hiker://empty', col_type: 'text_1' }];
    var p = Number(MY_PAGE || 1) || 1;
    var url = parse._host() + '/search/' + encodeURIComponent(q) + '/';
    if (p > 1) url += p + '/';
    return parse._cards(parse._html(url));
  },
  二级: function(surl) {
    var host = parse._host();
    var src = parse._str(surl || MY_URL || '');
    var id = '';
    var mm = src.match(/archives\/(\d+)/);
    if (mm) id = mm[1];
    if (!id) {
      try { id = String(src.split('archives')[1] || '').match(/\d+/)[0]; } catch (e0) { id = ''; }
    }
    var url = id ? host + '/archives/' + id + '/' : (src.indexOf('http') === 0 ? src : host + src);
    var html = parse._html(url);
    var cdn = parse._cdn(html);
    var title = '';
    try { title = pdfh(html, 'h1&&Text'); } catch (e1) { title = ''; }
    if (!title) {
      try { title = String(MY_PARAMS && MY_PARAMS.title || ''); } catch (e2) { title = ''; }
    }
    var plays = parse._m3u8(html);
    var playItems = [];
    var i, v;
    for (i = 0; i < plays.length; i++) {
      v = 'video://' + plays[i] + ';{Referer@' + host + '/&&User-Agent@' + parse.UA + '}';
      playItems.push({ title: '视频' + (i + 1), url: v, desc: '', img: '' });
    }
    var extend = [];
    extend.push({ title: title, desc: '', img: '', pic_url: '', url: url, col_type: 'text_center_1' });
    var imgs = [], src2;
    try { imgs = pdfa(html, 'body&&img') || []; } catch (e3) { imgs = []; }
    if (!imgs.length) {
      var rawImgs = String(html).match(/data-xkrkllgl="([^"]+)"/g) || [];
      for (i = 0; i < rawImgs.length; i++) imgs.push(rawImgs[i]);
    }
    for (i = 0; i < imgs.length; i++) {
      try { src2 = pdfh(imgs[i], 'img&&data-xkrkllgl') || pdfh(imgs[i], 'img&&data-src') || parse._attr(imgs[i], 'data-xkrkllgl'); } catch (e4) { src2 = parse._attr(imgs[i], 'data-xkrkllgl') || parse._attr(imgs[i], 'data-src'); }
      if (!src2 && /data-xkrkllgl="/.test(String(imgs[i]))) {
        var gm = String(imgs[i]).match(/data-xkrkllgl="([^"]+)"/);
        src2 = gm ? gm[1] : '';
      }
      if (!src2 || src2.indexOf('zw.png') >= 0) continue;
      src2 = parse._pic(src2, cdn);
      extend.push({ title: '', desc: '', img: src2 + parse._imgDec(), pic_url: src2 + parse._imgDec(), url: src2 + parse._imgDec(), col_type: 'pic_1_full' });
    }
    for (i = 0; i < playItems.length; i++) {
      extend.push({ title: playItems[i].title, desc: '', img: '', pic_url: '', url: playItems[i].url, col_type: 'text_2' });
    }
    var cover = '';
    try { cover = String(MY_PARAMS && MY_PARAMS.img || ''); } catch (e5) { cover = ''; }
    if (!cover && extend[1] && extend[1].img) cover = extend[1].img;
    return {
      detail1: title,
      detail2: '',
      noShow: { 简介: true, 排序: true },
      desc: title,
      img: cover,
      list: playItems.length ? playItems : [{ title: '暂无视频', url: 'hiker://empty', desc: '', img: '' }],
      extenditems: extend
    };
  },
  解析: function(url) {
    var u = parse._str(url || MY_URL || input || '');
    if (!u) return 'toast://空地址';
    return u;
  }
};
