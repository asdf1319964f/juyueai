---
name: spa-api-probe
description: 在真实浏览器里实锤 SPA 站（Vue/React 前端渲染）的 API 请求与响应结构。当规则开发遇到以下情况时使用：列表/详情是 JS 渲染（SSR HTML 无卡片）、POST API 返回未知格式、前端调用了你没找到的接口、需要确认请求方法/参数/响应字段、站点被沙箱墙掉但浏览器可达。核心手段是 firecrawl_agent 在真实浏览器里 fetch 目标 URL 并回传响应原文，绝不靠猜。
version: 1.0.0
---

# SPA 站 API 实锤

## 何时用

- SSR HTML 里找不到视频卡片/列表数据（列表是 JS 渲染的）
- 规则列表/详情空，但解析逻辑本地单测正常
- 需要确认前端到底 POST/GET 什么 URL、带什么参数
- 响应格式未知（JSON / 组件文本 / HTML）
- 沙箱被墙连不上目标站

## 核心手段

**firecrawl_agent 在真实浏览器里 fetch，回传响应原文。** 比 firecrawl_scrape（不支持自定义 method/不执行 fetch）强，比盲猜参数快一个数量级。

## 标准流程

### 1. 先确认响应是 JSON 还是 HTML（对比 GET/POST）

```json
{"prompt":"在浏览器里用 fetch 发送 POST 请求到 <URL>，设置 header X-Requested-With: XMLHttpRequest。读取响应文本，判断是 JSON 还是 HTML，返回前 300 字符。然后再用 fetch 发送 GET 请求到同一个 URL，对比返回是什么。最后告诉我结论：这个接口 POST 和 GET 分别返回什么。","maxSteps":6}
```

POST 返回 JSON + GET 返回 HTML → 前端列表走 POST API，规则必须用 POST。
两者都返回 HTML → 走页面解析（SSR/渲染后卡片）。

### 2. 实锤 POST 响应结构（列表/详情）

```json
{"prompt":"在浏览器里 fetch POST <URL> （header X-Requested-With: XMLHttpRequest）。把响应的前 2500 字符原样返回给我（不要截断，包括所有字段）。特别告诉我 template 字段的开头长什么样——是 <thumb-component 还是 <a href 还是别的格式？","maxSteps":5}
```

关键：**别让 agent 总结，要原文**。你拿到原文才能写正则。

### 3. 验证翻页参数（路径 vs query）

```json
{"prompt":"在浏览器里对 <URL> 发送 fetch POST 请求获取第2页：分别尝试 <URL?page=2>、<URL?current_page=2>、<URL/justadded/all/2>。读取每个响应的 JSON，用 video-id 或 id 判断哪个返回了与第1页不同的内容。告诉我哪个 URL 参数/路径翻页有效，返回了哪些 id（前3个）。","maxSteps":8}
```

翻页无效 = 站点单页（如实告知用户，不做伪翻页）。

### 4. 验证播放/详情两步链

```json
{"prompt":"在浏览器里 fetch <列表API> 和 <播放API>，对比两个响应。告诉我列表里的 id 是否能直接用于播放 API，还是需要先从详情页提取另一个 id。","maxSteps":5}
```

常见坑：列表 video-id ≠ 播放 cms_id（JAVHD 教训）。

## 已踩坑（2026-08-27 实锤）

1. **SPA POST API 返回 Vue 组件属性文本**：JAVHD 列表响应 `{"template":"<thumb-component video-id=... title=... url-thumb=...>"}`——不是 HTML 卡片、不是嵌套 JSON 对象。解析要按组件标签切块。
2. **同站不同页面 API 结构完全不同**：JAVHD 列表=template 字段，工作室=`{"roomVideos":[{videoId, video:{...}}]}` 对象数组。每类页面都要独立实锤。
3. **翻页靠路径不靠 query**：JAVHD `/justadded/all/2` 有效，`?page=2` 无效。
4. **firecrawl_scrape 不支持自定义 method**：POST 用 scrape 发不出去，必须用 agent。
5. **沙箱 TLS 被墙 ≠ 站点挂了**：javhd.com 沙箱 000，但 firecrawl 代理池 200——实锤前别下结论。

## 配套工具

- `firecrawl_agent`：主武器（真实浏览器 + fetch + 回传原文）
- `firecrawl_agent_status`：轮询 agent 结果（status: processing → completed，通常 60-120 秒）
- `js_reverse`：需要抓 initiator/断点看请求构造时用（站点得在沙箱浏览器可达）
- 本地 `node -e` mock：拿到真实响应后，用规则代码解析真实响应验证正则（不依赖网络）

## 铁律

1. **要原文不要总结**——prompt 明确"原样返回前 N 字符"，agent 总结会丢字段
2. **每个页面类型单独实锤**（列表/分类/工作室/详情/播放）——别假设同构
3. **拿真实响应喂本地解析单测**——规则改完先跑通真实响应再交付
4. **翻页/播放链路各实锤一次**——参数和 id 体系都要验证，别猜
