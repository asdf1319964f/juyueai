#!/bin/bash
set -e
mkdir -p /home/hermes/juyue/okfetch/lib && cd /home/hermes/juyue/okfetch/lib
B=https://repo1.maven.org/maven2
[ -f okhttp-4.9.3.jar ] || curl -sSLO $B/com/squareup/okhttp3/okhttp/4.9.3/okhttp-4.9.3.jar
[ -f okio-jvm-2.8.0.jar ] || curl -sSLO $B/com/squareup/okio/okio-jvm/2.8.0/okio-jvm-2.8.0.jar
[ -f kotlin-stdlib-1.4.10.jar ] || curl -sSLO $B/org/jetbrains/kotlin/kotlin-stdlib/1.4.10/kotlin-stdlib-1.4.10.jar
[ -f conscrypt-openjdk-uber-2.5.2.jar ] || curl -sSLO $B/org/conscrypt/conscrypt-openjdk-uber/2.5.2/conscrypt-openjdk-uber-2.5.2.jar
ls -la
