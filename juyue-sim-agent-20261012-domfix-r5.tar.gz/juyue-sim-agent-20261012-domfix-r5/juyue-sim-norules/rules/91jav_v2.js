var parse = {
  作者: 'NULL',
  版本: '20260910v2',
  名称: '91JAV',
  host: 'https://91jav.fun',
  UA: 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
  页码: { 主页: 1, 搜索: 1 },
  静态分类: {
    type: '主页',
    url: 'fyclass',
    class_name: '首页&🔥新作&黑丝&丝袜&制服&Cosplay&眼镜娘&无码高清&角色剧情&中文字幕',
    class_url: '/new/fypage&/new/fypage&/tags/142/latest/fypage&/tags/146/latest/fypage&/tags/154/latest/fypage&/tags/158/latest/fypage&/tags/147/latest/fypage&/theme/detail/11/update/fypage&/theme/detail/2/update/fypage&/theme/detail/3/update/fypage'
  },
  _str: function(x) {
    if (x == null) return '';
    try {
      if (typeof x === 'string') return x;
      if (x.toString) return String(x.toString());
    } catch (e0) {}
    return String(x);
  },
  _host: function() {
    var h = '';
    try { h = String(juItem.get('91JAVlink') || ''); } catch (e0) { h = ''; }
    if (!h) h = parse.host;
    return h.replace(/\/+$/, '');
  },
  _hdr: function(cookie) {
    var h = { 'User-Agent': parse.UA, Referer: parse._host() + '/', Accept: 'text/html,application/xhtml+xml', 'Accept-Encoding': 'identity' };
    if (cookie) h.Cookie = cookie;
    return h;
  },
  _cookie: function() {
    try { return String(getItem('91jav_full_cookie', '') || ''); } catch (e0) { return ''; }
  },
  _get: function(url) {
    var html = '', ck = parse._cookie();
    try {
      html = request(url, { headers: parse._hdr(ck), timeout: 15000 }) || '';
    } catch (e0) {}
    html = html == null ? '' : String(html);
    if (html && html.indexOf('Just a moment') < 0 && html.length > 800) return html;
    try {
      html = fetchCodeByWebView(url, {
        timeout: 12000,
        headers: parse._hdr(ck),
        checkJs: "document.title.indexOf('Just a moment') === -1 ? 'ok' : null"
      }) || html;
    } catch (e1) {}
    return html == null ? '' : String(html);
  },
  _alive: function(url) {
    var html = '';
    try { html = request(url, { headers: parse._hdr(''), timeout: 8000 }) || ''; } catch (e0) {}
    html = html == null ? '' : String(html);
    return html.indexOf('video-img-box') >= 0 || html.indexOf('热门女优') >= 0 || html.indexOf('/videos/') >= 0;
  },
  预处理1: function() {
    var cur = '';
    try { cur = String(juItem.get('91JAVlink') || ''); } catch (e0) { cur = ''; }
    if (cur && parse._alive(cur + '/new')) return;
    var cands = [parse.host, 'https://www.91jav.fun', 'https://91jav.app', 'https://www.91jav1.com', 'https://91jav1.com'];
    var i, u;
    for (i = 0; i < cands.length; i++) {
      u = cands[i];
      if (parse._alive(u + '/new') || parse._alive(u + '/')) {
        try { juItem.set('91JAVlink', u); } catch (e1) {}
        parse.host = u;
        return;
      }
    }
  },
  getVerifyItem: function(url) {
    return [{
      title: '🛡️ 需要过盾，点这里勾选验证',
      desc: '当前线路碰到 Cloudflare，勾选后看到列表会自动返回',
      col_type: 'text_center_1',
      img: '',
      pic_url: '',
      url: parse._str($().rule(function(targetUrl, ua) {
        setResult([{
          title: '验证沙箱 (过盾后自动返回)',
          url: targetUrl,
          col_type: 'x5_webview_single',
          extra: {
            ua: ua,
            js: $.toString(function() {
              function check() {
                var c = fba.getCookie(location.href);
                var ok = document.querySelector('.video-img-box') || document.querySelector('.img-box');
                if (ok && c && c.indexOf('cf_clearance') > -1) {
                  fba.setItem('91jav_full_cookie', c);
                  fba.toast('授权成功，正在返回');
                  setTimeout(function() { fba.back(); }, 800);
                } else {
                  setTimeout(check, 1000);
                }
              }
              check();
            })
          }
        }]);
      }, url, parse.UA))
    }];
  },
  _getImageDecrypt: function() {
    return $('').image(function() {
      try {
        var CryptoUtil = $.require('hiker://assets/crypto-java.js');
        var key = CryptoUtil.Data.parseUTF8('f5d965df75336270');
        var iv = CryptoUtil.Data.parseUTF8('97b60394abc2fbe1');
        var textData = CryptoUtil.Data.parseInputStream(input);
        var decrypted = CryptoUtil.AES.decrypt(textData, key, { mode: 'AES/CBC/NoPadding', iv: iv });
        return decrypted.toInputStream();
      } catch (e) { return input; }
    });
  },
  _attr: function(html, key) {
    var s = String(html || ''), m;
    m = s.match(new RegExp(key + '\\s*=\\s*"([^"]+)"', 'i'));
    if (m) return m[1];
    m = s.match(new RegExp(key + "\\s*=\\s*'([^']+)'", 'i'));
    return m ? m[1] : '';
  },
  _text: function(html, cls) {
    var s = String(html || ''), m;
    m = s.match(new RegExp('class="' + cls + '"[\\s\\S]{0,400}>([^<]+)', 'i'));
    return m ? String(m[1]).replace(/^\\s+|\\s+$/g, '') : '';
  },
  _play: function(link) {
    return parse._str($('#noLoading#').lazyRule(function(url, ua, host) {
      var cookie = '';
      try { cookie = String(getItem('91jav_full_cookie', '') || ''); } catch (e0) {}
      var html = '';
      try {
        html = request(url, {
          headers: { 'User-Agent': ua, Referer: host + '/', Cookie: cookie, 'Accept-Encoding': 'identity' },
          timeout: 15000
        }) || '';
      } catch (e1) {}
      html = html == null ? '' : String(html);
      if (!html || html.indexOf('Just a moment') >= 0) return url + '#嗅探';
      var m = html.match(/hlsUrl\s*=\s*["'](https?:[^"']+\.m3u8[^"']*)["']/i);
      if (!m) m = html.match(/["'](https?:[^"']+\.m3u8[^"']*)["']/i);
      if (m && m[1]) return 'video://' + m[1] + ';{Referer@' + host + '/&&User-Agent@' + ua + '}';
      return url + '#嗅探';
    }, link, parse.UA, parse._host()));
  },
  _抓取列表: function(url) {
    var html = parse._get(url);
    if (!html || html.indexOf('Just a moment') >= 0 || html.length < 800) return parse.getVerifyItem(url);
    var items = [];
    try { items = pdfa(html, 'body&&.video-img-box') || []; } catch (e0) { items = []; }
    if (!items.length) {
      var chunks = html.split(/class="[^"]*video-img-box/);
      for (var ci = 1; ci < chunks.length; ci++) items.push(chunks[ci]);
    }
    var d = [], seen = {}, i, item, link, title, pic, duration, host;
    host = parse._host();
    for (i = 0; i < items.length; i++) {
      item = items[i];
      try { link = pdfh(item, 'a&&href'); } catch (e1) { link = ''; }
      if (!link) link = parse._attr(item, 'href');
      if (!link || seen[link]) continue;
      seen[link] = 1;
      if (/邮箱|邮件|回家的路|pm\.me|广告|爆大奖/i.test(link + item)) continue;
      if (link.indexOf('http') === 0 && link.indexOf('91jav') < 0 && link.indexOf('/videos/') < 0) continue;
      if (link.indexOf('http') !== 0) link = host + (link.charAt(0) === '/' ? link : '/' + link);
      if (link.indexOf('/videos/') < 0) continue;
      try { title = pdfh(item, 'h3.title&&Text') || pdfh(item, 'img&&alt') || ''; } catch (e2) { title = ''; }
      if (!title) title = parse._attr(item, 'alt') || parse._text(item, 'title');
      title = String(title).replace(/\?&gt;/g, '').split('?')[0].split('？')[0];
      title = title.replace(/^ +| +$/g, '');
      if (/邮箱|邮件|回家的路|pm\.me|找到回家|最新地址|广告/i.test(title)) continue;
      try { pic = pdfh(item, 'img&&z-image-loader-url') || pdfh(item, 'img&&data-src') || pdfh(item, 'img&&src') || ''; } catch (e3) { pic = ''; }
      if (!pic) pic = parse._attr(item, 'z-image-loader-url') || parse._attr(item, 'data-src') || parse._attr(item, 'src');
      if (!pic || pic.indexOf('holder') >= 0) continue;
      if (pic.indexOf('http') !== 0) pic = host + pic;
      try { duration = pdfh(item, '.absolute-bottom-right span&&Text') || ''; } catch (e4) { duration = ''; }
      if (!duration) duration = parse._text(item, 'label');
      if (/广告/.test(duration)) continue;
      d.push({
        title: title || '未命名',
        desc: duration || '',
        img: pic + parse._getImageDecrypt(),
        pic_url: pic + parse._getImageDecrypt(),
        col_type: 'movie_2',
        url: parse._play(link)
      });
    }
    return d;
  },
  _path: function() {
    var raw = '';
    try { raw = String(MY_URL == null ? '' : MY_URL); } catch (e0) { raw = ''; }
    if (!raw || raw === 'fyclass') raw = '/new/fypage';
    return raw.replace('fypage', String(MY_PAGE || 1));
  },
  主页: function() {
    return parse._抓取列表(parse._host() + parse._path());
  },
  搜索: function(name) {
    var q = String(name || MY_URL || '').replace(/[\\"\r\n]+/g, '');
    q = q.replace(/^ +| +$/g, '');
    if (!q) return [{ title: '请输入番号或关键词', desc: '', img: '', pic_url: '', col_type: 'text_1', url: 'hiker://empty' }];
    var p = Number(MY_PAGE || 1) || 1;
    return parse._抓取列表(parse._host() + '/search/' + encodeURIComponent(q) + '/' + p);
  },
  二级: function(url) {
    var u = parse._str(url || MY_URL || input || '');
    return { detail1: '91JAV', desc: '', img: '', line: ['播放'], list: [[{ title: '播放', url: u, desc: '', img: '' }]] };
  },
  解析: function(url) {
    var u = parse._str(url || MY_URL || input || '');
    if (!u) return 'toast://空地址';
    return u;
  }
};
