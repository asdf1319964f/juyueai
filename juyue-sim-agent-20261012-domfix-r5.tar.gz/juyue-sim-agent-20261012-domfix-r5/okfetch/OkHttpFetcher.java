import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.SecureRandom;
import java.security.Security;
import java.security.cert.X509Certificate;
import java.util.*;
import javax.net.ssl.*;

import okhttp3.*;
import org.conscrypt.Conscrypt;

/**
 * 真机同款 OkHttp 4.9.3 网络壳（海阔 8.83 同版本 + trustAll + Conscrypt/BoringSSL）
 *
 * argv[0]=url argv[1]=method argv[2]=timeoutSec argv[3]=cookieJarPath
 * argv[4]=headersFile(每行 Key: Value) argv[5]=bodyFile(可 "-" 表示无) argv[6]=followRedirects(0/1)
 * stdout: 第一行 status / 最后一行 "@FINAL <url>"，中间为响应头；响应体写入 argv[3]+".body"
 */
public class OkHttpFetcher {
    static final String CRLF = "\r\n";

    static X509TrustManager trustAll() {
        return new X509TrustManager() {
            public void checkClientTrusted(X509Certificate[] c, String a) {}
            public void checkServerTrusted(X509Certificate[] c, String a) {}
            public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
        };
    }

    // 简易 netscape jar 读写，保持与仿真框架 curl -b/-c 语义一致
    static Map<String, String> loadJar(String path) {
        Map<String, String> m = new LinkedHashMap<>();
        try {
            for (String line : Files.readAllLines(Paths.get(path), StandardCharsets.UTF_8)) {
                if (line.startsWith("#") || line.trim().isEmpty()) continue;
                String[] t = line.split("\t");
                if (t.length >= 7) m.put(t[5], t[6]);
            }
        } catch (Exception e) {}
        return m;
    }

    static void saveJar(String path, Map<String, String> m) {
        try {
            StringBuilder sb = new StringBuilder("# Netscape HTTP Cookie File\n");
            for (Map.Entry<String, String> e : m.entrySet())
                sb.append(".missav.run\tTRUE\t/\tFALSE\t0\t").append(e.getKey()).append('\t').append(e.getValue()).append('\n');
            Files.write(Paths.get(path), sb.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {}
    }

    public static void main(String[] args) throws Exception {
        String url = args[0];
        String method = args.length > 1 ? args[1].toUpperCase() : "GET";
        int timeout = args.length > 2 ? Integer.parseInt(args[2]) : 20;
        String jarPath = args.length > 3 ? args[3] : "";
        String headersFile = args.length > 4 ? args[4] : "-";
        String bodyFile = (args.length > 5) ? args[5] : "-";
        boolean follow = args.length > 6 ? !"0".equals(args[6]) : true;

        try {
            java.security.Provider p = Conscrypt.newProvider();
            Security.insertProviderAt(p, 1);
        } catch (Throwable t) {
            System.err.println("#conscrypt-unavailable: " + t);
        }

        final Map<String, String> jarMap = new LinkedHashMap<>();
        if (!jarPath.isEmpty()) jarMap.putAll(loadJar(jarPath));

        X509TrustManager tm = trustAll();
        SSLContext sc = SSLContext.getInstance("TLS");
        sc.init(null, new TrustManager[]{tm}, new SecureRandom());

        CookieJar cookieJar = new CookieJar() {
            public void saveFromResponse(HttpUrl u, List<Cookie> cs) {
                for (Cookie c : cs) jarMap.put(c.name(), c.value());
            }
            public List<Cookie> loadForRequest(HttpUrl u) {
                List<Cookie> out = new ArrayList<>();
                for (Map.Entry<String, String> e : jarMap.entrySet()) {
                    try {
                        Cookie c = new Cookie.Builder().name(e.getKey()).value(e.getValue()).domain(u.host()).build();
                        out.add(c);
                    } catch (Throwable t) {}
                }
                return out;
            }
        };

        OkHttpClient client = new OkHttpClient.Builder()
                .sslSocketFactory(sc.getSocketFactory(), tm)
                .hostnameVerifier((h, s) -> true)
                .cookieJar(cookieJar)
                .connectTimeout(timeout, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(timeout, java.util.concurrent.TimeUnit.SECONDS)
                .writeTimeout(timeout, java.util.concurrent.TimeUnit.SECONDS)
                .followRedirects(follow)
                .followSslRedirects(follow)
                .build();

        Request.Builder rb = new Request.Builder().url(url);
        if (!"-".equals(headersFile) && !headersFile.isEmpty()) {
            for (String line : Files.readAllLines(Paths.get(headersFile), StandardCharsets.UTF_8)) {
                int i = line.indexOf(':');
                if (i > 0) rb.header(line.substring(0, i).trim(), line.substring(i + 1).trim());
            }
        }
        RequestBody rbod = null;
        if (!"GET".equals(method) && !"HEAD".equals(method) && !"-" .equals(bodyFile) && !bodyFile.isEmpty()) {
            byte[] b = Files.readAllBytes(Paths.get(bodyFile));
            String ct = rb.build().header("Content-Type");
            rbod = RequestBody.create(b, MediaType.parse(ct != null ? ct : "application/x-www-form-urlencoded"));
        }
        switch (method) {
            case "GET": rb.get(); break;
            case "HEAD": rb.head(); break;
            case "POST": rb.post(rbod != null ? rbod : RequestBody.create(new byte[0], null)); break;
            default: rb.method(method, rbod); break;
        }

        Response resp = client.newCall(rb.build()).execute();
        StringBuilder head = new StringBuilder();
        head.append("HTTP/1.1 ").append(resp.code()).append(' ').append(resp.message()).append(CRLF);
        Headers hs = resp.headers();
        for (int i = 0; i < hs.size(); i++) {
            head.append(hs.name(i)).append(": ").append(hs.value(i)).append(CRLF);
        }
        head.append("@FINAL ").append(resp.request().url()).append(CRLF);

        byte[] body = resp.body() != null ? resp.body().bytes() : new byte[0];
        Files.write(Paths.get(jarPath.isEmpty() ? "/tmp/okfetch.body" : jarPath + ".body"), body);
        saveJar(jarPath, jarMap);
        System.out.print(head.toString());
    }
}
