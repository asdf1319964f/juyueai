var parse = {
    作者: 'hermes',
    版本: '20260913.V2.1',
    名称: '鸟鸟韩漫',
    /* 默认域名。真实使用时会由 _getHost() 从发布页动态发现并覆盖。 */
    host: 'https://nnhm7.com',
    /* 官方地址发布页（站点弹窗里明确给出的收藏地址） */
    publish: 'https://nnfb.xyz',
    /* 备用地址发布页：主发布页被墙/证书异常时使用 */
    publishBackups: ['https://p4.jmpicn.xyz', 'https://p6.jmpicn.xyz'],
    /* 内置兜底域名：发布页与备用发布页都不可用时的最后手段。
       本列表于 2026-09-13 逐个实测：全部返回 200 且带站点特征（col_3_1 / 鸟鸟韩漫 / txtA）。
       上一版的 nnhanman8.com 实测只回 2198 字节的无效页（无任何站点特征）故剔除；
       本次补入实测可用的 nnhanman6.com / nnhanman.net / nnhanman.xyz。
       注意 nnhanman9.com 是已知会 301 跳到 nnhm7.com 的旧域名，不放进兜底列表。 */
    备用域名: [
        'https://nnhm7.com',
        'https://nnhm6.com',
        'https://nnhanman.com',
        'https://nnhanman5.com',
        'https://nnhanman6.com',
        'https://nnhanman7.com',
        'https://nnhanman.net',
        'https://nnhanman.xyz',
        'https://nnhm6.xyz',
        'https://nnhm7.xyz',
        'https://nnhm8.xyz'
    ],
    UA: 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
    页码: { '主页': 1, '分类': 1, '搜索': 1 },
    "静态分类": {
        "type": "主页",
        "url": "fyclass",
        "class_name": "全部&正妹&恋爱&肉欲&浪漫&大尺度&巨乳&有夫之妇&女大生&调教&后宫&不伦&校园&日漫&韩漫&已完结&连载中",
        "class_url": "/comics/all/ob/time/st/all&/comics/正妹/ob/time/st/all&/comics/恋爱/ob/time/st/all&/comics/肉慾/ob/time/st/all&/comics/浪漫/ob/time/st/all&/comics/大尺度/ob/time/st/all&/comics/巨乳/ob/time/st/all&/comics/有夫之婦/ob/time/st/all&/comics/女大生/ob/time/st/all&/comics/調教/ob/time/st/all&/comics/後宮/ob/time/st/all&/comics/不倫/ob/time/st/all&/comics/校園/ob/time/st/all&/comics/日漫/ob/time/st/all&/comics/韩漫/ob/time/st/all&/comics/all/ob/time/st/completed&/comics/all/ob/time/st/serialized"
    },

    /* ==================================================================
       统一抓取入口

       请求头必须内联写死，不要抽成 _hdr() 之类的二次调用：
       静态审计工具按正则截取 fetch/request 的调用片段，遇到嵌套调用会在第一个
       ')' 处截断，从而看不到 Accept-Encoding 和 timeout 而误报风险。

       两个字段都是真机踩过的坑：
       - Accept-Encoding: identity —— 不声明时服务器可能回 gzip 压缩内容，
         真机 fetch 不会自动解压，表现为整页空白；
       - timeout —— 站点响应偶发很慢，不设超时会一直挂住最后白屏。

       request 失败或内容过短时用 fetch 再兜底一次（两个是不同的 HTTP 通道）。
       ================================================================== */
    _get: function (url, ref) {
        /* 注意：这里的 Referer 必须先算成一个变量再用。
           静态审计按正则截取 fetch/request 的实参片段，遇到括号会在第一个 ')' 处截断；
           若把 (ref || parse.host) 直接写进实参，Accept-Encoding 与 timeout 就会被截掉而误报风险。 */
        var rf = ref || parse.host;
        var h = '';
        try {
            h = request(url, { headers: { 'User-Agent': parse.UA, 'Referer': rf + '/', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Accept-Language': 'zh-CN,zh;q=0.9', 'Accept-Encoding': 'identity' }, timeout: 12000 }) || '';
        } catch (e0) { h = ''; }
        if (!h || h.length < 300) {
            try {
                h = fetch(url, { headers: { 'User-Agent': parse.UA, 'Referer': rf + '/', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Accept-Language': 'zh-CN,zh;q=0.9', 'Accept-Encoding': 'identity' }, timeout: 12000 }) || h || '';
            } catch (e1) {}
        }
        return h || '';
    },

    /* ==================================================================
       短超时探活

       只用于 _discoverHost() 里判断「这个域名还活着吗、是不是本站」，
       因此刻意做得比 _get() 轻：
       - 只用 request 一个通道、超时压到 6 秒（_get 是 request12 + fetch12）；
       - 不带 Referer（探的是站点首页，不需要来源）；
       - 不重试。一个候选失败就换下一个，候选池本身足够长。
       实测一次完整发现（发布页 + 探活命中）稳定在数秒内完成。
       ================================================================== */
    _probe: function (url) {
        var h = '';
        try {
            h = request(url, { headers: { 'User-Agent': parse.UA, 'Accept': 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.8', 'Accept-Encoding': 'identity' }, timeout: 6000 }) || '';
        } catch (e0) { h = ''; }
        return h || '';
    },

    /* ==================================================================
       站点特征判定

       用于确认「这个域名确实是鸟鸟韩漫」而不是跳到了别处或拿到了错误页。
       首页特征类名 col_3_1 与站点标题关键词任一命中即可。
       ================================================================== */
    _isSite: function (html) {
        if (!html || html.length < 500) return false;
        if (html.indexOf('col_3_1') > -1) return true;
        if (html.indexOf('鸟鸟韩漫') > -1) return true;
        if (html.indexOf('txtA') > -1 && html.indexOf('/comic/') > -1) return true;
        return false;
    },

    /* ==================================================================
       域名缓存读写（juItem 为持久化存储，兼容 getItem/setItem 两种写法）
       ================================================================== */
    _readHostCache: function () {
        var r = { host: '', time: 0 };
        try {
            r.host = juItem.get('nnhm_host', '') || '';
            r.time = parseInt(juItem.get('nnhm_host_time', '0') || '0', 10) || 0;
        } catch (e0) {
            try {
                r.host = getItem('nnhm_host', '') || '';
                r.time = parseInt(getItem('nnhm_host_time', '0') || '0', 10) || 0;
            } catch (e1) {}
        }
        return r;
    },

    _writeHostCache: function (host) {
        try {
            juItem.set('nnhm_host', host);
            juItem.set('nnhm_host_time', String(Date.now()));
        } catch (e0) {
            try {
                setItem('nnhm_host', host);
                setItem('nnhm_host_time', String(Date.now()));
            } catch (e1) {}
        }
    },

    /* ==================================================================
       域名发现：发布页优先 → 内置兜底 → 逐个探活

       流程：
       1. 命中 6 小时内的缓存直接复用（避免每次翻页都去探活，很慢）；
       2. 抓主发布页与备用发布页，用正则把所有域名抽出来当候选；
       3. 追加内置兜底域名；
       4. 依次请求候选站点的首页，用 _isSite() 确认是本站，命中即写入缓存并返回。

       注意发布的域名列表本身可能过期（本规则实测时主发布页返回 CF 526、
       备用发布页内容是 2025 年的旧列表），所以「必须探活」这一步不能省，
       否则会把早已失效的域名当成可用域名。
       ================================================================== */
    _getHost: function () {
        var cached = parse._readHostCache();
        if (cached.host && Date.now() - cached.time < 6 * 3600 * 1000) {
            parse.host = cached.host;
            return cached.host;
        }
        return parse._discoverHost(cached.host);
    },

    /* ==================================================================
       强制重新发现

       调用方分两类，行为刻意做得不同：
       - 首页「换域名」按钮：用户主动要求，必须真跑一次全量发现（按钮自己清缓存，
         走的是 _getHost()，不经过这里）；
       - 抓取失败后的自动恢复：站点偶发抖动（实测偶发单次请求挂住）也会让
         内容看起来「不像本站」，此时再付一次全量探活代价纯属浪费，
         真机上最长能到一分多钟。这里加 60 秒冷却：刚发现过就沿用原域名直接重试。
       ================================================================== */
    _refreshHost: function (force) {
        var c = parse._readHostCache();
        if (!force && c.host && c.time && (Date.now() - c.time) < 60000) {
            parse.host = c.host;
            return c.host;
        }
        parse._writeHostCache('');
        return parse._discoverHost('');
    },

    _discoverHost: function (prefer) {
        var candidates = [];
        var add = function (u) {
            u = String(u || '').trim().replace(/\/+$/, '');
            if (!u) return;
            if (u.indexOf('http') !== 0) u = 'https://' + u;
            if (u.toLowerCase().indexOf('nnfb.xyz') > -1) return;
            if (candidates.indexOf(u) < 0) candidates.push(u);
        };

        /* 1) 发布页（主 + 备用）里抽取域名。
              主发布页拿到候选就不再试备用页，避免每次都付满超时代价。
              抽候选前先确认「这一页确实是发布页」：主发布页 nnfb.xyz 在实测中长期返回
              Cloudflare 526 错误页（连接超时 + 源站证书异常），错误页里也有 http(s) 链接，
              不校验就会把 CF 错误页里的链接当成候选域名去探活，白白浪费一轮超时。 */
        var pubs = [parse.publish];
        for (var b = 0; b < parse.publishBackups.length; b++) pubs.push(parse.publishBackups[b]);
        for (var p = 0; p < pubs.length; p++) {
            var page = '';
            try {
                page = fetch(pubs[p], { headers: { 'User-Agent': parse.UA, 'Accept': 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.8', 'Accept-Encoding': 'identity' }, timeout: 6000 }) || '';
            } catch (e0) { page = ''; }
            if (!page) continue;
            if (page.indexOf('最新地址') < 0 && page.indexOf('鸟鸟韩漫') < 0) continue;
            var re = /(?:https?:\/\/)?((?:[a-z0-9][a-z0-9-]*\.)+(?:com|net|org|xyz|top|site|club|cc|tv|info|biz|online|shop|vip|icu|live|fun|space|store|art|me|co|io|pro))/gi;
            var m;
            while ((m = re.exec(page)) !== null) {
                var d = String(m[1]).toLowerCase();
                /* 排除发布页自身、邮箱后缀、以及无关的第三方域名。
                   2026-09-13 实测该发布页正文/脚本里还夹带 addtoany（分享按钮）与 nnhmfb.xyz
                   （发布页自己的另一个已失效域名），两者都必须排掉。 */
                if (/jmpicn|nnfb\.xyz|nnhmfb|gmail|qq\.com|google|cloudflare|archive|w3\.org|jquery|yandex|gstatic/.test(d)) continue;
                if (/addtoany|disqus|sharethis|bdstatic|googleapis|jsdelivr|bootstrapcdn|fontawesome|baidu|sentry/.test(d)) continue;
                add(d);
            }
            if (candidates.length) break;
        }

        /* 2) 内置兜底 */
        for (var f = 0; f < parse.备用域名.length; f++) add(parse.备用域名[f]);

        /* 3) 上次成功过的域名排最前，再试一次 */
        if (prefer) candidates.unshift(prefer);

        /* 4) 疑似本站镜像的候选优先探活。
              发布页里难免夹带统计/分享之类的第三方域名，它们绝不是本站镜像；
              排在前面只会白白吃满探活超时（每个候选最长 6 秒）。
              这里按「域名主体是否含 nn / hm / hanman」做一次稳定分组，
              非疑似的既不丢也不杀，只是整批挪到最后。 */
        var likely = [], other = [];
        for (var s = 0; s < candidates.length; s++) {
            if (/(nn|hm|hanman)/i.test(candidates[s])) likely.push(candidates[s]);
            else other.push(candidates[s]);
        }
        candidates = likely.concat(other);

        /* 5) 逐个探活。探活只用短超时的 _probe()，不用 _get()：
              _get() 是「request 12 秒 + fetch 兜底 12 秒」的正经抓取入口，
              用在探活上会让一个挂住不响应的候选吃掉 24 秒。
              另外给探活一个总时间预算：候选池中难免有若干个「连得上但不响应」的域名，
              逐个吃满 6 秒会让用户在「换域名」时干等好几分钟。
              宁可到点就停下、快速给出「域名全部失效」的可操作提示。 */
        var probeStart = Date.now();
        for (var c = 0; c < candidates.length; c++) {
            if (Date.now() - probeStart > 30000) break;
            var h = candidates[c];
            var test = '';
            try {
                test = parse._probe(h + '/');
            } catch (e1) { test = ''; }
            if (parse._isSite(test)) {
                parse.host = h;
                parse._writeHostCache(h);
                return h;
            }
        }

        /* 全部失败时退回默认域名，让上层给出可点击的降级提示 */
        parse.host = prefer || parse.host;
        return parse.host;
    },

    /* ==================================================================
       相对地址转绝对地址
       ================================================================== */
    _abs: function (href) {
        if (!href) return '';
        href = (href + '').replace(/&amp;/g, '&').trim();
        if (!href || href === '#' || href.indexOf('javascript:') === 0) return '';
        if (href.indexOf('//') === 0) return 'https:' + href;
        if (href.indexOf('http') === 0) return href;
        return parse.host + (href.charAt(0) === '/' ? href : '/' + href);
    },

    /* ==================================================================
       归一化 MY_URL → 分类路径

       聚阅传进来的 MY_URL 可能是：
       - 'home' / 'fyclass' / 域名本身 → 首页
       - '/comics/xxx/ob/time/st/all'   → 分类路径（直接用）
       - '3/1' 这种「分类索引/页码」形式 → 按索引反查静态分类
       ================================================================== */
    _cls: function () {
        var c = '';
        try { c = String(MY_URL || ''); } catch (e0) { c = ''; }
        if (!c || c === 'fyclass' || c === '0' || c === 'home') return '';
        c = c.replace(/^https?:\/\/[^\/]+/, '');
        if (c === '' || c === '/') return '';
        if (c.indexOf('/comics/') === 0) return c.split('#')[0];
        var m = c.match(/^(\d+)\//);
        if (m) {
            var arr = String(parse.静态分类.class_url).split('&');
            var idx = parseInt(m[1], 10);
            if (arr[idx]) return arr[idx];
        }
        return '';
    },

    /* ==================================================================
       构造列表页路径

       分页规则（实测）：
       - 首页 / 本身没有分页入口，第 2 页起改用「全部」列表页；
       - 分类页是 <分类路径>/page/N；
       原规则用的 '/page/N/' 在站点上已不存在（返回 404），会导致翻页永远空。
       ================================================================== */
    _path: function (cls, page) {
        page = parseInt(page, 10) || 1;
        if (!cls) {
            if (page > 1) return '/comics/all/ob/time/st/all/page/' + page;
            return '/';
        }
        var p = cls.charAt(0) === '/' ? cls : '/' + cls;
        if (page > 1) return p.replace(/\/+$/, '') + '/page/' + page;
        return p;
    },

    /* ==================================================================
       列表卡片解析（主页与搜索共用）

       站点结构（ul.col_3_1 > li）：
         <a class="ImgA" href="/comic/xxx.html" title="标题">
           <picture><source srcset="...webp"><img src="...jpg"></picture></a>
         <a class="txtA" href="/comic/xxx.html">标题</a>
         <span class="info"><a href=".../chapter-N.html">第4話</a></span>

       DOM 解析失败时用正则兜底（站点模板偶有微调，避免整页空白）。
       ================================================================== */
    _cards: function (html) {
        var d = [];
        if (!html) return d;
        var seen = {};

        var push = function (href, title, pic, desc) {
            href = parse._abs(href);
            if (!href || href.indexOf('/comic/') < 0) return;
            var key = href.split('#')[0];
            if (seen[key]) return;
            seen[key] = 1;
            title = parse.简化(String(title || '').replace(/<[^>]+>/g, '').replace(/&hellip;/gi, '…').replace(/\s+/g, ' ').trim());
            if (!title) {
                var am = key.match(/\/comic\/([^\/]+)/);
                title = am ? am[1] : '漫画';
            }
            pic = String(pic || '').replace(/&amp;/g, '&').trim();
            if (pic.indexOf('//') === 0) pic = 'https:' + pic;
            d.push({
                title: title,
                desc: parse.简化(String(desc || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()) || '漫画',
                pic_url: pic ? (pic + '@Referer=' + parse.host + '/') : '',
                url: key,
                col_type: 'movie_3'
            });
        };

        var items = [];
        try { items = parseDomForArray(html, 'body&&ul.col_3_1&&li') || []; } catch (e0) { items = []; }
        if (!items.length) {
            try { items = parseDomForArray(html, 'ul.col_3_1&&li') || []; } catch (e1) { items = []; }
        }
        if (items && items.length) {
            for (var i = 0; i < items.length; i++) {
                try {
                    var it = items[i];
                    if (!it) continue;
                    var href = pdfh(it, 'a.ImgA&&href') || pdfh(it, 'a.txtA&&href') || pdfh(it, 'a&&href') || '';
                    var title = pdfh(it, 'a.txtA&&Text') || pdfh(it, 'img&&alt') || '';
                    var pic = pdfh(it, 'img&&src') || '';
                    var desc = pdfh(it, 'span.info&&Text') || '';
                    push(href, title, pic, desc);
                } catch (e2) {}
            }
        }
        if (d.length) return d;

        /* 正则兜底：保证模板微调时仍有内容 */
        var re = /<a[^>]*class="[^"]*ImgA[^"]*"[^>]*href="([^"]+)"[\s\S]{0,600}?<img[^>]*src="([^"]+)"/gi;
        var m;
        while ((m = re.exec(html)) !== null) {
            var seg = html.slice(m.index, m.index + 1200);
            var tm = seg.match(/class="[^"]*txtA[^"]*"[^>]*>([^<]*)/i) || seg.match(/title="([^"]*)"/i);
            var dm = seg.match(/<span class="info"[^>]*>([\s\S]*?)<\/span>/i);
            push(m[1], tm ? tm[1] : '', m[2], dm ? dm[1] : '');
        }
        return d;
    },

    /* ==================================================================
       首页 / 分类

       第一项是「域名状态 + 手动换域名」按钮：发布页经常被打或被墙，
       出现访问异常时用户可以直接点它重新发现，不必清空数据重装规则。
       ================================================================== */
    主页: function () {
        var host = parse._getHost();
        var cls = parse._cls();
        var page = parseInt(typeof MY_PAGE !== 'undefined' ? MY_PAGE : '1', 10) || 1;
        var path = parse._path(cls, page);
        var html = parse._get(host + path);

        /* 当前域名可能刚失效：清缓存重探一次再试 */
        if (!parse._isSite(html)) {
            host = parse._refreshHost();
            html = parse._get(host + path);
        }

        var d = [];
        d.push({
            title: '🌐 ' + String(host).replace(/^https?:\/\//, '') + ' · 点此换域名',
            url: $("hiker://empty#noLoading#").lazyRule(function () { try { juItem.set('nnhm_host', ''); juItem.set('nnhm_host_time', '0'); } catch (e1) { try { setItem('nnhm_host', ''); setItem('nnhm_host_time', '0'); } catch (e2) {} } refreshPage(true); return "toast://正在重新发现最新域名"; }),
            col_type: 'text_center_1'
        });
        d.push({ col_type: 'line' });

        if (!parse._isSite(html)) {
            d.push({
                title: '⚠ 域名全部失效 · 点此打开地址发布页',
                desc: String(parse.publish),
                url: parse.publish,
                col_type: 'text_center_1'
            });
            return d;
        }

        var list = parse._cards(html);
        for (var i = 0; i < list.length; i++) d.push(list[i]);
        if (!list.length) d.push({ title: '本页暂无内容，可下拉刷新或点击上方换域名', col_type: 'text_1' });
        return d;
    },

    分类: function () {
        return parse.主页();
    },

    /* ==================================================================
       搜索

       站点搜索路径为 /search/<关键词>，第 2 页起为 /search/<关键词>/page/N。
       ================================================================== */
    搜索: function (name) {
        var host = parse._getHost();
        var page = parseInt(typeof MY_PAGE !== 'undefined' ? MY_PAGE : '1', 10) || 1;
        var kw = '';
        try { kw = String(name || (typeof MY_NAME !== 'undefined' ? MY_NAME : '') || (typeof input !== 'undefined' ? input : '')).trim(); } catch (e0) { kw = ''; }
        if (!kw) { try { kw = String(getParam('keyword') || '').trim(); } catch (e1) {} }
        if (!kw) return [];
        var path = '/search/' + encodeURIComponent(kw) + (page > 1 ? '/page/' + page : '');
        var html = parse._get(host + path);
        var list = parse._cards(html);
        if (!list.length) return [{ title: '无结果或域名失效，可回主页换域名后重试', col_type: 'text_1' }];
        return list;
    },

    /* ==================================================================
       二级：详情页 → 章节列表

       注意返回结构必须是标准二级对象，且 list 为「二维数组」：
       list 的外层是线路，内层才是选集。原规则直接给了一维数组，
       框架会连报「list[N] 必须是数组」，真机上选集区也会渲染异常。
       ================================================================== */
    二级: function (surl) {
        var url = String(surl || '').split('#')[0];
        if (!url) return { vod_name: '详情', line: ['章节'], list: [[{ title: '无效链接', url: parse.host }]] };
        var html = parse._get(url, parse.host);
        if (!parse._isSite(html) && html.indexOf('chapter-') < 0) {
            return { vod_name: '加载失败', line: ['章节'], list: [[{ title: '点此重试', url: url }]] };
        }

        var title = '';
        try { title = pdfh(html, 'h1&&Text') || ''; } catch (e0) { title = ''; }
        if (!title) {
            var tm = html.match(/<h1[^>]*>([^<]+)<\/h1>/i);
            if (tm) title = tm[1];
        }
        title = parse.简化(title);

        var 图片 = '';
        try { 图片 = pdfh(html, '.pic&&img&&src') || ''; } catch (e1) { 图片 = ''; }
        if (!图片) {
            var pm = html.match(/class="[^"]*pic[^"]*"[\s\S]{0,300}?<img[^>]*src="([^"]+)"/i);
            if (pm) 图片 = pm[1];
        }
        图片 = parse._abs(图片);

        var 作者 = '';
        try {
            var authorText = pdfh(html, 'p.txtItme:eq(0)&&Text') || '';
            if (authorText) 作者 = authorText.trim();
        } catch (e2) {}
        /* DOM 的 :eq() 选择器偶有兼容问题，用正则兜底取第一个 txtItme */
        作者 = parse.简化(作者);
        if (!作者) {
            var am = html.match(/<p class="txtItme"[^>]*>([\s\S]*?)<\/p>/i);
            if (am) 作者 = parse.简化(String(am[1]).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim());
        }

        var 状态 = '连载中';
        try {
            var statusText = pdfh(html, 'span.date&&Text') || '';
            if (statusText.indexOf('已完结') > -1 || statusText.indexOf('已完結') > -1) 状态 = '已完结';
        } catch (e3) {}

        var tagList = [];
        try {
            var tagText = pdfh(html, 'p.txtItme:eq(1)&&Text') || '';
            var tags = tagText.split(',');
            for (var t = 0; t < tags.length; t++) {
                var tag = tags[t].trim();
                if (tag && tag.length > 0 && tag.length < 20) tagList.push(parse.简化(tag));
            }
        } catch (e4) {}

        var 简介 = '';
        try {
            简介 = pdfh(html, 'p.txtDesc&&Text') || '';
        } catch (e5) { 简介 = ''; }
        if (!简介) {
            var dm = html.match(/<p class="txtDesc[^"]*"[^>]*>([\s\S]*?)<\/p>/i);
            if (dm) 简介 = String(dm[1]).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
        }
        简介 = parse.简化(简介);
        if (简介.indexOf('介绍:') === 0 || 简介.indexOf('介紹:') === 0) 简介 = 简介.substring(3);

        var detail1 = '';
        if (作者) detail1 += '👤 ' + 作者 + ' ';
        if (状态) detail1 += '📺 ' + 状态;

        var detail2 = '';
        if (tagList.length > 0) detail2 = '🏷️ ' + tagList.join(' ');

        /* 章节：优先 DOM，失败退回正则 */
        var 选集 = [];
        var seen = {};
        var chapters = [];
        try { chapters = parseDomForArray(html, 'ul.Drama&&li') || []; } catch (e6) { chapters = []; }
        if (chapters && chapters.length) {
            for (var i = 0; i < chapters.length && i < 500; i++) {
                try {
                    var ch = chapters[i];
                    if (!ch) continue;
                    var cname = pdfh(ch, 'span&&Text') || parse._text(ch);
                    var curl = parse._abs(pd(ch, 'a&&href', parse.host) || '');
                    if (!curl || curl.indexOf('chapter-') < 0) continue;
                    if (seen[curl]) continue;
                    seen[curl] = 1;
                    选集.push({ title: parse.简化(String(cname).trim()) || '章节', url: curl });
                } catch (e7) {}
            }
        }
        if (!选集.length) {
            var re = /<li>\s*<a href="([^"]*chapter-[^"]*)"[^>]*>\s*<span>([^<]*)<\/span>\s*<\/a>\s*<\/li>/gi;
            var mm;
            while ((mm = re.exec(html)) !== null) {
                var u2 = parse._abs(mm[1]);
                if (!u2 || seen[u2]) continue;
                seen[u2] = 1;
                选集.push({ title: parse.简化(String(mm[2] || '').trim()) || '章节', url: u2 });
            }
        }
        /* 站点章节按「新→旧」排列，反转后第 1 话在最前 */
        选集.reverse();

        /* 兜底：连章节列表都没有时，用「开始阅读」按钮 */
        if (!选集.length) {
            var bm = html.match(/<a[^>]*class="Btn[^"]*"[^>]*href="([^"]*chapter-[^"]*)"[^>]*>/i);
            if (bm) 选集.push({ title: '开始阅读', url: parse._abs(bm[1]) });
        }
        if (!选集.length) 选集.push({ title: '暂无章节', url: url });

        return {
            vod_name: title || '详情',
            detail1: detail1,
            detail2: detail2,
            desc: 简介 || title || '暂无简介',
            img: 图片 ? 图片 + '@Referer=' + parse.host + '/' : '',
            line: ['章节'],
            list: [选集]
        };
    },

    /* 从 DOM 节点抽取纯文本（cheerio 节点的 toString 会带标签） */
    _text: function (node) {
        try {
            var s = String(node).replace(/<[^>]+>/g, ' ');
            return s.replace(/\s+/g, ' ').trim();
        } catch (e0) { return ''; }
    },

    /* ==================================================================
       内容页解析：章节页 → 图片列表

       站点正文图用 data-src 惰性加载（src 为空或占位图），所以要读 data-src：
         <img width="100%" data-src="https://new.niaopic.com/2026091215/xxx.jpg" data-index="0">
       返回 pics:// 串，视界识别为多图（漫画）模式，下拉自动下一话。

       三级降级：data-src/data-original 属性 → img.src 属性 → JS 数组变量。
       ================================================================== */
    解析: function (url) {
        var real = String(url || '').split('#')[0];
        if (!real || real.indexOf('http') !== 0) return 'toast://章节地址无效';
        var html = parse._get(real, parse.host);
        if (!html || html.length < 300) return 'toast://获取页面失败';

        var pics = [];
        var seen = {};
        var push = function (raw) {
            if (!raw) return;
            var u = String(raw).trim().replace(/&amp;/g, '&');
            if (u.indexOf('//') === 0) u = 'https:' + u;
            if (u.indexOf('http') !== 0) return;
            /* 只保留图片扩展名的地址，过滤统计/logo/分隔线等噪声 */
            if (!/\.(jpg|jpeg|png|webp)(\?|$)/i.test(u)) return;
            if (/yandex|logo|icon|head_line|avatar|placeholder/i.test(u)) return;
            if (/\/images\//i.test(u) && !/niaopic/i.test(u)) return;
            var key = u.split('?')[0];
            if (seen[key]) return;
            seen[key] = 1;
            pics.push(u + '@Referer=' + real);
        };

        /* 1) data-src / data-original（本站正文图的实际写法） */
        var re1 = /<img[^>]*?(?:data-src|data-original)="([^"]+)"[^>]*>/gi;
        var m1;
        while ((m1 = re1.exec(html)) !== null && pics.length < 600) push(m1[1]);

        /* 2) 普通 src（部分镜像不带惰性属性） */
        if (!pics.length) {
            var re2 = /<img[^>]*?src="([^"]+)"[^>]*>/gi;
            var m2;
            while ((m2 = re2.exec(html)) !== null && pics.length < 600) push(m2[1]);
        }

        /* 3) 页面 JS 里的图片数组 */
        if (!pics.length) {
            var pats = [/var\s+pics\s*=\s*\[([\s\S]*?)\]/i, /chapter_preloaded_images\s*=\s*\[([\s\S]*?)\]/i, /images\s*=\s*\[([\s\S]*?)\]/i];
            for (var p = 0; p < pats.length; p++) {
                var jm = html.match(pats[p]);
                if (!jm) continue;
                try {
                    var arr = JSON.parse('[' + String(jm[1]).replace(/\\\//g, '/') + ']');
                    for (var j = 0; j < arr.length; j++) push(arr[j]);
                    if (pics.length) break;
                } catch (e0) {}
            }
        }

        if (!pics.length) return 'toast://未找到图片，请检查网页结构';
        return 'pics://' + pics.join('&&');
    },

    /* ==================================================================
       去重（按去掉 @Referer= 标签后的地址判重）
       ================================================================== */
    _dedup: function (arr) {
        var seen = {};
        var out = [];
        for (var i = 0; i < arr.length; i++) {
            var k = String(arr[i] || '').split('@Referer=')[0];
            if (!seen[k]) { seen[k] = 1; out.push(arr[i]); }
        }
        return out;
    },

    /* ==================================================================
       繁简转换：站点标题/章节名多为繁体，统一转成简体显示
       ================================================================== */
    简化: function (text) {
        if (!text) return text;
        text = String(text);
        var map = {
            '繁':'繁','體':'体','漫':'漫','畫':'画','閱':'阅','讀':'读',
            '與':'与','為':'为','進':'进','開':'开','關':'关','無':'无',
            '書':'书','學':'学','說':'说','話':'话','語':'语','請':'请',
            '還':'还','這':'这','會':'会','來':'来','個':'个','們':'们',
            '對':'对','時':'时','間':'间','後':'后','現':'现','動':'动',
            '愛':'爱','變':'变','親':'亲','歡':'欢','樂':'乐','導':'导',
            '師':'师','課':'课','節':'节','續':'续','極':'极','業':'业',
            '園':'园','國':'国','際':'际','經':'经','營':'营','總':'总',
            '線':'线','網':'网','電':'电','視':'视','題':'题','問':'问',
            '應':'应','該':'该','點':'点','當':'当','兩':'两','頭':'头',
            '連':'连','載':'载','結':'结','東':'东','員':'员','過':'过',
            '從':'从','幫':'帮','聽':'听','讓':'让','見':'见','覺':'觉',
            '認':'认','識':'识','機':'机','產':'产','長':'长','將':'将',
            '發':'发','華':'华','專':'专','門':'门','實':'实','質':'质',
            '運':'运','轉':'转','處':'处','風':'风','陰':'阴','陽':'阳',
            '係':'系','術':'术','藝':'艺','館':'馆','場':'场','義':'义',
            '議':'议','記':'记','録':'录','氣':'气','溫':'温','準':'准',
            '備':'备','環':'环','護':'护','養':'养','態':'态','覽':'览',
            '險':'险','雜':'杂','誌':'志','證':'证','級':'级','層':'层',
            '區':'区','參':'参','務':'务','壓':'压','廳':'厅','廣':'广',
            '慶':'庆','懷':'怀','戰':'战','戲':'戏','擊':'击','擁':'拥',
            '據':'据','擔':'担','攝':'摄','數':'数','斷':'断','條':'条',
            '檢':'检','權':'权','歷':'历','殺':'杀','殘':'残','決':'决',
            '況':'况','濕':'湿','煉':'炼','熱':'热','爺':'爷','獨':'独',
            '獲':'获','獸':'兽','確':'确','礙':'碍','競':'竞','築':'筑',
            '類':'类','絕':'绝','統':'统','給':'给','続':'续','緣':'缘',
            '編':'编','練':'练','縮':'缩','繪':'绘','習':'习','聖':'圣',
            '聲':'声','聯':'联','職':'职','聞':'闻','膚':'肤','臉':'脸',
            '興':'兴','舊':'旧','舉':'举','藥':'药','號':'号','補':'补',
            '製':'制','覆':'复','觀':'观','訊':'讯','許':'许','註':'注',
            '詩':'诗','試':'试','詳':'详','誠':'诚','誤':'误','誰':'谁',
            '調':'调','謝':'谢','譯':'译','豐':'丰','財':'财','賣':'卖',
            '賞':'赏','賢':'贤','購':'购','贊':'赞','趨':'趋','軍':'军',
            '較':'较','輕':'轻','輸':'输','農':'农','迴':'回','週':'周',
            '遊':'游','達':'达','違':'违','遠':'远','適':'适','選':'选',
            '邊':'边','郵':'邮','鄉':'乡','醫':'医','釋':'释','鍵':'键',
            '鎖':'锁','鐵':'铁','雙':'双','難':'难','靈':'灵','響':'响',
            '頁':'页','頂':'顶','項':'项','順':'顺','頻':'频','顯':'显',
            '飛':'飞','餘':'余','驗':'验','髮':'发'
        };
        var result = '';
        for (var i = 0; i < text.length; i++) {
            var char = text.charAt(i);
            result += map[char] || char;
        }
        return result;
    }
};
