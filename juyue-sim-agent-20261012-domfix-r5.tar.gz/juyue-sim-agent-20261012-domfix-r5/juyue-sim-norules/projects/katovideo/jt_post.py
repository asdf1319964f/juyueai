#!/usr/bin/env python3
"""加藤视频 API 加密请求测试"""
import sys, json, urllib.request, ssl
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

AESKEY = b'AMZnWRr3rr8BaLiS'
IV = b'pZrc9PeVi1kMXzPP'
HOSTS = [
    'https://xvrxwdo.j83maij.fit:13001',
    'https://vmm6j73.ml17wfc.fit:38292',
    'https://fuf7g49.qvq80fc.fit:28149',
]
UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36'

def enc(obj):
    c = AES.new(AESKEY, AES.MODE_CBC, IV)
    ct = c.encrypt(pad(json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode(), 16))
    return {'encrypt': ct.hex()}

def dec_hex(h):
    c = AES.new(AESKEY, AES.MODE_CBC, IV)
    return unpad(c.decrypt(bytes.fromhex(h)), 16).decode('utf-8', 'replace')

def call(path, obj, host_idx=0):
    host = HOSTS[host_idx]
    req = urllib.request.Request(host + path, method='POST')
    req.add_header('User-Agent', UA)
    req.add_header('Content-Type', 'application/json')
    req.add_header('Accept', 'application/json')
    data = json.dumps(enc(obj)).encode()
    ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
    try:
        with urllib.request.urlopen(req, data=data, timeout=20, context=ctx) as r:
            raw = r.read()
            try:
                j = json.loads(raw)
            except Exception:
                return ('RAW', raw[:400])
            if isinstance(j, dict) and 'encrypt' in j:
                plain = dec_hex(j['encrypt'])
                try:
                    return ('JSON', json.loads(plain))
                except Exception:
                    return ('PLAIN', plain[:1500])
            return ('RAWJSON', j)
    except Exception as e:
        return ('ERR', str(e)[:120])

if __name__ == '__main__':
    path = sys.argv[1]
    # 参数从 stdin 或 argv[2] JSON
    if len(sys.argv) > 2:
        obj = json.loads(sys.argv[2])
    else:
        obj = json.loads(sys.stdin.read() or '{}')
    idx = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    kind, val = call(path, obj, idx)
    print(f'[{kind}] {path} body={json.dumps(obj, ensure_ascii=False)}')
    if kind == 'JSON':
        print(json.dumps(val, ensure_ascii=False, indent=1)[:4000])
    else:
        print(val)
