var parse = {
    作者: "NULL",
    版本: "20260913.V21",
    host: "https://www.wn08.ru",
    publish: "https://wnacg01.link",
    publish2: "https://wnacg02.link",
    UA: "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
    页码: {
        主页: 1,
        分类: 1,
        搜索: 1
    },
    矩阵大类: [
        {
            name: "同人志",
            subs: [
                { name: "全部", path: "/albums-index-cate-5.html" },
                { name: "漢化", path: "/albums-index-cate-1.html" },
                { name: "日語", path: "/albums-index-cate-12.html" },
                { name: "English", path: "/albums-index-cate-16.html" },
                { name: "CG畫集", path: "/albums-index-cate-2.html" },
                { name: "Cosplay", path: "/albums-index-cate-3.html" },
                { name: "3D漫畫", path: "/albums-index-cate-22.html" },
                { name: "AI圖集", path: "/albums-index-cate-37.html" }
            ]
        },
        {
            name: "單行本",
            subs: [
                { name: "全部", path: "/albums-index-cate-6.html" },
                { name: "漢化", path: "/albums-index-cate-9.html" },
                { name: "日語", path: "/albums-index-cate-13.html" },
                { name: "English", path: "/albums-index-cate-17.html" }
            ]
        },
        {
            name: "雜誌短篇",
            subs: [
                { name: "全部", path: "/albums-index-cate-7.html" },
                { name: "漢化", path: "/albums-index-cate-10.html" },
                { name: "日語", path: "/albums-index-cate-14.html" },
                { name: "English", path: "/albums-index-cate-18.html" }
            ]
        },
        {
            name: "韓漫",
            subs: [
                { name: "全部", path: "/albums-index-cate-19.html" },
                { name: "漢化", path: "/albums-index-cate-20.html" },
                { name: "生肉", path: "/albums-index-cate-21.html" }
            ]
        }
    ],
    _getHost: function () {
        var key = "wnacg_host";
        var timeKey = "wnacg_host_time";
        var cached = "";
        var cachedTime = 0;
        try {
            cached = juItem.get(key, "") || "";
            cachedTime = parseInt(juItem.get(timeKey, "0") || "0", 10) || 0;
        } catch (e0) {
            try {
                cached = getItem(key, "") || "";
                cachedTime = parseInt(getItem(timeKey, "0") || "0", 10) || 0;
            } catch (e1) {}
        }
        if (cached && Date.now() - cachedTime < 6 * 3600 * 1000) {
            parse.host = cached;
            return cached;
        }
        var candidates = [];
        var pubs = [parse.publish, parse.publish2];
        for (var i = 0; i < pubs.length; i++) {
            try {
                var html =
                    fetch(pubs[i], {
                        headers: { "User-Agent": parse.UA, "Accept-Encoding": "identity" },
                        timeout: 8000
                    }) || "";
                var re = /https?:\/\/(?:www\.)?wn\d+\.[a-z0-9.]+/gi;
                var m;
                while ((m = re.exec(html)) !== null) {
                    var u = m[0].replace(/\/$/, "");
                    if (candidates.indexOf(u) < 0) candidates.push(u);
                }
            } catch (e2) {}
        }
        var fallbacks = [
            "https://www.wn08.ru",
            "https://www.wn08.shop",
            "https://www.wn07.cfd",
            "https://www.wn08.cfd",
            "https://www.wn07.shop"
        ];
        for (var f = 0; f < fallbacks.length; f++) {
            if (candidates.indexOf(fallbacks[f]) < 0) candidates.push(fallbacks[f]);
        }
        if (cached) candidates.unshift(cached);
        for (var c = 0; c < candidates.length; c++) {
            var h = candidates[c];
            try {
                var test =
                    fetch(h + "/albums-index-cate-5.html", {
                        headers: {
                            "User-Agent": parse.UA,
                            Referer: h + "/",
                            "Accept-Encoding": "identity"
                        },
                        timeout: 6000
                    }) || "";
                if (test && test.indexOf("photos-index-aid") > -1) {
                    parse.host = h;
                    try {
                        juItem.set(key, h);
                        juItem.set(timeKey, String(Date.now()));
                    } catch (e3) {
                        try {
                            setItem(key, h);
                            setItem(timeKey, String(Date.now()));
                        } catch (e4) {}
                    }
                    return h;
                }
            } catch (e5) {}
        }
        var last = cached || parse.host || "https://www.wn08.ru";
        parse.host = last;
        return last;
    },
    _fetch: function (url, referer) {
        var host = parse.host;
        var headers = { "User-Agent": parse.UA, "Accept-Encoding": "identity" };
        headers.Referer = referer || host + "/";
        var html =
            fetch(url, {
                headers: headers,
                timeout: 15000
            }) || "";
        return html && html.length >= 80 ? html : "";
    },
    _absImg: function (img, host) {
        if (!img) return "";
        img = String(img).trim();
        if (img.indexOf("//") === 0) img = "https:" + img;
        else if (img.indexOf("http") !== 0) {
            if (img.charAt(0) === "/") img = host + img;
            else img = host + "/" + img;
        }
        if (img.indexOf("http://") === 0) img = "https://" + img.slice(7);
        return img;
    },
    _parseCard: function (item, host) {
        var raw = String(item);
        var link = pd(item, "a.ImgA&&href", host) || pd(item, "a&&href", host);
        if (!link) {
            var m0 = raw.match(/\/photos-index-aid-\d+\.html/);
            if (m0) link = host + m0[0];
        }
        if (!link || String(link).indexOf("/photos-index-aid-") < 0) return null;
        if (link.indexOf("http") !== 0) link = host + (link.charAt(0) === "/" ? link : "/" + link);
        var title =
            pdfh(item, "a.txtA&&Text") ||
            pdfh(item, ".txtA&&Text") ||
            "";
        if (!title) {
            var sm = raw.match(/<span[^>]*style="[^"]*position:\s*absolute[^"]*"[^>]*>([\s\S]*?)<\/span>/i);
            if (sm) title = sm[1];
        }
        if (!title) title = pdfh(item, "a.ImgA&&Text") || pdfh(item, "a span&&Text") || "";
        if (!title) {
            var tm = raw.match(/title="([^"]+)"/i);
            if (tm) title = tm[1];
        }
        title = String(title)
            .replace(/<em>/gi, "")
            .replace(/<\/em>/gi, "")
            .replace(/<[^>]+>/g, "")
            .replace(/\s+/g, " ")
            .trim();
        var img =
            pd(item, "img&&src", host) ||
            pd(item, "img&&data-src", host) ||
            pdfh(item, "img&&src") ||
            pdfh(item, "img&&data-src");
        if (!img) {
            var im = raw.match(/(?:src|data-src)="([^"]+)"/i);
            if (im) img = im[1];
        }
        img = parse._absImg(img, host);
        var info = pdfh(item, ".info&&Text") || pdfh(item, "span.info&&Text") || "";
        if (!info) {
            var inf = raw.match(/class="info"[^>]*>([\s\S]*?)<\/span>/i);
            if (inf) info = inf[1];
        }
        info = String(info).replace(/\s+/g, " ").trim();
        if (!title) {
            var am = String(link).match(/aid-(\d+)/);
            title = am ? "作品 " + am[1] : "未命名";
        }
        return {
            title: title,
            desc: info,
            pic_url: img ? img + "@Referer=" + host + "/" : "",
            url: link,
            col_type: "movie_3"
        };
    },
    _parseListPage: function (html, host) {
        var d = [];
        var seen = {};
        var items =
            pdfa(html, "body&&#classify_container&&li") ||
            pdfa(html, "ul#classify_container&&li") ||
            pdfa(html, "body&&.col_2&&li") ||
            [];
        var i;
        for (i = 0; i < items.length; i++) {
            var card = parse._parseCard(items[i], host);
            if (card && !seen[card.url]) {
                seen[card.url] = 1;
                d.push(card);
            }
        }
        if (d.length) return d;
        var re =
            /href="(\/photos-index-aid-\d+\.html)"[\s\S]{0,1200}?(?:src|data-src)="([^"]+)"[\s\S]{0,1200}?(?:class="txtA"[^>]*>([\s\S]*?)<\/a>|<span[^>]*position:\s*absolute[^>]*>([\s\S]*?)<\/span>)[\s\S]{0,400}?<span class="info">([\s\S]*?)<\/span>/gi;
        var m;
        while ((m = re.exec(html)) !== null) {
            var link = host + m[1];
            if (seen[link]) continue;
            seen[link] = 1;
            var title = String(m[3] || m[4] || "")
                .replace(/<em>/gi, "")
                .replace(/<\/em>/gi, "")
                .replace(/<[^>]+>/g, "")
                .replace(/\s+/g, " ")
                .trim();
            var img = parse._absImg(m[2], host);
            d.push({
                title: title || m[1],
                desc: String(m[5] || "").replace(/\s+/g, " ").trim(),
                pic_url: img ? img + "@Referer=" + host + "/" : "",
                url: link,
                col_type: "movie_3"
            });
        }
        if (d.length) return d;
        var re2 =
            /href="(\/photos-index-aid-\d+\.html)"[\s\S]{0,800}?(?:src|data-src)="([^"]+)"[\s\S]{0,800}?<span class="info">([\s\S]*?)<\/span>/gi;
        while ((m = re2.exec(html)) !== null) {
            var link2 = host + m[1];
            if (seen[link2]) continue;
            seen[link2] = 1;
            var ctx = html.substring(Math.max(0, m.index - 50), Math.min(html.length, m.index + 900));
            var t2 = "";
            var tm = ctx.match(/position:\s*absolute[^>]*>([\s\S]*?)<\/span>/i) || ctx.match(/class="txtA"[^>]*>([\s\S]*?)<\/a>/i);
            if (tm) t2 = tm[1];
            t2 = String(t2)
                .replace(/<em>/gi, "")
                .replace(/<\/em>/gi, "")
                .replace(/<[^>]+>/g, "")
                .replace(/\s+/g, " ")
                .trim();
            var img2 = parse._absImg(m[2], host);
            var am2 = m[1].match(/aid-(\d+)/);
            d.push({
                title: t2 || (am2 ? "作品 " + am2[1] : m[1]),
                desc: String(m[3] || "").replace(/\s+/g, " ").trim(),
                pic_url: img2 ? img2 + "@Referer=" + host + "/" : "",
                url: link2,
                col_type: "movie_3"
            });
        }
        return d;
    },
    _buildListUrl: function (host, path, page) {
        path = path || "/";
        if (path === "/" || path === "") {
            if (page > 1) return host + "/albums-index-page-" + page + ".html";
            return host + "/";
        }
        if (page > 1) {
            if (/\.html$/i.test(path)) return host + path.replace(/\.html$/i, "") + "-page-" + page + ".html";
            return host + path.replace(/\/$/, "") + "-page-" + page + ".html";
        }
        return host + path;
    },
    _matrixUi: function (d, host) {
        var big = parseInt(getMyVar("wn_big", "0"), 10) || 0;
        var path = getMyVar("wn_path", "/albums-index-cate-5.html");
        var matrix = parse.矩阵大类;
        if (big < 0 || big >= matrix.length) big = 0;
        var i;
        for (i = 0; i < matrix.length; i++) {
            var name = matrix[i].name;
            var selected = i === big;
            var firstPath =
                matrix[i].subs && matrix[i].subs[0] ? matrix[i].subs[0].path : path;
            d.push({
                title: selected
                    ? "““””<b><font color=#FFFFFF>" + name + "</font></b>"
                    : name,
                // lazyRule 回调必须单行：多行源码塞进 URL 会引入换行，真机上有风险
                url: $("hiker://empty#noLoading#").lazyRule(function (idx, p0) { putMyVar("wn_big", String(idx)); putMyVar("wn_path", p0); refreshPage(false); return "hiker://empty"; }, i, firstPath),
                col_type: "scroll_button"
            });
        }
        d.push({ col_type: "line" });
        var subs = matrix[big].subs || [];
        for (i = 0; i < subs.length; i++) {
            var sub = subs[i];
            var on = path === sub.path;
            d.push({
                title: on
                    ? "““””<b><font color=#FF6699>" + sub.name + "</font></b>"
                    : sub.name,
                url: $("hiker://empty#noLoading#").lazyRule(function (p) { putMyVar("wn_path", p); refreshPage(false); return "hiker://empty"; }, sub.path),
                col_type: "scroll_button"
            });
        }
        d.push({
            title:
                "域名 " +
                String(host).replace(/^https?:\/\//, "") +
                " · 点此刷新",
            url: $("hiker://empty#noLoading#").lazyRule(function () { try { juItem.set("wnacg_host", ""); juItem.set("wnacg_host_time", "0"); } catch (e) { try { setItem("wnacg_host", ""); setItem("wnacg_host_time", "0"); } catch (e2) {} } refreshPage(true); return "toast://正在重新获取域名"; }),
            col_type: "text_center_1"
        });
    },
    主页: function () {
        var host = parse._getHost();
        var d = [];
        var path = getMyVar("wn_path", "/albums-index-cate-5.html");
        var page = MY_PAGE || 1;
        parse._matrixUi(d, host);
        var url = parse._buildListUrl(host, path, page);
        var html = parse._fetch(url);
        if (!html) {
            d.push({ title: "列表加载失败，下拉刷新或点上方刷新域名", col_type: "text_1" });
            return d;
        }
        var list = parse._parseListPage(html, host);
        for (var i = 0; i < list.length; i++) d.push(list[i]);
        if (!list.length) d.push({ title: "本页暂无内容", col_type: "text_1" });
        return d;
    },
    分类: function () {
        return parse.主页();
    },
    二级: function (url) {
        var host = parse._getHost();
        var html = parse._fetch(url);
        if (!html) {
            return {
                vod_name: "加载失败",
                vod_pic: "",
                line: ["阅读"],
                list: [[]]
            };
        }
        var cover = pd(html, "#Cover&&img&&src", host) || pdfh(html, "#Cover img&&src") || "";
        cover = parse._absImg(cover, host);
        var title = (pdfh(html, "title&&Text") || "")
            .replace(/-紳士漫畫移動版[\s\S]*$/i, "")
            .replace(/\s*-\s*列表[\s\S]*$/i, "")
            .replace(/-紳士漫畫[\s\S]*$/i, "")
            .trim();
        var author = pdfh(html, ".introName&&Text") || "";
        var category = pdfh(html, ".sub_r&&.pd,1&&Text") || "";
        var pageCount = pdfh(html, ".date&&Text") || "";
        var desc = pdfh(html, "p.txtDesc&&Text") || pdfh(html, ".txtDesc&&Text") || "";
        var aid = "";
        var am = String(url).match(/aid-(\d+)/);
        if (am) aid = am[1];
        if (!aid) {
            var am2 = html.match(/aid-(\d+)/);
            if (am2) aid = am2[1];
        }
        var img = "";
        try {
            img = (MY_PARAMS && MY_PARAMS.img) || cover;
        } catch (e) {
            img = cover;
        }
        var list = [];
        if (aid) {
            list.push({
                title: "📖 開始閱讀",
                url: host + "/photos-item-aid-" + aid + ".html"
            });
        }
        return {
            vod_name: title || "未知标题",
            vod_pic: img ? img + "@Referer=" + host + "/" : "",
            detail1: author ? "作者：" + author : "",
            detail2: category
                ? "分類：" + category + (pageCount ? " ｜ " + pageCount : "")
                : pageCount,
            desc: desc,
            vod_content: desc,
            line: ["阅读"],
            list: [list]
        };
    },
    解析: function (url) {
        var host = parse._getHost();
        var realUrl = String(url || "").split("#")[0];
        var aidMatch = realUrl.match(/aid-(\d+)/);
        if (!aidMatch) return "toast://未找到作品ID";
        var aid = aidMatch[1];
        var dataUrl = host + "/photos-item-aid-" + aid + ".html";
        var html = parse._fetch(dataUrl, host + "/photos-index-aid-" + aid + ".html");
        if (!html) return "toast://加载失败";
        // 站点把图片数组写在 JS 里：mReader.initData({"page_url":[...]})
        // 反斜杠转义（\u002F、\/）先还原，否则后面抽出来的地址是坏的
        html = String(html).replace(/\\u002F/gi, "/").replace(/\\\//g, "/");
        var urls = [];
        var seen = {};
        var norm = function (src) {
            if (!src) return "";
            src = String(src).trim();
            if (src.indexOf("//") === 0) src = "https:" + src;
            if (src.indexOf("http://") === 0) src = "https://" + src.slice(7);
            else if (src.indexOf("http") !== 0) src = host + (src.charAt(0) === "/" ? "" : "/") + src;
            return src;
        };
        var push = function (src) {
            src = norm(src);
            if (!src) return;
            if (!/\.(jpg|jpeg|png|webp)(\?|$)/i.test(src)) return;
            if (/logo|icon|avatar|loading|favicon/i.test(src) && /\/data\/t\//i.test(src)) return;
            // 判重必须去掉 ?verify= 签名，否则同一张图换个签名会被当成两张
            var key = src.split("?")[0];
            if (seen[key]) return;
            seen[key] = 1;
            urls.push(src);
        };
        // ① 首选：页面自带的 page_url 数组，顺序就是站点顺序，签名原样保留
        var i0 = html.indexOf("page_url");
        if (i0 > -1) {
            var lb = html.indexOf("[", i0);
            if (lb > -1) {
                var depth = 0, rb = -1, d;
                for (d = lb; d < html.length; d++) {
                    var ch = html.charAt(d);
                    if (ch === "[") depth = depth + 1;
                    else if (ch === "]") {
                        depth = depth - 1;
                        if (depth === 0) { rb = d; break; }
                    }
                }
                if (rb > lb) {
                    try {
                        var arr = JSON.parse(html.slice(lb, rb + 1));
                        for (var a = 0; a < arr.length; a++) push(arr[a]);
                    } catch (eJ) {}
                }
            }
        }
        // ② 兜底：正则扫绝对地址
        //    这里必须把 ?query（verify 签名）一起吃掉。原写法 /...[^"'\\\s<>]+?\.(?:jpg|jpeg|png|webp)/gi
        //    是惰性匹配，命中 .webp 就收尾，签名被丢掉 → CDN 全部 403 → 阅读页一片空白（实测 74/74 张全 403）
        if (!urls.length) {
            var re = /https?:\/\/[^"'\\\s<>]+?\.(?:jpg|jpeg|png|webp)(?:\?[^"'\\\s<>]*)?/gi;
            var m;
            while ((m = re.exec(html)) !== null) push(m[0]);
        }
        // ③ 再兜底：src / data-src / data-original 属性（含相对路径）
        if (!urls.length) {
            var re2 = /(?:src|data-src|data-original)=["']([^"']+\.(?:jpg|jpeg|png|webp)(?:\?[^"']*)?)["']/gi;
            var m2;
            while ((m2 = re2.exec(html)) !== null) push(m2[1]);
        }
        if (!urls.length) return "toast://未找到图片，站点可能已改版";
        var pics = [];
        for (var p = 0; p < urls.length; p++) pics.push(urls[p] + "@Referer=" + host + "/");
        return "pics://" + pics.join("&&");
    },
    搜索: function (name, page) {
        var host = parse._getHost();
        var key = name || MY_NAME || "";
        if (!key) return [];
        var pg = page || MY_PAGE || 1;
        var url;
        if (pg <= 1) {
            url =
                host +
                "/q/?q=" +
                encodeURIComponent(key) +
                "&f=_all&s=create_time_DESC&syn=yes";
        } else {
            url =
                host +
                "/q/index.php?q=" +
                encodeURIComponent(key) +
                "&m=&f=_all&syn=yes&s=create_time_DESC&p=" +
                pg;
        }
        var html = parse._fetch(url);
        if (!html) return [];
        return parse._parseListPage(html, host);
    }
};