var parse = {
  作者: 'hermes',
  版本: '20260913.V12',
  名称: 'ASMR1',
  host: 'https://www.asmr1.cc',
  UA: 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
  类型: '视频',
  页码: { 主页: 1, 分类: 1, 搜索: 1 },
  静态分类: {
    type: '主页',
    url: 'fyclass',
    class_name: '首页&AKI秋水&BOB1啵啵&圈圈&晓美&Yoonying&呆呆小羊iu&要抱好顶&恰恰恰饭小斯&亭子ww&卡卡助眠',
    class_url: 'home&AKI秋水&BOB1啵啵&圈圈&晓美&Yoonying&呆呆小羊iu&要抱好顶&恰恰恰饭小斯&亭子ww&卡卡助眠'
  },

  _str: function (x) {
    if (x == null) return '';
    try { return String(x); } catch (e0) { return ''; }
  },
  _clsList: function () {
    try { return String((parse.静态分类 && parse.静态分类.class_url) || '').split('&'); } catch (e0) { return ['home']; }
  },
  _page: function () {
    var p = 0;
    try { p = parseInt(MY_PAGE, 10) || 0; } catch (e0) { p = 0; }
    if (p < 1) {
      try {
        var m = String(MY_URL || '').match(/^\d+\/(\d+)$/);
        if (m) p = parseInt(m[1], 10) || 1;
      } catch (e1) {}
    }
    return p < 1 ? 1 : p;
  },
  _cate: function () {
    var c = '';
    try { c = parse._str(MY_URL).replace(/^\s+|\s+$/g, ''); } catch (e0) { c = ''; }
    var list = parse._clsList();
    if (list.indexOf(c) >= 0) return c;
    var m = c.match(/^(\d+)(?:\/(\d+))?$/);
    if (m) {
      var idx = parseInt(m[1], 10) || 0;
      if (list[idx]) return list[idx];
    }
    return 'home';
  },
  _kw: function (keyword) {
    var q = parse._str(keyword).replace(/^\s+|\s+$/g, '');
    try { if (!q) q = String(MY_WD || '').replace(/^\s+|\s+$/g, ''); } catch (e0) {}
    return String(q || '').replace(/[\\"\r\n]+/g, '');
  },
  _fetch: function (url) {
    if (!url || url.indexOf('http') !== 0) return '';
    var html = '';
    try {
      html = request(url, {
        headers: { 'User-Agent': parse.UA, Referer: parse.host + '/', 'Accept-Encoding': 'identity' },
        timeout: 20000
      }) || '';
    } catch (e0) { html = ''; }
    return parse._str(html);
  },
  _text: function (s) {
    s = parse._str(s).replace(/<[^>]+>/g, ' ');
    s = s.replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"');
    return s.replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
  },
  _pic: function (u) {
    u = parse._str(u).replace(/&amp;/g, '&').split('@')[0];
    if (u.indexOf('//') === 0) u = 'https:' + u;
    if (u.indexOf('http') !== 0) return '';
    return u + '@Referer=' + parse.host + '/';
  },
  _listUrl: function (cate, page) {
    cate = parse._str(cate) || 'home';
    page = page || 1;
    if (cate === 'home' || cate === '首页') {
      return page > 1 ? (parse.host + '/page/' + page + '/') : (parse.host + '/');
    }
    return parse.host + '?person=' + encodeURIComponent(cate);
  },
  _oneline: function (s) {
    return parse._str(s).replace(/\s*[\r\n]+\s*/g, ' ');
  },

  /* ==================================================================
     本地代理解密（startProxyServer）
     代理体在「收到请求时」被服务独立求值，必须自包含：只能用平台 API
     （fetch / closeMe / getCryptoJS）、Packages/java、以及服务注入的 MY_PARAMS。

     视频文件： [0, 65536) AES-256-CTR 密文 + [65536, EOF) 明文 MP4
     密钥：     key = ASCII(md5(文件名最后一段))，counter = key 前 16 字节
     CDN 防盗链：只放行 Referer: https://player.abyssplayer.com/
                 （无 Referer → 403；浏览器 JS 不能伪造 Referer，平台 fetch 可以）
     ================================================================== */
  _proxySrc: function () {
    /* $.toString(fn) → "(function(){…})()"：服务端 eval("var MY_PARAMS=…;\n" + 该串)，
       必须是表达式（立即执行），裸 function(){} 会因语句位置缺函数名而语法错误 */
    return parse._oneline($.toString(function () {
      var CT = 65536;
      var hdr = function (range) {
        var h = { Referer: 'https://player.abyssplayer.com/', 'Accept-Encoding': 'identity' };
        var ua = 'Mozilla/5.0 (Linux; Android 13) Chrome/124';
        try { if (MY_PARAMS && MY_PARAMS.a) ua = String(MY_PARAMS.a); } catch (e0) {}
        h['User-Agent'] = ua;
        if (range) h['Range'] = range;
        return h;
      };
      var bad = function (m) {
        return { statusCode: 500, headers: { 'Content-Type': 'text/plain; charset=utf-8' }, body: 'ASMR1_PROXY_ERR: ' + m };
      };
      try {
        var F = Packages.com.example.hikerview.utils.FileUtil;
        var B = Packages.java.util.Base64;
        var q = (typeof MY_PARAMS === 'undefined' || !MY_PARAMS) ? '' : MY_PARAMS.u;
        if (q && typeof q === 'object' && q.length) q = q[0];
        if (!q) return bad('missing param u');
        var info = JSON.parse(String(new java.lang.String(B.getDecoder().decode(String(q).replace(/ /g, '+')), 'ISO-8859-1')));
        /* 站点对部分画质不下发 url/path（只给 fristDatas 首帧分片）→ 这里必须挡住，
           否则 fetch('/') 会拿到一堆垃圾，App 侧表现为莫名报错 */
        var u0 = String(info.u || ''), p0 = String(info.p || '');
        if (u0.indexOf('http') !== 0 || p0.length < 3) {
          return bad('该画质无直连地址（站点未下发 url/path），请换其它画质或走网页播放');
        }
        var full = u0 + '/' + p0;
        var name = String(info.n);
        var size = parseInt(info.s, 10) || 0;

        var s1 = fetch(full, { headers: hdr('bytes=0-' + (CT - 1)), inputStream: true, timeout: 30000 });
        var b1 = F.toBytes(s1);
        try { closeMe(s1); } catch (e1) {}
        if (!b1 || b1.length === 0) return bad('head empty (cdn rejected referer?)');

        eval(getCryptoJS());
        var md5hex = CryptoJS.MD5(name).toString();
        var ctWA = CryptoJS.enc.Latin1.parse(String(new java.lang.String(b1, 'ISO-8859-1')));
        var nb = Math.ceil(ctWA.sigBytes / 16), arr = [], c = [], i, j, k;
        for (i = 0; i < 16; i++) c[i] = md5hex.charCodeAt(i) & 0xff;
        for (var b = 0; b < nb; b++) {
          var line = '';
          for (j = 0; j < 16; j++) line += ('0' + c[j].toString(16)).slice(-2);
          arr.push(line);
          for (k = 15; k >= 0; k--) { c[k] = (c[k] + 1) & 0xff; if (c[k] !== 0) break; }
        }
        var ksWA = CryptoJS.AES.encrypt(CryptoJS.enc.Hex.parse(arr.join('')),
          CryptoJS.enc.Latin1.parse(md5hex),
          { mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.NoPadding }).ciphertext;
        var cw = ctWA.words, kw = ksWA.words, ow = [];
        for (var w = 0; w < cw.length; w++) ow.push((cw[w] ^ (kw[w] || 0)) >>> 0);
        var plain = CryptoJS.lib.WordArray.create(ow, ctWA.sigBytes).toString(CryptoJS.enc.Latin1);
        var headBytes = new java.lang.String(plain).getBytes('ISO-8859-1');

        var rest;
        if (b1.length > CT) {
          rest = new java.io.ByteArrayInputStream(java.util.Arrays.copyOfRange(b1, CT, b1.length));
        } else {
          rest = fetch(full, { headers: hdr('bytes=' + CT + '-'), inputStream: true, timeout: 60000 });
        }
        if (!rest) return bad('tail stream null');
        var seq = new java.io.SequenceInputStream(new java.io.ByteArrayInputStream(headBytes), rest);
        var hs = { 'Content-Type': 'video/mp4', 'Accept-Ranges': 'bytes' };
        if (size > 0) hs['Content-Length'] = String(size);
        return { body: seq, headers: hs, statusCode: 200 };
      } catch (e) { return bad(String(e)); }
    }));
  },

  /* 点击卡片 → 画质菜单页
     关键：必须用 @rule=（不是 @lazyRule=）—— 只有 @rule 这条链上 App 才注册回调，
     setResult 才有效（海角_v48 的 _detailRule 就是这个写法）。
     @lazyRule= 只能 return，setResult 会被静默忽略 → 什么都显示不出来。 */
  _playUrl: function (href) {
    href = parse._str(href);
    if (href.indexOf('http') !== 0) return '';
    /* 代理体源码先存到 myVar（廉价，不启动服务）；点击时才真正 startServer，
       避免列表渲染 35 张卡时被 30s 的 CountDownLatch 阻塞。 */
    try { putMyVar('asmr1_proxy_src', parse._proxySrc()); } catch (e0) {}
    var src = parse._oneline(String(function (u) {
      var H = String.fromCharCode(35);
      /* 标签必须运行时拼：写死在源码里会被 App 的 clearUrlTag 从 JS 中间删掉
         （UrlDetector 对 23 个已知标签做 replaceOnce，不管它出现在 URL 的哪个位置） */
      var T_IGNORE = H + 'ignoreVideo=true' + H + H + 'fullTheme' + H + H + 'immersiveTheme' + H;
      var T_VIDEO = H + 'isVideo=true' + H + H + 'ignoreM3U8' + H;
      var HOST = 'https://www.asmr1.cc';
      var UA = 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36';
      var CT = 65536;
      var webUrl = u + T_IGNORE;

      var page = [];
      var fail = function (why) {
        page.push({ title: '⚠ 解析失败：' + why, desc: '下面是原始信息，可截图反馈', col_type: 'text_center_1', url: 'hiker://empty' });
        page.push({ title: '🌐 网页播放（官方播放器）', desc: '备用通道，需允许网页弹广告', col_type: 'text_center_1', url: webUrl });
        setResult(page);
      };
      try {
        var B64 = Packages.java.util.Base64;
        var req = function (url, ref) {
          try {
            return String(request(url, {
              headers: { 'User-Agent': UA, Referer: ref || (HOST + '/'), 'Accept-Encoding': 'identity' },
              timeout: 20000
            }) || '');
          } catch (e0) { return ''; }
        };
        var b64d = function (s) {
          s = String(s || '').replace(/[^A-Za-z0-9+/=]/g, '');
          try { return String(new java.lang.String(B64.getDecoder().decode(s), 'ISO-8859-1')); } catch (e0) { return ''; }
        };
        var b64e = function (s) {
          try { return String(B64.getEncoder().encodeToString(new java.lang.String(s).getBytes('UTF-8'))); } catch (e0) { return ''; }
        };
        eval(getCryptoJS());

        /* 1) 帖子页 → slug */
        var html = req(u, HOST + '/');
        if (!html) return fail('帖子页打不开（网络/被墙）');
        var PRE = 'player.abyssplayer.com/';
        var i0 = html.indexOf(PRE);
        if (i0 < 0) return fail('帖子页里没有找到播放器链接');
        var m0 = html.slice(i0 + PRE.length).match(/^[A-Za-z0-9_-]+/);
        if (!m0) return fail('播放器 id 解析异常');
        var slug = m0[0];

        /* 2) 播放器页 → datas → media 解密 */
        var ph = req('https://player.abyssplayer.com/' + slug, u);
        if (!ph) return fail('播放器页打不开（' + slug + '）');
        var j0 = ph.indexOf('datas');
        if (j0 < 0) return fail('播放器页里没有 datas');
        var qa = ph.indexOf('"', j0), qb = qa < 0 ? -1 : ph.indexOf('"', qa + 1);
        if (qa < 0 || qb < 0 || qb - qa < 50) return fail('datas 内容为空');
        var j = JSON.parse(b64d(ph.slice(qa + 1, qb)));
        if (!j || !j.media) return fail('datas 里没有 media');
        var pw = String(j.user_id) + ':' + String(j.slug || slug) + ':' + String(j.md5_id);
        var kh = CryptoJS.MD5(pw).toString();
        var ctWA = CryptoJS.enc.Latin1.parse(String(j.media));
        var nb = Math.ceil(ctWA.sigBytes / 16), arr = [], c = [], i, j2, k;
        for (i = 0; i < 16; i++) c[i] = kh.charCodeAt(i) & 0xff;
        for (var b = 0; b < nb; b++) {
          var ln = '';
          for (j2 = 0; j2 < 16; j2++) ln += ('0' + c[j2].toString(16)).slice(-2);
          arr.push(ln);
          for (k = 15; k >= 0; k--) { c[k] = (c[k] + 1) & 0xff; if (c[k] !== 0) break; }
        }
        var ksWA = CryptoJS.AES.encrypt(CryptoJS.enc.Hex.parse(arr.join('')),
          CryptoJS.enc.Latin1.parse(kh),
          { mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.NoPadding }).ciphertext;
        var cw = ctWA.words, kw = ksWA.words, ow = [];
        for (var w = 0; w < cw.length; w++) ow.push((cw[w] ^ (kw[w] || 0)) >>> 0);
        var pt = CryptoJS.lib.WordArray.create(ow, ctWA.sigBytes).toString(CryptoJS.enc.Latin1);
        var obj = JSON.parse(pt);
        var mp4 = obj && obj.mp4;
        if (!mp4 || !mp4.sources || !mp4.sources.length) return fail('解密后没有视频源');

        /* 3) 起本地代理（点击时才启动，结果缓存复用） */
        var base = '';
        try { base = String(getMyVar('asmr1_proxy_base', '') || ''); } catch (eB) { base = ''; }
        if (base.indexOf('http') !== 0) {
          var body = '';
          try { body = String(getMyVar('asmr1_proxy_src', '') || ''); } catch (eC) { body = ''; }
          if (!body) return fail('代理脚本丢失，请重新进入列表');
          try { base = String(startProxyServer(body) || ''); } catch (eS) { base = ''; }
          if (base.indexOf('http') === 0) { try { putMyVar('asmr1_proxy_base', base); } catch (eP) {} }
        }
        if (base.indexOf('http') !== 0) return fail('代理服务启动失败：' + base);

        /* 4) 画质菜单 */
        var zh = function (l) {
          l = String(l || '');
          if (l === '1080p') return '超清 1080P';
          if (l === '720p') return '高清 720P';
          if (l === '480p') return '标清 480P';
          return l || '默认画质';
        };
        var mb = function (n) { n = parseInt(n, 10) || 0; return n > 0 ? (Math.round(n / 1048576 * 10) / 10) + ' MB' : ''; };
        /* 只有 url 和 path 都齐全的画质才能直连解密；缺字段的（站点只下发 fristDatas
           首帧分片）在代理侧必然失败 → 直接不展示，避免点进去报错 */
        var srcs = [], skipped = 0, skLabels = [];
        for (var q = 0; q < mp4.sources.length; q++) {
          var t = mp4.sources[q];
          if (String(t.url || '').indexOf('http') === 0 && String(t.path || '').length > 3) srcs.push(t);
          else { skipped++; skLabels.push(String(t.label || '?')); }
        }
        if (!srcs.length) return fail('此帖未下发直连地址（站点只提供首帧分片 URL），无法在规则内解密');
        srcs.sort(function (a, b) { return (parseInt(b.size, 10) || 0) - (parseInt(a.size, 10) || 0); });
        page.push({
          title: '『' + slug + '』选择画质',
          desc: '规则内解密直连 · 无需官方播放器' + (skipped ? ('（已跳过 ' + skipped + ' 个无地址画质：' + skLabels.join('/') + '）') : ''),
          col_type: 'text_center_1', url: 'hiker://empty'
        });
        for (var m = 0; m < srcs.length; m++) {
          var s = srcs[m];
          var seg = String(s.path || '').split('/');
          var payload = { u: String(s.url || ''), p: String(s.path || ''), n: seg[seg.length - 1], s: String(s.size || ''), a: UA };
          page.push({
            title: '▶ ' + zh(s.label) + (mb(s.size) ? (' · ' + mb(s.size)) : ''),
            desc: '点此播放',
            col_type: 'text_center_1',
            url: base + '?u=' + encodeURIComponent(b64e(JSON.stringify(payload))) + T_VIDEO
          });
        }
        page.push({ col_type: 'blank_block' });
        page.push({ title: '🌐 网页播放（官方播放器）', desc: '备用通道，需允许网页弹广告', col_type: 'text_center_1', url: webUrl });
        setResult(page);
      } catch (e5) {
        fail('异常：' + String(e5 && e5.message ? e5.message : e5).slice(0, 60));
      }
    }));
    return 'hiker://empty#noLoading#@rule=js:(' + src + ')(' + JSON.stringify(href) + ')';
  },

  _cards: function (html) {
    var d = [];
    html = parse._str(html);
    var parts = html.split('<article');
    var i, blk, href, title, img, meta, pic, m;
    for (i = 1; i < parts.length; i++) {
      blk = parts[i];
      m = blk.match(/class="card-link"[^>]*href="([^"]+)"/) || blk.match(/href="([^"]+)"/);
      href = m ? parse._str(m[1]).replace(/&amp;/g, '&') : '';
      if (href.indexOf('//') === 0) href = 'https:' + href;
      else if (href && href.indexOf('http') !== 0) href = parse.host + (href.charAt(0) === '/' ? '' : '/') + href;
      if (!href || href.indexOf('http') !== 0) continue;
      if (href.indexOf('/page/') >= 0 || href.indexOf('wp-content') >= 0 || href.indexOf('?person=') >= 0) continue;
      title = parse._text((blk.match(/class="card-title"[^>]*>([\s\S]*?)<\/h2>/) || [])[1] || '');
      if (!title) {
        var am = blk.match(/<img[^>]+alt="([^"]*)"/);
        title = parse._text(am ? am[1] : '');
      }
      if (!title) continue;
      meta = parse._text((blk.match(/class="card-meta"[^>]*>([\s\S]*?)<\/p>/) || [])[1] || '');
      img = (blk.match(/src="([^"]*\/wp-content\/uploads\/[^"]+)"/) || [])[1] || '';
      pic = parse._pic(img);
      d.push({
        title: title,
        desc: meta,
        img: pic,
        pic_url: pic,
        url: parse._playUrl(href),
        col_type: 'pic_2',
        extra: { ua: parse.UA }
      });
    }
    return d;
  },
  主页: function () {
    var cate = parse._cate();
    var page = parse._page();
    var isHome = (cate === 'home');
    if (!isHome && page > 1) return [];
    var url = parse._listUrl(cate, page);
    var html = parse._fetch(url);
    if (!html) {
      if (page > 1) return [];
      return [{ title: '‘‘’’加载失败，点我重试', desc: url, img: '', pic_url: '', url: url, col_type: 'text_center_1' }];
    }
    var d = parse._cards(html);
    if (d.length) return d;
    if (page > 1) return [];
    return [{ title: '‘‘’’列表为空', desc: url, img: '', pic_url: '', url: url, col_type: 'text_center_1' }];
  },
  分类: function () { return parse.主页(); },
  搜索: function (keyword) {
    var q = parse._kw(keyword);
    if (!q) return [{ title: '‘‘’’输入关键词', desc: '', img: '', pic_url: '', url: 'hiker://empty', col_type: 'text_center_1' }];
    var page = parse._page();
    var url = parse.host + '/?s=' + encodeURIComponent(q) + (page > 1 ? ('&paged=' + page) : '');
    var html = parse._fetch(url);
    if (!html) {
      if (page > 1) return [];
      return [{ title: '‘‘’’搜索失败，点我重试', desc: url, img: '', pic_url: '', url: url, col_type: 'text_center_1' }];
    }
    var d = parse._cards(html);
    if (d.length) return d;
    if (page > 1) return [];
    return [{ title: '‘‘’’未找到「' + q + '」相关内容', desc: url, img: '', pic_url: '', url: url, col_type: 'text_center_1' }];
  }
};
