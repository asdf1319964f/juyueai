#!/bin/bash
cd /home/hermes/juyue/okfetch
# 1) 拉新鲜质询页并现场解题
curl -s -m 20 -A "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/128.0.6613.127 Mobile Safari/537.36" https://missav.run/zh-tw -o /tmp/chal.html
python3 - <<'PYEOF'
import re, hashlib, os
h = open('/tmp/chal.html').read()
seed = re.search(r'challengeSeed\s*=\s*"([0-9a-f]+)"', h).group(1)
mac = re.search(r'challengeMAC\s*=\s*"([0-9a-f]+)"', h).group(1)
cx = int(re.search(r'complexity\s*=\s*(\d+)', h).group(1))
s = bytes.fromhex(seed)
while True:
    nonce = os.urandom(len(s))
    d = hashlib.sha512(s + nonce).digest()
    lz = 0
    for b in d:
        if b == 0: lz += 8; continue
        lz += 8 - b.bit_length(); break
    if lz >= cx: break
lines = ['.missav.run\tTRUE\t/\tFALSE\t0\t__challenge_seed\t' + seed,
         '.missav.run\tTRUE\t/\tFALSE\t0\t__challenge_solution\t' + nonce.hex(),
         '.missav.run\tTRUE\t/\tFALSE\t0\t__challenge_mac\t' + mac]
open('/tmp/okck.jar','w').write('\n'.join(lines) + '\n')
print('solved, cx =', cx)
PYEOF
echo "== OkHttp cookie 重放 =="
java -cp 'lib/*:.' OkHttpFetcher 'https://missav.run/zh-tw' GET 20 /tmp/okck.jar - 1 2>/dev/null > /tmp/okreplay.txt
echo "size: $(wc -c < /tmp/okreplay.txt), video-data: $(grep -c 'video-data' /tmp/okreplay.txt || true)"
echo "== 指纹采集 =="
java -cp 'lib/*:.' OkHttpFetcher 'https://tls.peet.ws/api/all' GET 20 /tmp/okfp.jar - 1 2>/dev/null > /tmp/okfp.txt
python3 - <<'PYEOF'
import json
raw = open('/tmp/okfp.txt', encoding='utf-8', errors='replace').read()
body = raw.split('\r\n\r\n', 1)[-1] if '\r\n\r\n' in raw else raw
j = json.loads(body)
print('http_version:', j.get('http_version'))
print('ja4:', j.get('tls', {}).get('ja4') if isinstance(j.get('tls'), dict) else j.get('ja4'))
print('ja3:', (j.get('tls', {}) or {}).get('ja3', '')[:90] if isinstance(j.get('tls'), dict) else str(j.get('ja3'))[:90])
print('akamai_h2:', (j.get('http2', {}) or {}).get('akamai_fingerprint', ''))
PYEOF
echo "== 对照：纯 curl 指纹 =="
curl -s -m 20 https://tls.peet.ws/api/all -o /tmp/cfp.json
python3 - <<'PYEOF'
import json
j = json.load(open('/tmp/cfp.json'))
t = j.get('tls', {})
print('http_version:', j.get('http_version'))
print('ja4:', t.get('ja4'))
print('ja3:', t.get('ja3', '')[:90])
print('akamai_h2:', (j.get('http2', {}) or {}).get('akamai_fingerprint', ''))
PYEOF
