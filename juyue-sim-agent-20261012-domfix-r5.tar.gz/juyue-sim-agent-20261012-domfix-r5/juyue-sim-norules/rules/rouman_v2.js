/* ============================================================================
   肉漫屋（rouman）规则 v2
   作者：hermes（基于 dy2020 的 v1 重制）

   v1 → v2 的主要修复：
   1. 站点已改版：选择器从 col-span-2/truncate/bg-cover 换成 site-comic 系列
   2. 域名兜底 roum27.xyz 已死；发布页现在分「肉漫屋 / 肉視頻」两组，必须取第一组
   3. page → MY_PAGE、name → MY_KEYWORD（App 注入的变量名）
   4. 去掉两个远程依赖（ghproxy.js + f），改内联：远程依赖一旦拉不到，
      整条规则所有函数全废，这正是本次故障的形态
   5. 阅读页图片走 Next.js flight 数据的 imageUrl，按 ind 排序

   站点结构（2026-09 实测）：
     Next.js App Router，内容伺服端渲染，卡片在 HTML 里可直接抓
     a.site-comic                      → 卡片（href = /books/<id>）
       .site-comic-cover img[src]      → 封面
       h3                              → 标题（含 title 属性）
       .site-comic-chapter             → 最新章节
       .site-comic-meta .shrink-0      → 连载/完结
       .site-comic-meta span           → 分类 / ◉人气
     .site-section-heading             → 首页分组标题
   列表 /books?continued=<true|false|>&page=N     （N 从 0 开始）
   搜索 /search?term=<词>&page=N                  （N 从 0 开始）
   详情 /books/<id>
   阅读 /books/<id>/<章节序号>           图片在 flight 数据里
   ============================================================================ */

let parse = {
    作者: 'hermes',
    版本: '20260913.V2.1',
    名称: '肉漫屋',

    /* 永远返回 1 条兜底地址；真实域名由 _host() 从发布页发现 */
    默认域名: 'https://rouman5.com',
    地址发布页: 'https://rou.pub/dizhi',
    域名缓存: 'hiker://files/rules/juyue/host_rouman_v2.txt',

    /* 抓取用的 UA：站点对 UA 不敏感，但给个正常值避免被当脚本 */
    UA: 'Mozilla/5.0 (Linux; Android 15; 2407FRK8EC Build/AP3A.240617.008; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/128.0.6613.127 Mobile Safari/537.36',

    /* ========================================================================
       基础工具（全部内联，不依赖任何远程模块）
       ======================================================================== */

    /* 反转义 + 清洗。
       Next.js 的 flight 数据里 " 和 / 都被转义成 \" 和 \/，
       不还原就没法从里面提取图片地址。 */
    _u: function (s) {
        if (s === null || s === undefined) return '';
        s = String(s);
        /* &#xHHHH; 实体 */
        s = s.replace(/&#x([0-9a-fA-F]+);/g, function (m, h) { return String.fromCharCode(parseInt(h, 16)); });
        /* 常见的命名实体 */
        s = s.replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
        /* \\uXXXX */
        s = s.replace(/\\u([0-9a-fA-F]{4})/g, function (m, h) { return String.fromCharCode(parseInt(h, 16)); });
        /* flight 数据的 \" 与 \/ */
        s = s.replace(/\\"/g, '"').replace(/\\\//g, '/').replace(/\\\\/g, '\\');
        return s.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
    },

    /* 只做反斜杠反转义，保留标签（给正则提取用） */
    _un: function (s) {
        if (!s) return '';
        return String(s).replace(/\\"/g, '"').replace(/\\\//g, '/').replace(/\\u([0-9a-fA-F]{4})/g, function (m, h) { return String.fromCharCode(parseInt(h, 16)); });
    },

    _safe: function (s) {
        return String(s || '').replace(/https?:\/\//g, '').replace(/[<>:"|?*\/\\]/g, '_');
    },

    /* 富文本包装（App 认 ‘ ‘ ’ ’ 前缀） */
    _ss: function (d, c) { return '‘‘’’<strong><small><font color=#' + (c || '333333') + '>' + d + '</font></small></strong>'; },
    _color: function (d, c) { return '‘‘’’<font color=#' + (c || '333333') + '>' + d + '</font>'; },
    _small: function (d, c) { return '<small><font color=#' + (c || '333333') + '>' + d + '</font></small>'; },
    _strong: function (d, c) { return '‘‘’’<strong><font color=#' + (c || '333333') + '>' + d + '</font></strong>'; },

    /* 相对地址转绝对地址 */
    _abs: function (u, host) {
        u = String(u || '').trim();
        if (!u || u === '#' || u.indexOf('javascript:') === 0) return '';
        if (u.indexOf('http') === 0) return u;
        if (u.indexOf('//') === 0) return 'https:' + u;
        return String(host || '').replace(/\/+$/, '') + (u.charAt(0) === '/' ? u : '/' + u);
    },

    /* ========================================================================
       抓取

       缓存规则沿用 v1 的思路但加了时效：v1 的 getHtml 只看缓存存在与否、
       不判断新鲜度，站点改版后会一直复用旧页面（本次排查时就被这个坑过）。
       textError 用来识别「拿到了内容但其实是错误页」。
       ======================================================================== */
    _错误特征: ['error occurred', '安全验证', 'Your IP has been blocked', 'Access from your IP has been blocked',
        'Attention Required!', 'Checking your browser', 'Just a moment', 'DDOS-Guard', 'Rate-limited',
        'Too Many Requests', '503 Service Unavailable', '502 Bad Gateway', '504 Gateway Timeout',
        'Request blocked', 'Web Application Firewall', 'Please enable JavaScript', '404 Not Found',
        '欢迎来到 nginx', '无法访问目标地址'],

    _bad: function (html) {
        if (!html || html.length < 200) return true;
        for (let i = 0; i < parse._错误特征.length; i++) {
            if (html.indexOf(parse._错误特征[i]) > -1) return true;
        }
        return false;
    },

    _get: function (url, opt) {
        opt = opt || {};
        /* 缓存按「天」失效：内容每天在变，但翻页时不必反复重抓。
           v1 的 getHtml 只看缓存存在与否、不判断新鲜度，站点改版后会一直
           复用旧页面 —— 本次排查时就被这个坑过一次。这里在缓存键里带上日期。 */
        let cachePath = '';
        if (opt.cache !== 0) {
            let day = new Date().toISOString().slice(0, 10);
            cachePath = 'hiker://files/_cache/juyue/rm_' + day + '_' + parse._safe(url) + '.txt';
            try {
                let cached = fetch(cachePath);
                if (cached && cached.length > 500) return cached;
            } catch (e0) { }
        }
        let html = '';
        try {
            html = request(url, { headers: { 'User-Agent': parse.UA, 'Accept': 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.8', 'Accept-Encoding': 'identity' }, timeout: 15000 });
        } catch (e1) { html = ''; }
        if (parse._bad(html)) {
            try {
                html = fetch(url, { headers: { 'User-Agent': parse.UA, 'Accept': 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.8', 'Accept-Encoding': 'identity' }, timeout: 15000 }) || html || '';
            } catch (e2) { }
        }
        if (html && !parse._bad(html)) {
            try { writeFile(cachePath, html); } catch (e3) { }
        }
        return html || '';
    },

    /* ========================================================================
       域名发现

       发布页 https://rou.pub/dizhi 现在是两组：
         <section class="sec"><h2>肉漫屋</h2>  ... rouman5.com / roum29.xyz
         <section class="sec"><h2>肉視頻</h2>  ... rou.video / rouvb1.xyz
       这是两个不同的站（肉視頻 是视频站，HTML 结构完全不同），所以必须
       只取「肉漫屋」那一组，否则会把视频站当成漫画站去解析，永远抓不到卡片。

       v1 的写法是取第 2 个 .url（array[1]），在旧版发布页上碰巧对，
       但发布页一改组就错位 —— 这里改成按分组标题定位，稳得多。
       ======================================================================== */
    _host: function () {
        try {
            let c = fetch(parse.域名缓存);
            if (c && c.indexOf('http') === 0) return c.replace(/\s+/g, '');
        } catch (e0) { }

        let found = '';
        try {
            let html = parse._get(parse.地址发布页, { cache: 6 });
            if (html) {
                /* 优先：定位到 h2 含「肉漫屋」的分组，取组内第一个地址 */
                let secs = pdfa(html, 'body&&section.sec');
                for (let i = 0; i < secs.length; i++) {
                    let name = '';
                    try { name = pdfh(secs[i], 'h2&&Text') || ''; } catch (e1) { }
                    if (name.indexOf('肉漫屋') < 0) continue;
                    let urls = pdfa(secs[i], 'span.url');
                    for (let j = 0; j < urls.length; j++) {
                        let u = parse._u(pdfh(urls[j], 'Text'));
                        if (u && u.indexOf('http') === 0) { found = u.replace(/\/+$/, ''); break; }
                    }
                    break;
                }
                /* 兜底：页面改版导致上面抓不到时，退化成「取所有 .url 里像漫画站的」 */
                if (!found) {
                    let all = pdfa(html, 'span.url');
                    for (let k = 0; k < all.length; k++) {
                        let u = parse._u(pdfh(all[k], 'Text'));
                        if (!u || u.indexOf('http') !== 0) continue;
                        if (/rouman\d|roum\d|rouvideo|rouvb/.test(u) && !/rou\.video|rouvb/.test(u)) { found = u.replace(/\/+$/, ''); break; }
                    }
                }
            }
        } catch (e2) { }

        if (!found) found = parse.默认域名;
        try { writeFile(parse.域名缓存, found); } catch (e3) { }
        return found;
    },

    /* 站点特征判定：新版首页/列表页都有 site-comic 卡片 */
    _isSite: function (html) {
        if (!html || html.length < 500) return false;
        if (html.indexOf('site-comic') > -1) return true;
        if (html.indexOf('肉漫屋') > -1) return true;
        return false;
    },

    /* ========================================================================
       卡片解析

       新版的卡片是一个完整的 <a class="site-comic">，所以直接对它取子元素即可。
       封面在 img 的 src 属性上（旧版是 style 里的背景图，这点变了）。
       ======================================================================== */
    _cards: function (html, host) {
        let out = [];
        let list = [];
        try { list = pdfa(html, 'body&&a.site-comic'); } catch (e0) { list = []; }
        if (!list || !list.length) {
            try { list = pdfa(html, 'a.site-comic'); } catch (e1) { list = []; }
        }
        let seen = {};
        for (let i = 0; i < list.length; i++) {
            let it = list[i];
            let url = '';
            /* pd 在 baseUrl 为空时会去读 MY_URL，取不到就抛错，所以 baseUrl 必须给全 */
            try { url = parse._un(pd(it, 'a&&href', host)); } catch (e2) { }
            if (!url) { try { url = parse._un(pd(it, 'href', host)); } catch (e3) { } }
            if (!url) {
                let hm = String(it).match(/href="([^"]+)"/);
                url = hm ? hm[1] : '';
            }
            url = parse._abs(url, host).split('"')[0];
            if (!url || seen[url]) continue;
            seen[url] = 1;

            let title = '';
            try { title = pdfh(it, 'h3&&Text') || ''; } catch (e4) { }
            if (!title) { try { title = pdfh(it, 'h3&&title') || ''; } catch (e5) { } }
            title = parse._u(title);

            let img = '';
            try { img = pdfh(it, '.site-comic-cover&&img&&src') || ''; } catch (e6) { }
            if (!img) { try { img = pdfh(it, 'img&&src') || ''; } catch (e7) { } }
            img = parse._un(img).split('"')[0];

            let chap = '';
            try { chap = pdfh(it, '.site-comic-chapter&&title') || ''; } catch (e8) { }
            if (!chap) { try { chap = pdfh(it, '.site-comic-chapter&&Text') || ''; } catch (e9) { } }
            chap = parse._u(chap);

            let status = '';
            try { status = pdfh(it, '.site-comic-meta&&.shrink-0&&Text') || ''; } catch (e10) { }
            status = parse._u(status);

            /* 分类 / 人气：.site-comic-meta 里最后一个 span */
            let kind = '';
            try { kind = pdfh(it, '.site-comic-meta,-1&&span:eq(0)&&Text') || ''; } catch (e11) { }
            kind = parse._u(kind);

            out.push({
                title: title || '未命名',
                img: img ? parse._pic(img, 0) : '',
                url: url,
                desc: [chap, status].filter(function (x) { return x; }).join(' · ')
            });
        }
        return out;
    },

    /* ========================================================================
       图片代理

       v1 用一整套 proxyPic 映射（wp.com / images.weserv.nl 等）。
       实测图片直连即可（不带 Referer 也 200），所以默认不代理；
       mode 传入时仍按老映射走，便于遇到被墙的 CDN 时切换。
       ======================================================================== */
    _pic: function (url, mode) {
        url = String(url || '').replace(/"/g, '');
        if (!url) return '';
        if (!mode) return url;
        let map = { 1: 'https://images.weserv.nl/?url=', 2: 'https://wdkj.eu.org/', 3: 'https://seep.eu.org/', 7: 'https://wsrv.nl/?url=' };
        return (map[mode] || '') + url;
    },

    /* ========================================================================
       主页 / 分类 / 搜索
       ======================================================================== */

    页码: { '主页': 1, '分类': 1 },

    '静态分类': {
        type: '主页',
        url: 'fyclass',
        class_name: '全部&连载中&已完结',
        class_url: 'all&serialized&completed'
    },

    主页: function () {
        let host = parse._host();
        let page = parseInt(typeof MY_PAGE !== 'undefined' ? MY_PAGE : 1, 10) || 1;
        let d = [];
        d.push({
            title: '🌐 ' + String(host).replace(/^https?:\/\//, '') + ' · 点此换域名',
            url: $('hiker://empty#noLoading#').lazyRule(function () { try { writeFile('hiker://files/rules/juyue/host_rouman_v2.txt', ''); } catch (e1) { } refreshPage(true); return 'toast://正在重新发现最新域名'; }),
            col_type: 'text_center_1'
        });
        d.push({ col_type: 'line' });

        /* 静态分类 的 class_url 会被宿主当作 MY_URL 传进来。不同宿主对「点分类 tab」
           的调用入口不一样：有的调 分类()，有的把 MY_URL 塞好后直接调 主页()
           （本仓库的仿真框架就是后者）。所以这里必须自己认一次 MY_URL，
           否则三个 tab 会全部显示首页 —— 这是 nnhm7/wangcang 都踩过的坑。 */
        let cls = '';
        try { cls = String(typeof MY_URL !== 'undefined' ? MY_URL : ''); } catch (e0) { cls = ''; }
        if (cls === 'all' || cls === 'serialized' || cls === 'completed' || cls === 'fyclass') {
            return d.concat(parse.分类());
        }

        /* 首页没有分页参数，第 2 页起用「全部」列表页代替 */
        let url = page > 1 ? (host + '/books?continued=&page=' + (page - 1)) : (host + '/home');
        let html = parse._get(url);
        if (!parse._isSite(html)) {
            d.push({ title: '⚠ 加载失败 · 点此重试或换域名', url: host + '/home', col_type: 'text_center_1' });
            return d;
        }

        /* 首页分多个板块：每个板块是「.site-section-heading + .site-comic-grid」。
           站点把第一个板块裸露在 .site-home 下，其余 4 个包在 .site-home-section 里，
           所以不按 section 遍历，而是把「标题」和「卡片网格」两个列表按序号一一配对
           （两边的数量都是 5，且都按文档顺序返回）。
           标题标签不统一：第一个板块用 h1，其余用 h2，所以两个都试。 */
        if (page === 1) {
            let heads = [], grids = [];
            try { heads = pdfa(html, 'body&&.site-section-heading'); } catch (e0) { heads = []; }
            try { grids = pdfa(html, 'body&&.site-comic-grid'); } catch (e1) { grids = []; }
            if (grids && grids.length) {
                for (let g = 0; g < grids.length; g++) {
                    let head = '';
                    if (heads && heads[g]) {
                        try { head = pdfh(heads[g], 'h1&&Text') || ''; } catch (e2) { }
                        if (!head) { try { head = pdfh(heads[g], 'h2&&Text') || ''; } catch (e3) { } }
                    }
                    head = parse._u(head);
                    let cards = parse._cards(grids[g], host);
                    if (!cards.length) continue;
                    d.push({ title: '💠 ' + (head || ('板块 ' + (g + 1))), url: 'hiker://empty', col_type: 'text_1' });
                    for (let c = 0; c < cards.length; c++) d.push(cards[c]);
                }
                if (d.length > 2) return d;
            }
        }

        let cards = parse._cards(html, host);
        if (!cards.length) {
            d.push({ title: '本页暂无内容，可下拉刷新或点上方换域名', col_type: 'text_1' });
            return d;
        }
        for (let i = 0; i < cards.length; i++) d.push(cards[i]);
        return d;
    },

    分类: function () {
        let host = parse._host();
        let page = parseInt(typeof MY_PAGE !== 'undefined' ? MY_PAGE : 1, 10) || 1;
        let cls = '';
        try { cls = String(typeof MY_URL !== 'undefined' ? MY_URL : 'all' || 'all'); } catch (e0) { cls = 'all'; }
        if (!cls || cls === 'home' || cls === 'fyclass') cls = 'all';
        let cont = cls === 'serialized' ? 'true' : cls === 'completed' ? 'false' : '';
        let url = host + '/books?continued=' + cont + '&page=' + (page - 1);

        let d = [];
        let cards = parse._cards(parse._get(url), host);
        for (let i = 0; i < cards.length; i++) d.push(cards[i]);
        if (!d.length) d.push({ title: '本页暂无内容，可下拉刷新或点上方换域名', col_type: 'text_1' });
        return d;
    },

    搜索: function (name) {
        let host = parse._host();
        let page = parseInt(typeof MY_PAGE !== 'undefined' ? MY_PAGE : 1, 10) || 1;
        let kw = '';
        try { kw = String(name || (typeof MY_KEYWORD !== 'undefined' ? MY_KEYWORD : '') || '').trim(); } catch (e0) { kw = ''; }
        if (!kw) { try { kw = String(getParam('keyword') || '').trim(); } catch (e1) { } }
        if (!kw) return [];
        let url = host + '/search?term=' + encodeURIComponent(kw) + '&page=' + (page - 1);
        let d = [];
        let cards = parse._cards(parse._get(url), host);
        for (let i = 0; i < cards.length; i++) d.push(cards[i]);
        if (!d.length) d.push({ title: '没有找到「' + kw + '」，换个词试试', col_type: 'text_1' });
        return d;
    },

    /* ========================================================================
       二级（详情页）

       新版详情页是一个 <dl class="site-book-data"> 键值对：
         作者 / 狀態 / 地區 / 更新，外加 .site-book-stats 的统计、
         .site-book-synopsis 的简介、.site-chapters 里的章节。
       ======================================================================== */
    二级: function (surl) {
        let host = parse._host();
        let url = String(surl || '').split('#')[0];
        if (!url) return { vod_name: '详情', line: ['章节'], list: [[{ title: '无效链接', url: host }]] };
        let html = parse._get(url);
        if (!parse._isSite(html)) {
            return { vod_name: '加载失败', line: ['章节'], list: [[{ title: '点此重试', url: url }]] };
        }

        let title = '';
        try { title = parse._u(pdfh(html, 'h1&&Text') || ''); } catch (e0) { }
        if (!title) {
            let m = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
            if (m) title = parse._u(m[1]);
        }

        let alias = '';
        try { alias = parse._u(pdfh(html, '.site-book-alias&&Text') || ''); } catch (e1) { }

        /* 详情页的资料区是 <dt>标签</dt><dd>值</dd> 成对出现的 dl。
           不要用 dd:eq(n) —— 实测海阔在这个页面上会把 :eq(n) 取到错位的节点
           （“状态”取成了作者+统计、“更新”取成了状态），所以直接按 dt/dd 配对抠。 */
        let info = {};
        try {
            let pairs = String(html).match(/<dt>[\s\S]*?<\/dt>\s*<dd>[\s\S]*?<\/dd>/g) || [];
            for (let i = 0; i < pairs.length; i++) {
                let km = pairs[i].match(/<dt>([\s\S]*?)<\/dt>/);
                let vm = pairs[i].match(/<dd>([\s\S]*?)<\/dd>/);
                if (!km || !vm) continue;
                let k = parse._u(km[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim());
                let v = parse._u(vm[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim());
                if (k && !info[k]) info[k] = v;
            }
        } catch (e2) { }

        let author = info['作者'] || '';
        let status = info['狀態'] || info['状态'] || '';
        let area = info['地區'] || info['地区'] || '';
        let updated = info['更新'] || '';

        let stats = '';
        try { stats = parse._u(pdfh(html, '.site-book-stats&&Text') || ''); } catch (e6) { }

        let desc = '';
        try { desc = parse._u(pdfh(html, '.site-book-synopsis&&Text') || ''); } catch (e7) { }
        if (!desc) {
            let m = html.match(/<div class="site-book-synopsis[^"]*"[^>]*>([\s\S]*?)<\/div>/i);
            if (m) desc = parse._u(m[1]);
        }

        let img = '';
        try { img = parse._un(pdfh(html, '.site-detail-cover&&src') || ''); } catch (e8) { }
        if (!img) { let m = html.match(/<img class="site-detail-cover"[^>]*src="([^"]+)"/i); if (m) img = m[1]; }

        let detail1 = parse._ss(
            (author ? '作者: ' + author : '') +
            (alias ? (author ? '\n' : '') + '别名: ' + alias : '') +
            (area ? '\n地区: ' + area : ''),
            'CC3366');
        let detail2 = parse._color(
            (status ? '状态: ' + status : '') +
            (stats ? (status ? ' ' : '') + stats : '') +
            (updated ? '\n更新: ' + updated : '') +
            (stats ? '' : ''),
            '006699');

        /* 章节：a.site-chapter-link > span[title] */
        let 选集 = [];
        let seen = {};
        let chs = [];
        try { chs = pdfa(html, 'body&&a.site-chapter-link'); } catch (e9) { chs = []; }
        for (let i = 0; i < chs.length; i++) {
            let cu = '';
            try { cu = parse._abs(pd(chs[i], 'a&&href', host), host); } catch (e10) { }
            cu = parse._un(cu).split('"')[0];
            if (!cu || seen[cu]) continue;
            seen[cu] = 1;
            let cn = '';
            try { cn = pdfh(chs[i], 'span&&title') || pdfh(chs[i], 'span&&Text') || ''; } catch (e11) { }
            cn = parse._u(cn) || ('第' + (i + 1) + '话');
            选集.push({ title: cn, url: cu });
        }
        /* 正则兜底 */
        if (!选集.length) {
            let re = /<a href="(\/books\/[^"]+\/\d+)" class="site-chapter-link[^"]*"[^>]*>\s*<span[^>]*>([^<]*)<\/span>/gi, mm;
            while ((mm = re.exec(html)) !== null) {
                let cu = parse._abs(mm[1], host);
                if (seen[cu]) continue;
                seen[cu] = 1;
                选集.push({ title: parse._u(mm[2]) || '章节', url: cu });
            }
        }
        if (!选集.length) 选集.push({ title: '暂无章节', url: url });

        return {
            vod_name: title || '详情',
            detail1: detail1,
            detail2: detail2,
            desc: desc ? parse._small('　　' + desc, 'CC7799') : (title || '暂无简介'),
            img: img ? parse._pic(img, 0) : '',
            line: ['章节'],
            list: [选集]
        };
    },

    /* ========================================================================
       解析（阅读页）

       图片不在 HTML 标签里，而是 Next.js flight 数据中的
          {"imageUrl":"https://v1.xxx/m/<token>/wm:0/sr:1/<base64>.webp","ind":0}
       所以：先反转义，再按 imageUrl 提取、按 ind 排序。

       - sr:0 → 原图直接可看
       - sr:1 → 图片被按行分块打乱，需要 @js= 在本地还原（算法见 _imgFix）
       ======================================================================== */
    解析: function (url) {
        let host = parse._host();
        let html = parse._get(url, { cache: 1 });
        let body = parse._un(html);

        let items = [];
        let re = /"imageUrl"\s*:\s*"([^"]+)"/g, m;
        while ((m = re.exec(body)) !== null) {
            let u = m[1].split('"')[0].trim();
            if (!/^https?:\/\//.test(u)) continue;
            /* 紧跟其后的 ind */
            let ind = items.length;
            let tail = body.slice(m.index, m.index + 400);
            let im = tail.match(/"ind"\s*:\s*(\d+)/);
            if (im) ind = parseInt(im[1], 10);
            items.push({ u: u, ind: ind });
        }
        /* 去重（保留首次出现的顺序信息） */
        let seen = {}, uniq = [];
        for (let i = 0; i < items.length; i++) {
            if (seen[items[i].u]) continue;
            seen[items[i].u] = 1;
            uniq.push(items[i]);
        }
        uniq.sort(function (a, b) { return a.ind - b.ind; });

        let pics = [];
        for (let i = 0; i < uniq.length; i++) {
            let u = uniq[i].u;
            if (!/\.(jpe?g|webp|png|gif)$/i.test(u)) continue;
            pics.push(u + (u.indexOf('sr:1') > -1 ? '@js=' + parse._imgFix(u) : ''));
        }
        if (!pics.length) {
            /* flight 里没拿到时退回 HTML 里的 img 标签（部分镜像两种都有） */
            let alt = [];
            let re2 = /<img[^>]+src="(https?:\/\/[^"]+\.(?:jpe?g|webp|png))"/gi, m2;
            while ((m2 = re2.exec(body)) !== null) alt.push(m2[1]);
            for (let j = 0; j < alt.length; j++) {
                if (alt[j].indexOf('/m/') < 0) continue;
                pics.push(alt[j] + (alt[j].indexOf('sr:1') > -1 ? '@js=' + parse._imgFix(alt[j]) : ''));
            }
        }
        if (!pics.length) return 'toast://本章没有解析到图片' + url;
        return 'pics://' + pics.join('&&');
    },

    最新: function (url) {
        let host = parse._host();
        let html = parse._get(url);
        try { return parse._u(pdfh(html, 'a.site-chapter-link,-1&&Text') || ''); } catch (e0) { }
        return '';
    },

    /* ========================================================================
       图片还原（sr:1）

       站点把每张图按「行块」切分后倒序打乱，块数由**文件名 base64 解出的路径**的
       md5 末字节决定：blockCount = md5(path) 的最后一字节 % 10 + 5。
       还原就是把第 i 块搬回正确位置（首块额外包含余数行）。

       这段在 App 本地跑：input 是图片输入流，返回还原后的输入流。
       注意 @js= 的内容必须是「立即执行的函数表达式」，所以用 $.toString 包参数。
       ======================================================================== */
    _imgFix: function (picUrl) {
        return $.toString(function (picUrl) {
            eval(getCryptoJS());
            var ByteArrayOutputStream = java.io.ByteArrayOutputStream;
            var ByteArrayInputStream = java.io.ByteArrayInputStream;
            var Bitmap = android.graphics.Bitmap;
            var BitmapFactory = android.graphics.BitmapFactory;
            var Canvas = android.graphics.Canvas;
            var imgBitmap = null, newImgBitmap = null;
            try {
                var parts = picUrl.split('/');
                var fileName = parts[parts.length - 1];
                var base64Part = fileName.split('.').slice(0, -1).join('.');
                /* 补 padding，否则 atob 会失败 */
                while (base64Part.length % 4 !== 0) base64Part += '=';
                var decodedString = window0.atob(base64Part.replace(/-/g, '+').replace(/_/g, '/'));
                var md5 = CryptoJS.MD5(decodedString).toString();
                var lastByte = parseInt(md5.substring(md5.length - 2), 16);
                var blockCount = lastByte % 10 + 5;

                imgBitmap = BitmapFactory.decodeStream(input);
                if (!imgBitmap) return input;
                var width = imgBitmap.getWidth();
                var height = imgBitmap.getHeight();
                var blockHeight = Math.floor(height / blockCount);
                var remainder = height % blockCount;
                if (blockHeight <= 0) return input;

                newImgBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                var canvas = new Canvas(newImgBitmap);
                for (var cb = 0; cb < blockCount; cb++) {
                    var sourceY = height - blockHeight * (cb + 1) - remainder;
                    var destY = blockHeight * cb;
                    var ch = blockHeight;
                    if (cb === 0) { ch = blockHeight + remainder; }
                    else { destY += remainder; }
                    if (sourceY < 0) { ch += sourceY; sourceY = 0; }
                    if (sourceY + ch > height) { ch = height - sourceY; }
                    if (ch <= 0) continue;
                    var blk = Bitmap.createBitmap(imgBitmap, 0, sourceY, width, ch);
                    canvas.drawBitmap(blk, 0, destY, null);
                    blk.recycle();
                }
                var baos = new ByteArrayOutputStream();
                newImgBitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                return new ByteArrayInputStream(baos.toByteArray());
            } catch (e) {
                return input;
            } finally {
                try { if (newImgBitmap) newImgBitmap.recycle(); } catch (e1) { }
                try { if (imgBitmap) imgBitmap.recycle(); } catch (e2) { }
            }
        }, picUrl ? picUrl : '');
    }
};
