---
name: juyue-rule-pitfalls
description: 开发或修复聚阅/海阔规则时必须先读的真机踩坑清单。触发包括写规则、修搜索、修详情空白、图片空白、视频无法播放、CF、登录、Cookie、WebView、Discuz、二级、pics、吃瓜、91、AES 解密、ArticleListModel、Expected URL scheme、PNG包m3u8、Shaka、官方播放器、屏蔽页面元素。用来避免重复踩 2026-09 这批坑。
metadata:
  type: workflow
  version: "20260911.1"
---

# 聚阅规则真机踩坑

详细例子见 `notes/2026-09-10_规则踩坑.md`。下面是强制规避。

## 先探活再写码

打开现网首页/分类/搜索/详情/一张封面字节。旧规则里的 id、接口、分类 slug 默认当过期。

## URL 必须是 http/https

真机列表会 OkHttp 拉卡片地址。禁止当列表 url 的东西：

- `hiker://empty##...`
- `#noLoading#@rule=...`
- `/archives/123/`

列表详情写法：`$(https://主机/archives/id/).rule(fn, host, ua)`。`request` 前检查 `indexOf('http')===0`。

## 图文不要走视频二级

视频源二级只画 `list` 选集，`extenditems` 经常丢。图文用 `.rule()` + `setResult`。用户要直出图集就 `pics://`，不要再套二级。

## rule 回调零闭包

参数顺序必须和烘焙实参一致。回调里不要用外层 `parse`/`this`。host、UA、key、iv 全部传入。字段全部 `String(x||'')`，缺 `pic_url/desc/url` 会 `replace` 空指针。

## 图片先看魔数

`Content-Type: image/jpeg` 不可信。`FFD8FF` 才是 JPEG。911/91 系常用 AES-CBC/NoPadding，key `f5d965df75336270`，iv `97b60394abc2fbe1`。封面可能在 `loadBannerDirect('url')`，正文可能在 `data-xkrkllgl`。

## 视频先解 data-config

`&quot;`、`\/`、`\u0026` 处理后再 JSON.parse。播放 `video://m3u8;{Referer@...}`。有 CF 头但无挑战页就普通 request，不要上 WebView。

## 广告过滤要保守

用 `indexOf('关键词：')` 截尾巴。禁止宽正则 `广告|回家|浏览器` 扫正文。含中文标点的字符类正则可能在 Android JS 抛错，导致只剩视频。

## 仿真不是真机

`ISSUES 0` 不覆盖 OkHttp scheme、二级模板是否渲染 extenditems、Java 解密、WebView Cookie。交付时写明差。

## WebView 登录必须过桥

WebView 登录态不自动给 `request()`。禁止空 `extra.js` + 只 `getCookie(host+'/')`。登录页轮询 `fba.getCookie(location.href/origin/host/forum.php)` 和页面「退出」/`discuz_uid`，写入 `juItem` + 文件后，后续 `request` 自己带 Cookie 头。HttpOnly 只能靠 `fba.getCookie`，不要只读 `document.cookie`。

## 特殊播放：用官网播放器，不要硬解直链

站点把 HLS 包成 PNG、走 Shaka `responseFilter`、CF 指纹或没有明文 m3u8 时，规则解出的地址 Exo/`clearM3u8` 播不了。

默认做法（rou.video / 同类站，2026-09-11）：

1. 列表搜索照常解析。
2. 点击不要回 m3u8。用：

```javascript
$('hiker://empty#noLoading#').rule(function (page, ua, js) {
  setResult([{
    title: '播放',
    url: page,
    col_type: 'x5_webview_single',
    desc: 'float&&100%',
    extra: { ua: ua, js: js }
  }]);
}, page, ua, js);
```

3. JS 只把 `.播放器` 的兄弟 `display:none`，再把播放器 `position:fixed` 铺满。
4. 禁止 `document.body.innerHTML = ''` 或把 video 挪出原树，会拆掉 Shaka/React。
5. 禁止用 `#immersiveTheme#` / 图文详情打开播放页，那是文章二级，不是播放 WebView。
6. 禁止 `parse._str($().rule())` / `parse._str($().lazyRule())`，对象会被变成废字符串，点击没反应。
7. `类型: 视频` 时非直链经常没反应或被当空播放；要用上面的 `.rule()` 开 X5。
8. 直链能播的站仍走 `video://` / m3u8，这套只给「只有官网播放器能拆流」的站。

## Discuz 附图走 /remote/

`/data/attachment/forum/*.jpg` 经常 404；`thumb/800x600`、`0x0` 是空白 SVG。用 `/remote/data/attachment/forum/*.jpg`。附件 `aid=` 链接游客会跳登录，不能当 `pic_url`。
