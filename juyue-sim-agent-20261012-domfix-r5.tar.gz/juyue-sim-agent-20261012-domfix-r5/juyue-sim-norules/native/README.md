# native/ — 原生 dex/so 返回值 fixture 目录

规则里调 `loadJavaClass` / `findJavaClass` 时，PC 沙箱不可能真跑 ART/JNI，
所以桥默认返回占位串 `NATIVE_STUB::<类名>#<方法名>`（明显标记，不冒充真值）。

把**真机上抓到的真实返回值**放进这个目录，桥就会返回真值 ——
这样"原生返回之后的整条管线"（拼 URL、拼播放项、翻页、App 消费）就能在 PC 端到端验收。

## 查找顺序

1. `$JUYUE_NATIVE_FIXTURES`（多个用 `:` 分隔）
2. `<框架根目录>/native/`  ← **推荐放这里**，跨次运行稳定
3. `<--out 目录>/runtime/native/`（每次运行都新建带时间戳的目录，只作兜底）

## 两种文件格式

**JSON（推荐，一个类一个文件）** — `com.rule.jianpian.json`

```json
{
  "JPUrlDec": "真机上抓到的返回值原文",
  "另一个方法名": "..."
}
```

方法名带不带类名前缀都认：`JPUrlDec` 和 `com.rule.jianpian.JPUrlDec` 都能匹配。

**纯文本（单方法场景省事）** — `com.rule.jianpian#JPUrlDec.txt`

内容就是返回值原文，不要加引号或转义。

> 链式属性调用（文档案例 3 的 `NativeLib.lxxx.NativeLib(args)`）在调用记录里显示为
> `com.lxxx.NativeLib#lxxx.NativeLib`，`.json` 的键写 `"lxxx.NativeLib"` 即可。

## 怎么抓真机值

1. 在聚阅规则里临时把调用结果 `log()` 出来（或用 `toast` 弹出）；
2. 或者改规则把返回值写文件：`writeFile('hiker://files/cache/nat.txt', String(v))`，再从 App 目录取出；
3. 拿到后填进本目录，再跑

```sh
node run.js ../demo-rules/native_decrypt.js --cat home --device --out /tmp/x
#   [NATIVE] 2 次原生调用（0 次返回占位串，2 次命中 fixture）   ← 命中真值
```

## 强制模式

```sh
JUYUE_NATIVE=strict node run.js <rule> --cat x --device   # 无 fixture 直接失败，防止"占位串混过验收"
JUYUE_NATIVE=off    node run.js <rule> --cat x --device   # 完全不注入（等价旧行为，会 ReferenceError）
JUYUE_ABI=armeabi-v7a node run.js ...                     # 覆盖 getCpuAbi() 返回值
```

## 示例

见 `com.rule.jianpian.json.example`（把 `.example` 去掉即可生效）。
本目录下所有真实 fixture 文件默认**不进版本库/不打进交付包**，只留示例。
