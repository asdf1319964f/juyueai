const path = require('path');
const { createSandbox, loadRule } = require('./lib/engine');

(async () => {
  const rulePath = process.argv[2];
  const kw = process.argv[3] || '助眠';
  const page = Number(process.argv[4] || 1);

  const { sandbox, workdir } = createSandbox({
    workdir: path.join(process.cwd(), 'runtime_search'),
  });
  const parse = loadRule(rulePath, sandbox);

  // 真机 SearchParser 注入 MY_PAGE / MY_KEYWORD。MY_WD 只留给旧规则兼容。
  sandbox.MY_PAGE = page;
  sandbox.MY_POSITION = 0;
  sandbox.MY_KEYWORD = kw;
  sandbox.MY_WD = kw;
  sandbox.MY_URL = 'hiker://search?keyword=' + encodeURIComponent(kw);

  const t0 = Date.now();
  const out = await parse.搜索(kw);
  const dt = Date.now() - t0;

  console.log('关键词=' + kw, '页=' + page, '耗时=' + dt + 'ms');
  console.log('返回条目数 =', Array.isArray(out) ? out.length : 'NOT-ARRAY');
  (out || []).slice(0, 5).forEach((it, i) => {
    console.log(' ', i, '|', String(it.title).slice(0, 40), '|', String(it.desc || '').slice(0, 30));
  });
  if (!out || !out.length) console.log('  (空)');
})().catch(e => { console.error('ERR', e.message); process.exit(1); });
