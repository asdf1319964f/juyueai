var parse = {
  作者: 'NULL',
  版本: '20260901v1',
  名称: 'Telegram Web版',
  页码: { 主页: 1, 分类: 1, 搜索: 1 },
  静态分类: { type: '主页', url: 'fyclass/fypage', class_name: 'A& B', class_url: 'a&b' },
  _ensureAuth: function () {},
  _api: function (path, data) { return path; },
  _oneItem: function (it) { return it; },
  主页: function () {
    return [
      { title: 'Telegram 1', url: 'https://web.telegram.org/k/' },
      { title: 'Telegram 2', url: 'https://web.telegram.org/k/' }
    ];
  },
  分类: function () { return []; },
  搜索: function (name) { return []; },
  二级: function (id) { return []; },
  解析: function (url) { return []; }
};
module.exports = parse;
