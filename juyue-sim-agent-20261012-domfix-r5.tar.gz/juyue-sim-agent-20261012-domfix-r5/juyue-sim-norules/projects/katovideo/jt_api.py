#!/usr/bin/env python3
"""加藤视频 API 解密工具"""
import sys, json, urllib.request, ssl, zlib
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

AESKEY = b'AMZnWRr3rr8BaLiS'
IV = b'pZrc9PeVi1kMXzPP'
HOSTS = [
    'https://xvrxwdo.j83maij.fit:13001',
    'https://vmm6j73.ml17wfc.fit:38292',
    'https://fuf7g49.qvq80fc.fit:28149',
]
UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36'

def decrypt_hex(h):
    ct = bytes.fromhex(h)
    c = AES.new(AESKEY, AES.MODE_CBC, IV)
    return unpad(c.decrypt(ct), 16).decode('utf-8', 'replace')

def api(path, host_idx=0, method='GET', body=None):
    host = HOSTS[host_idx]
    url = host + path
    req = urllib.request.Request(url, method=method)
    req.add_header('User-Agent', UA)
    req.add_header('Accept', 'application/json')
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header('Content-Type', 'application/json')
    else:
        data = None
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try:
        with urllib.request.urlopen(req, data=data, timeout=20, context=ctx) as r:
            raw = r.read()
            try:
                j = json.loads(raw)
            except Exception:
                return ('RAW', raw[:500])
            if isinstance(j, dict) and 'encrypt' in j:
                plain = decrypt_hex(j['encrypt'])
                try:
                    return ('JSON', json.loads(plain))
                except Exception:
                    return ('PLAIN', plain[:2000])
            return ('RAWJSON', j)
    except Exception as e:
        return ('ERR', str(e))

if __name__ == '__main__':
    path = sys.argv[1] if len(sys.argv) > 1 else '/'
    idx = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    kind, val = api(path, idx)
    print(f'[{kind}] {path}')
    if kind == 'JSON':
        print(json.dumps(val, ensure_ascii=False, indent=1)[:3000])
    else:
        print(val)
